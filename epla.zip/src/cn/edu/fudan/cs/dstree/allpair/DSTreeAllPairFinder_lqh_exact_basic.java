package cn.edu.fudan.cs.dstree.allpair;

import java.io.FileWriter;
import java.io.BufferedWriter;
import cn.edu.fudan.cs.dstree.dynamicsplit.ISeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeSegmentSketch;
import cn.edu.fudan.cs.dstree.dynamicsplit.SeriesSegmentSketch;
import cn.edu.fudan.cs.dstree.partition.Edge;
import cn.edu.fudan.cs.dstree.partition.Graph;
import cn.edu.fudan.cs.dstree.partition.Partitioner;
import cn.edu.fudan.cs.dstree.partition.Vertex;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

/**
 * by lqh
 */
public class DSTreeAllPairFinder_lqh_exact_basic {
	private static final Log log = LogFactory
			.getLog(DSTreeAllPairFinder_lqh_exact_basic.class);
	private int capacity;
	public boolean useUpperBound=true;
	public boolean isUseUpperBound() {
		return useUpperBound;
	}

	public void setUseUpperBound(boolean useUpperBound) {
		this.useUpperBound = useUpperBound;
	}

	private long allsize;
	int segmentSize;

	public int getSegmentSize() {
		return segmentSize;
	}

	public void setSegmentSize(int segmentSize) {
		this.segmentSize = segmentSize;
	}

	public long getAllsize() {
		return allsize;
	}

	public void setAllsize(long allsize) {
		this.allsize = allsize;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	double padReduceRatio = 0.01;
	List<int[]> ret2 = new ArrayList<int[]>();
	private int segmentLength;
	private Node target = null;
	private HashMap cache = new HashMap();
	List<int[]> nodeIdxPairList;

	// List<double[]> boundsPairList;
	public double getPadReduceRatio() {
		return padReduceRatio;
	}

	public void setPadReduceRatio(double padReduceRatio) {
		this.padReduceRatio = padReduceRatio;
	}

	List<Node> nodeList = new ArrayList<Node>();
	List<Node> nodeAllList = new ArrayList<Node>();
	List<int[]> idxArrayList = new ArrayList<int[]>();
	Node root = null;
	Map<Node, Integer> nodeMap = new HashMap<Node, Integer>();
	double[][] timeSeries;
	double[][] reducedTimeSeries;
	int tsLength;

	public double[][] getTimeSeries() {
		return timeSeries;
	}

	public int getTsLength() {
		return tsLength;
	}

	public void setTsLength(int tsLength) {
		this.tsLength = tsLength;
	}

	public void loadIndexAndData(String index) throws IOException,
			ClassNotFoundException {
		Node newRoot = Node.loadFromFile(index);
		log.debug("newRoot = " + newRoot);
		root = newRoot;
		// fina all terminal node
		loadTerminalNodes(newRoot);
		for (int i = 0; i < nodeList.size(); i++) {
			Node node = nodeList.get(i);
			nodeMap.put(node, i);
		}
		log.debug("nodeList.size() = " + nodeList.size());
		log.debug("nodeList total pairs = " + nodeList.size() * nodeList.size()
				/ 2);

		int size = newRoot.getSize();
		
	//	timeSeries = new double[size][tsLength];
		// reducedDimensionCount = (int) (tsLength * padReduceRatio);
		reducedDimensionCount = segmentSize;
	//	System.out.println("  Size    is    " + size+"    segmentSize      is     "+segmentSize);
		//System.out.println(" segment size   is   "+segmentSize);
		// if (tsLength % reducedDimensionCount != 0)
		// throw new
		// RuntimeException("reduceDimensionCount can not be divided!");
		segmentLength = tsLength / reducedDimensionCount;

		reducedTimeSeries = new double[size][reducedDimensionCount];
		// disk algorithm needn't load data
		loadData();

		log.debug("idxArrayList.size() = " + idxArrayList.size());
	}

	int reducedDimensionCount;
	public int getReducedDimensionCount() {
		return reducedDimensionCount;
	}

	public void setReducedDimensionCount(int reducedDimensionCount) {
		this.reducedDimensionCount = reducedDimensionCount;
	}

	int[] segments;

	private void loadData() throws IOException {
		int idx = 0;
		for (int i = 0; i < nodeList.size(); i++) {
			Node node = nodeList.get(i);
			String fileName = node.getFileName();
			double[][] tss = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(
					fileName, tsLength);
			int[] idxArray = new int[node.getSize()];

			for (int j = 0; j < tss.length; j++) {
				double[] ts = tss[j];
				idxArray[j] = idx;
			//	timeSeries[idx] = ts;
				idx++;
			

			}
		
			idxArrayList.add(idxArray);

		}

		// deal with reducedTimeSeries
	//	segments = AllPairUtils.calcPoints(tsLength, reducedDimensionCount);
	//	for (int i = 0; i < timeSeries.length; i++) {
		//	reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i],
		//			segments);
		//}
	}

	public void loadTerminalNodes(Node node) {
		if (node == null)
			return;

		if (node.isTerminal()) {
			nodeList.add(node);
		} else {
			Node left = node.getLeft();
			loadTerminalNodes(left);

			Node right = node.getRight();
			loadTerminalNodes(right);
		}
	}

	public Node findParent(Node root, Node node) {
		if (root == null)
			return null;
		else if (root.getLeft() == node || root.getRight() == node)
			return root;
		else {
			Node leftnode = findParent(root.getLeft(), node);
			if (leftnode != null)
				return leftnode;
			return findParent(root.getRight(), node);

		}

	}

	public boolean findCloseParent(Node root, Node node, int start, int end) {
		if (root == null)
			return false;

		if (root == node) {
			if (target == null)
				return false;
			else
				return true;
		}

		if (matchSegments(root, start, end))
			target = root;

		boolean leftnode = findCloseParent(root.getLeft(), node, start, end);
		if (leftnode)
			return leftnode;
		return findCloseParent(root.getRight(), node, start, end);
	}

	public boolean matchSegments(Node node, int start, int end) {
		boolean result = false;
		short[] old = node.nodePoints;
		int same = -1;
		for (int t = 0; t < old.length; t++) {
			// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
			int old_start = 0;
			if (t > 0)
				old_start = old[t - 1];
			if (old_start == start && old[t] == end) {
				same = t;
				// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
				result = true;
				break;
			}
		}

		return result;

	}

	public void loadAllNodes(Node node) {
		if (node == null)
			return;

		if (node.isTerminal()) {
			nodeAllList.add(node);
		} else {
			Node left = node.getLeft();
			loadTerminalNodes(left);

			Node right = node.getRight();
			loadTerminalNodes(right);
		}
	}

	public List<int[]> findNodePairsNew(double range, int type,boolean basic)
			throws IOException {
		log.debug("DSTreeAllPairFinder.findNodePairsNew begin");
		int nodelistsize = nodeList.size();
		int all = nodelistsize * (nodelistsize - 1) / 2;
		List<int[]> ret = new ArrayList<int[]>();
		
		int pruneC = 0;
		int allCompares = 0;
		int pruneC_lower = 0;
		int pruneC_upper = 0;
		// deep search
		Stack<Node> firstTraverseStack = new Stack<Node>();
		Stack<Node> secondTraverseStack = new Stack<Node>();
		firstTraverseStack.push(root);
		//String name = "/home/hadoop/lqh/out_pairs_" + capacity + ".txt";
	//	FileWriter fw = new FileWriter(name);// ����FileWriter��������д���ַ���
	//	BufferedWriter bw = new BufferedWriter(fw);
	//	FileWriter fw = new FileWriter("c:\\data\\dstree_between_"+capacity+"_"+segmentSize+".txt");// ����FileWriter��������д���ַ���
	//	BufferedWriter bw = new BufferedWriter(fw);
		int lbprune = 0;
		double lbprunerate = 0.0;
		int ubprune = 0;
		double ubprunerate = 0.0;
		while (!firstTraverseStack.isEmpty()) {
			Node firstVisitNode = firstTraverseStack.pop();
			if (firstVisitNode.isTerminal()) {
				//System.out.println("first node  "+firstVisitNode.getId());
				int i = nodeMap.get(firstVisitNode);

				// find pair node after the current node
				secondTraverseStack.clear();

				secondTraverseStack.addAll(firstTraverseStack);
                int count=0;
                int count1=0;
                int count2=0;
				while (!secondTraverseStack.isEmpty()) {
					Node secondVisitNode = secondTraverseStack.pop();
					if (secondVisitNode.isTerminal()) {
						// calc lowerBound
						double lb = 0.0;
						double ub = 0.0;
						double lbreal = 0.0;
						double ubreal = 0.0;
						allCompares++;
						count++;
						if (type == 1) {
							lb = lowerBound(firstVisitNode, secondVisitNode);
							if(useUpperBound)
								ub = upperBound(firstVisitNode, secondVisitNode);
							count1++;
						} else {
							count2++;
						//	System.out.println("******************************");
							lb = lowerBound_different_segmentsize_new(
									firstVisitNode, secondVisitNode,basic);
						//	double lb3= lowerBound_different_segmentsize(
							//		firstVisitNode, secondVisitNode);
						//	double lb2 = lowerBound_different_segmentsize_new(
							//		firstVisitNode, secondVisitNode,!basic);
						//	if(lb>lb2)
							//	System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBB  optimiztion  "+lb2+"  basic "+lb+"  old  "+lb3);
						//	else
							//	System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAA  Wrong optimiztion  "+lb2+"  basic "+lb);
				    		if(useUpperBound)
								ub = upperBound_different_segmentsize(
									firstVisitNode, secondVisitNode);
						/*	lbreal=lowerBoundReal_two(firstVisitNode,
							 secondVisitNode);
							 ubreal=upperBoundReal_two(firstVisitNode,
							 secondVisitNode);
							bw.write(lb + "\t" + ub + "\t\t" + lbreal + "\t"
									+ ubreal + "\t\t" + firstVisitNode.getId()
									+ "\t" + secondVisitNode.getId());
						     bw.newLine();*/
						}
						if (useUpperBound && ub <= range) {
							ubprune++;
							int j = nodeMap.get(secondVisitNode);
						//	ret.add(new int[] { i, j });
							pruneC_upper += firstVisitNode.getSize()
									* secondVisitNode.getSize();
							ret2.add(new int[] { i, j });
							continue;
						}
						if (lb <= range ) {
							int j = nodeMap.get(secondVisitNode);
							ret.add(new int[] { i, j });
							continue;
						}
						if (lb > range) {
							lbprune++;
							pruneC_lower += firstVisitNode.getSize()
									* secondVisitNode.getSize();

						}

						
					} else {
						double lb = 0.0;
						double ub=0.0;
						if (type == 1)
						{
							lb = lowerBound(firstVisitNode, secondVisitNode);
							
						}
						else
						{
						
							lb = lowerBound_different_segmentsize_new(
									firstVisitNode, secondVisitNode,basic);
						//	double lb2 = lowerBound_different_segmentsize_new(
							//		firstVisitNode, secondVisitNode,!basic);
						//	if(lb>lb2)
							//	System.out.println("BBBBBBBBBBBBBBB   ");
							
						} 
						if (lb <= range) {
							
							
								Node left = secondVisitNode.getLeft();
								if (left != null)
									secondTraverseStack.push(left);
	
								Node right = secondVisitNode.getRight();
								if (right != null)
									secondTraverseStack.push(right);
							}
						
					}
				}
			//	System.out.println("  count    "+count+"    count1    "+count1+"  count2   "+count2);
			} else {
				Node left = firstVisitNode.getLeft();
				if (left != null)
					firstTraverseStack.push(left);

				Node right = firstVisitNode.getRight();
				if (right != null)
					firstTraverseStack.push(right);
			}
		}

		// for (int i = 0; i < nodeList.size(); i++) {
		// Node node1 = nodeList.get(i);
		// for (int j = i + 1; j < nodeList.size(); j++) {
		// Node node2 = nodeList.get(j);
		//
		// if (lowerBound(node1, node2) <= range) {
		// ret.add(new int[]{i, j});
		// }
		// }
		// }
		log.debug("DSTreeAllPairFinder.findNodePairsNew end");
		System.out.println("**************  between  Upper Bound Pruning  nodes   "
				+ ubprune + "   rate   is  " + (double) ubprune / all
				+ "  time series   is " + pruneC_upper+"    number of comparisons of nodes "+allCompares);
		System.out.println("   between **************   Lower Bound Pruning  nodes   "
				+ lbprune + "   rate    is   " + (double) lbprune / all
				+ "  time series   is " + pruneC_lower);
	//	bw.close();
	//	fw.close();
		return ret;
	}

	private double lowerBound_different_segmentsize_new(Node node1, Node node2,boolean basic) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		int size1 = node1.getSegmentSize();
		int size2 = node2.getSegmentSize();
		short[] info1 = node1.nodePoints;
		short[] info2 = node2.nodePoints;
		boolean allsame = true;
		if (info1.length == info2.length) {
			for (int ii = 0; ii < info1.length; ii++) {
				if (info1[ii] != info2[ii]) {
					allsame = false;
					break;
				}

			}
			// allsame=true;
		} else
			allsame = false;
		if (allsame) {
			double lb = lowerBound(node1, node2);
			return lb;
		}

		/*
		 * if(size1==size2 && size1==10) { double lb=lowerBound(node1,node2);
		 * return lb; }
		 */

		int length = tsLength;
		int i = 0;
		int j = 0;
		List<int[]> result = new ArrayList();
		while (info1[i] != length || info2[j] != length) {
			while (info1[i] != info2[j]) {
				if (info1[i] > info2[j] && j < (size2 - 1))
					j++;
				else {
					if (i < (size1 - 1))
						i++;
				}

			}
			int end1 = i;
			int end2 = j;
			if (i < (size1 - 1))
				i++;
			if (j < (size2 - 1))
				j++;
			int[] item = new int[2];
			item[0] = end1;
			item[1] = end2;
			result.add(item);
			// System.out.println("  end1   is   "+end1+"  end2   is  "+end2);

		}
		// System.out.println("  common segment   is  "+result.size());

		int info1_start = 0;
		int end1_pre = -1;
		int info2_start = 0;
		int end2_pre = -1;
		for (int ii = 0; ii < result.size(); ii++) {

			if (ii >= 1) {
				int[] item = result.get(ii - 1);
				end1_pre = item[0];
				info1_start = info1[end1_pre];
				end2_pre = item[1];
				info2_start = info2[end2_pre];

			}
			int[] item2 = result.get(ii);
			int end1 = item2[0];
			int end2 = item2[1];
			Range node1AvgRange = null;// new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = null;// new Range(node2MinAvg, node2MaxAvg);
			Range node1StdRange = null;// new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = null;// new Range(node2MinStd, node2MaxStd);
			int segmentLength1 = 0;// initial value
			
		//	System.out.println("All  greate ************"+(end1 - end1_pre)+"  2nd   is "+(end2 - end2_pre));
			if ((end1 - end1_pre) > 1) {
				double node1MaxAvg = 0.0;
				double node1MinAvg = 0.0;
				double node1MaxStd = 0.0;
				double node1MinStd = 0.0;
				// System.out.println("  end1_pre    is   "+end1_pre+"   point is  "+info1[end1_pre]);
				// System.out.println("  end1    is   "+end1_pre+"   point is  "+info1[end1]);
			/*	if ((end1 - end1_pre) == 2) {
					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);

						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;

					double Avgmin1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1];
					double Avgmax1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0];
					double Avgmin2 = node1.getNodeSegmentSketches()[end1].indicators[1];
					double Avgmax2 = node1.getNodeSegmentSketches()[end1].indicators[0];
					if (Avgmin2 > Avgmax1) {
						double temp = Avgmin2 - Avgmax1;
						node1MinStd += (node1.getSegmentLength(end1_pre + 1)
								* node1.getSegmentLength(end1) * temp * temp)
								/ (segmentLength1 * segmentLength1);
						node1MinStd = Math.sqrt(node1MinStd / segmentLength1);
					} else {
						if (Avgmin1 > Avgmax2) {
							double temp = Avgmin1 - Avgmax2;
							node1MinStd += (node1
									.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
									/ (segmentLength1 * segmentLength1);
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						} else {
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						}
					}

					double temp = Math
							.max(Math
									.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0]
											- node1.getNodeSegmentSketches()[end1].indicators[1]),
									Math.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1]
											- node1.getNodeSegmentSketches()[end1].indicators[0]));
					node1MaxStd = node1MaxStd
							/ segmentLength1
							+ (node1.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node1MaxStd = Math.sqrt(node1MaxStd);
				} 
				*/
				//else {
					double addMinStd = addition_item_of_minstd(node1, end1_pre,
							end1);
					double addMaxStd = addition_item_of_maxstd(node1, end1_pre,
							end1);

					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);
						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;
				//	System.out.println("    addMinstd   "+addMinStd+"  addMaxStd "+addMaxStd);
                    if(!basic)
                    	node1MinStd = Math.sqrt((node1MinStd + addMinStd)
							/ segmentLength1);
                    if(!basic)
                    	node1MaxStd = Math.sqrt((node1MaxStd + addMaxStd)
							/ segmentLength1);
					
		             
				     target = null;
				     long id = node1.id;
				     String key = "" + id + "\t" + info1_start + "\t" + info1[end1];
				     Object value = cache.get(key);
				     double nodeMaxAvg_o = 0.0;
				     double nodeMinAvg_o = 0.0;
				     double nodeMaxStd_o = 0.0;
				     double nodeMinStd_o = 0.0;
				     if (value == null) {
				    	 boolean tt = findCloseParent(root, node1, info1_start,
							info1[end1]);
					// find the segment in the original
				    	 short[] old = target.nodePoints;
				    	 int same = -1;
				    	 for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
				    		 int old_start = 0;
				    		 if (t > 0)
				    			 old_start = old[t - 1];
				    		 if (old_start == info1_start && old[t] == info1[end1]) {
				    			 same = t;
				    			 // System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
				    			 break;
				    	 }//for 
					}//if
					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);
						// System.out.println(" Parent   min avg  "+nodeMinAvg_o+"  max avg  "+nodeMaxAvg_o+"  min std  "+nodeMinStd_o+"  max  std   "+nodeMaxStd_o);
						// System.out.println("   min avg  "+node1MinAvg+"  max avg  "+node1MaxAvg+"  min std  "+node1MinStd+"  max  std   "+node1MaxStd);

					}
				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);

				}
				
				node1MinAvg = Math.max(nodeMinAvg_o, node1MinAvg);
				node1MaxAvg = Math.min(nodeMaxAvg_o, node1MaxAvg);
				if(!basic)
					node1MinStd = Math.max(nodeMinStd_o, node1MinStd);
				else
					node1MinStd=nodeMinStd_o;
				if(!basic)
					node1MaxStd = Math.min(nodeMaxStd_o, node1MaxStd);
				else
					node1MaxStd=nodeMaxStd_o;
				if(node1MinAvg>node1MaxAvg)
					node1MaxAvg=node1MinAvg;
				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				if(node1MinStd>node1MaxStd)
					node1MaxStd=node1MinStd;
			    node1StdRange = new Range(node1MinStd, node1MaxStd);
			 //   System.out.println("  min std  "+node1MinStd+"  max std "+node1MaxStd+"  basic "+basic);

			} else {
				double node1MaxAvg = node1.getNodeSegmentSketches()[end1].indicators[0];
				double node1MinAvg = node1.getNodeSegmentSketches()[end1].indicators[1];
				double node1MaxStd = node1.getNodeSegmentSketches()[end1].indicators[2];
				double node1MinStd = node1.getNodeSegmentSketches()[end1].indicators[3];
				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				segmentLength1 = node1.getSegmentLength(end1);

			}
			if ((end2 - end2_pre) > 1) {
				double node2MaxAvg = 0.0;
				double node2MinAvg = 0.0;
				double node2MaxStd = 0.0;
				double node2MinStd = 0.0;
				double Avgmin1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1];
				double Avgmax1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0];
				double Avgmin2 = node2.getNodeSegmentSketches()[end2].indicators[1];
				double Avgmax2 = node2.getNodeSegmentSketches()[end2].indicators[0];
			    double addMinStd = addition_item_of_minstd(node2, end2_pre,
							end2);
				double addMaxStd = addition_item_of_maxstd(node2, end2_pre,
							end2);
				for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);
						// segmentLength1+=node1.getSegmentLength(jj);
				 }

				node2MaxAvg = node2MaxAvg / segmentLength1;
				node2MinAvg = node2MinAvg / segmentLength1;
				if(!basic)
					node2MinStd = Math.sqrt((node2MinStd + addMinStd)
							/ segmentLength1);
				if(!basic)
					node2MaxStd = Math.sqrt((node2MaxStd + addMaxStd)
							/ segmentLength1);
			//	}// else

				target = null;
				long id = node2.id;
				String key = "" + id + "\t" + info2_start + "\t" + info2[end2];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node2, info2_start,
							info2[end2]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info2_start && old[t] == info2[end2]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}
                   
					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);

					}
    			} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);
				}
				node2MinAvg = Math.max(nodeMinAvg_o, node2MinAvg);
				node2MaxAvg = Math.min(nodeMaxAvg_o, node2MaxAvg);
			//	node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
			//	node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
				
				if(!basic)
					node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
				else
					node2MinStd=nodeMinStd_o;
				if(!basic)
					node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
				else
					node2MaxStd=nodeMaxStd_o;
				if (node2MinAvg > node2MaxAvg) {
					node2MaxAvg = node2MinAvg;
				}
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				if (node2MinStd > node2MaxStd) {
					node2MaxStd = node2MinStd;
				}
				node2StdRange = new Range(node2MinStd, node2MaxStd);

			} else {
				// (end2-end2_pre)==1
				double node2MaxAvg = node2.getNodeSegmentSketches()[end2].indicators[0];
				double node2MinAvg = node2.getNodeSegmentSketches()[end2].indicators[1];
				double node2MaxStd = node2.getNodeSegmentSketches()[end2].indicators[2];
				double node2MinStd = node2.getNodeSegmentSketches()[end2].indicators[3];
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				node2StdRange = new Range(node2MinStd, node2MaxStd);
			}
			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}
			double stdDistance = Range.distance(node1StdRange, node2StdRange);
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}

		}

		sum = Math.sqrt(sum);

		// System.out.println("Different     node  size   common segment   is  "+result.size()+"          distance  is   "+sum);
		return sum;
	}
	
	public double[][] reduce(double[][] originalTss) {
		double[][] ret = new double[originalTss.length][];
		segments = AllPairUtils.calcPoints(tsLength, reducedDimensionCount);
		for (int i = 0; i < originalTss.length; i++) {
			ret[i] = AllPairUtils.avgBySegments(originalTss[i], segments);
		}
		return ret;
	}

	/**
	 * @param allPairs
	 * @param range
	 * @param maxCacheSize
	 *            time series count
	 */
	public void findAllPairsWithPartition(AutoExpandIntArray allPairs,
			double range, double maxCacheSize, Partitioner partitioner, int type,boolean basic)
			throws IOException {
		// init graph
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		long actualNumber = 0;

		//FileWriter fw = new FileWriter("/home/hadoop/lqh/singlenode_out.txt");// ����FileWriter��������д���ַ���
		/*FileWriter fw = new FileWriter("/home/hadoop/lqh/singlenode_out.txt");// ����FileWriter��������д���ַ���
		BufferedWriter bw = new BufferedWriter(fw);
		for (int i = 0; i < nodeList.size(); i++) {
			double upbound = upperBound(nodeList.get(i));
			double lbboundReal = lowerBoundReal(nodeList.get(i));
			double ubboundReal=upperBoundReal(nodeList.get(i));
		    System.out.println("  upper bound  of  node "+i+"   is           "+upbound);
			bw.write("" + upbound + "\t" + lbboundReal + "\t"+ubboundReal
					+ nodeList.get(i).getSize());
			bw.newLine();
     	}
		bw.close();
*/
		double allsize2 = (nodeList.size() * (nodeList.size() - 1)) / 2;
		nodeIdxPairList = findNodePairsNew(range, 2,basic);
		double rate = (double) nodeIdxPairList.size() / allsize2;
		System.out.println("nodeIdxPairList.size() = " + nodeIdxPairList.size()
				+ "    time    is   " + stopWatch.getTime() + "  rate   is  "
				+ rate);
		log.debug("nodeIdxPairList.size() = " + nodeIdxPairList.size());
		int totalNodePairs = nodeList.size() * (nodeList.size() - 1) / 2;
		StopWatch  sw=new StopWatch();
		sw.start();
		Graph graph = makeGraph(nodeList, nodeIdxPairList);
		List<Edge> edgeList = graph.getEdgeList();

		// graph.graphToFile("/home/hadoop/lqh/graph");
		partitioner.setGraph(graph);
		partitioner.setCapacityThreshold(maxCacheSize);
		partitioner.partition();
		int partitionCount = partitioner.getPartitionCount();
		System.out.println("partitionCount = " + partitionCount);
		System.out.println("   make graph    time ***************  "+sw.getTime());
		// add by lqh

		/*long inneredge = 0;
		long interedge = 0;
		for (int ii = 0; ii < edgeList.size(); ii++) {
			Edge edge = edgeList.get(ii);
			Vertex vertex1 = edge.getVertex1();
			Vertex vertex2 = edge.getVertex2();
			if (vertex1.getPartitionIdx() == vertex2.getPartitionIdx()) {

				inneredge++;
			} else
				interedge++;

		}*/
		EdgeComparatorClass edgeComparatorClass = new EdgeComparatorClass();

	//	System.out.println("   inneredge    number   is    " + inneredge
			//	+ "   interedge  number   is  " + interedge);
		/*
		 * for(int ii=0;ii<partitionCount-1;ii++) { List<Vertex>
		 * leftList=partitioner.getVertexListByPartitionIdx(ii); for(int
		 * jj=ii+1;jj<partitionCount-1;jj++) { List<Vertex>
		 * rightList=partitioner.getVertexListByPartitionIdx(jj);
		 * System.out.println("     ii   is  "+ii+ "  jj   is   "+jj);
		 * partitioner.swapTwoPartitions(leftList, rightList);
		 * 
		 * } } inneredge=0; interedge=0; for(int ii=0;ii<edgeList.size();ii++) {
		 * Edge edge=edgeList.get(ii); Vertex vertex1 = edge.getVertex1();
		 * Vertex vertex2 = edge.getVertex2();
		 * if(vertex1.getPartitionIdx()==vertex2.getPartitionIdx()) inneredge++;
		 * else interedge++;
		 * 
		 * } System.out.println("  After   swap  inneredge    number   is    "+
		 * inneredge+"   interedge  number   is  "+interedge);
		 */
		// prune by single node lb and ub
		int countU = 0;
		int upperPruneSingle = 0;
		long times=0;
		long allcomparisonsInNodes=0;
		long comparsionsInNodes=0;
		long alltimes=0;
		for (int i = 0; i < partitionCount; i++) {
		//	System.out.println("find pairs for partition i = " + i);
			List<Vertex> vertexListByPartitionIdx = partitioner
					.getVertexListByPartitionIdx(i);

			// load into cache
			Map<Vertex, double[][]> cache = new HashMap<Vertex, double[][]>();
			Map<Vertex, double[][]> reducedCache = new HashMap<Vertex, double[][]>();
			double rate22=0.0;
			long allPairNow=allPairs.size() / 2;
			for (int j = 0; j < vertexListByPartitionIdx.size(); j++) {
				Vertex curVertex = vertexListByPartitionIdx.get(j);

				// find self pairs
				curVertex.incVisitCount();
				double[][] tss = getVertexTimeSeries(curVertex);
				comparsionsInNodes+=tss.length*(tss.length-1)/2;
				cache.put(curVertex, tss);
				curVertex.incDiskLoadCount();
				curVertex.setInCache(true);

				double[][] reducedTss = reduce(tss);
				reducedCache.put(curVertex, reducedTss);
            	int[] idxArray = idxArrayList.get(curVertex.getId());
				// deal with cur node

				double ub = upperBound((Node) curVertex.getData());
				// double ub1=upperBoundReal((Node)curVertex.getData());
				// double lb1=lowerBoundReal((Node)curVertex.getData());
				
				if (ub <= range) {
					upperPruneSingle+=tss.length*(tss.length-1)/2;
					countU++;
					for (int ii = 0; ii < tss.length; ii++)
						for (int jj = ii + 1; jj < tss.length; jj++) {
							allPairs.append(idxArray[ii], idxArray[jj]);
							
						}
				} else {
					actualNumber += tss.length * (tss.length - 1) / 2;
					comparsionsInNodes+=tss.length * (tss.length - 1) / 2;
					AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(
							idxArray, tss, reducedTss, segmentLength, range,
							allPairs);
				}
				 rate22=((double)allPairs.size() / 2)/(tss.length * (tss.length - 1) / 2);
			}
			rate22=rate22/vertexListByPartitionIdx.size();
            System.out.println("      in   node  all Pairs   "+allPairs.size() / 2+"  effective rate is "+rate22+"   node  size   "+vertexListByPartitionIdx.size()); 
			log.debug("in node allPairs = " + allPairs.size() / 2);
            long allPiarHere=allPairs.size() / 2;
            allcomparisonsInNodes+=(allPiarHere-allPairNow);
          //  System.out.println("Partion   "+i+"     pairs   "+(allPiarHere-allPairNow));
			// for those in the same partition or the partitionId large than
			// currentPartitionId
            double rate3=0.0;
            
			Map<Vertex, List<Vertex>> outerVertexMap = new HashMap<Vertex, List<Vertex>>();
			for (int j = 0; j < edgeList.size(); j++) {
				Edge edge = edgeList.get(j);
				Vertex vertex1 = edge.getVertex1();
				Vertex vertex2 = edge.getVertex2();
				if ((vertex1.getPartitionIdx() == i)
						&& (vertex2.getPartitionIdx() == i)) {
					// within one partition and both in cache
					vertex1.incVisitCount();
					double[][] leftTss = cache.get(vertex1);
					double[][] leftReducedTss = reducedCache.get(vertex1);

					vertex2.incVisitCount();
					double[][] rightTss = cache.get(vertex2);
					double[][] rightReducedTss = reducedCache.get(vertex2);

					int[] leftIdxArray = idxArrayList.get(vertex1.getId());
					int[] rightIdxArray = idxArrayList.get(vertex2.getId());
					actualNumber += leftTss.length * rightTss.length;
					alltimes+= leftTss.length * rightTss.length;
					AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(
							leftTss, rightTss, leftReducedTss, rightReducedTss,
							leftIdxArray, rightIdxArray, range, segmentLength,
							allPairs);

				} else {
					if ((vertex1.getPartitionIdx() == i)
							&& (vertex2.getPartitionIdx() > i)) {
						List<Vertex> vertexes = outerVertexMap.get(vertex2);
						if (vertexes == null) {
							vertexes = new ArrayList<Vertex>();
							outerVertexMap.put(vertex2, vertexes);
						}
						vertexes.add(vertex1);

						// vertex1.incVisitCount();
						// double[][] leftTss = cache.get(vertex1);
						// double[][] leftReducedTss =
						// reducedCache.get(vertex1);
						//
						// vertex2.incVisitCount();
						// vertex2.incDiskLoadCount();
						// double[][] rightTss = getVertexTimeSeries(vertex2);
						// double[][] rightReducedTss = reduce(rightTss);
						//
						// int[] leftIdxArray =
						// idxArrayList.get(vertex1.getId());
						// int[] rightIdxArray =
						// idxArrayList.get(vertex2.getId());
						//
						// AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(leftTss,
						// rightTss, leftReducedTss, rightReducedTss,
						// leftIdxArray, rightIdxArray, range, segmentLength,
						// allPairs);
					} else if ((vertex1.getPartitionIdx() > i)
							&& (vertex2.getPartitionIdx() == i)) {
						List<Vertex> vertexes = outerVertexMap.get(vertex1);
						if (vertexes == null) {
							vertexes = new ArrayList<Vertex>();
							outerVertexMap.put(vertex1, vertexes);
						}
						vertexes.add(vertex2);

						// vertex1.incVisitCount();
						// vertex1.incDiskLoadCount();
						//
						// double[][] leftTss = getVertexTimeSeries(vertex1);
						// double[][] leftReducedTss = reduce(leftTss);
						//
						// vertex2.incVisitCount();
						// double[][] rightTss = cache.get(vertex2);
						// double[][] rightReducedTss =
						// reducedCache.get(vertex2);
						//
						// int[] leftIdxArray =
						// idxArrayList.get(vertex1.getId());
						// int[] rightIdxArray =
						// idxArrayList.get(vertex2.getId());
						//
						// AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(leftTss,
						// rightTss, leftReducedTss, rightReducedTss,
						// leftIdxArray, rightIdxArray, range, segmentLength,
						// allPairs);
					}
				}
			}

			// deal with outerVertexMap
			Set<Map.Entry<Vertex, List<Vertex>>> entries = outerVertexMap
					.entrySet();
			for (Iterator<Map.Entry<Vertex, List<Vertex>>> iterator = entries
					.iterator(); iterator.hasNext();) {
				Map.Entry<Vertex, List<Vertex>> entry = iterator.next();

				Vertex outerVertex = entry.getKey();
				outerVertex.incVisitCount();
				outerVertex.incDiskLoadCount();
				double[][] leftTss = getVertexTimeSeries(outerVertex);
				double[][] leftReducedTss = reduce(leftTss);
				int[] leftIdxArray = idxArrayList.get(outerVertex.getId());
            	List<Vertex> innerVertexList = entry.getValue();
				for (int j = 0; j < innerVertexList.size(); j++) {
					Vertex innerVertex = innerVertexList.get(j);
					innerVertex.incVisitCount();
					double[][] rightTss = cache.get(innerVertex);
					double[][] rightReducedTss = reducedCache.get(innerVertex);
					int[] rightIdxArray = idxArrayList.get(innerVertex.getId());
					actualNumber += leftTss.length * rightTss.length;
					alltimes+= leftTss.length * rightTss.length;
					AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(
							leftTss, rightTss, leftReducedTss, rightReducedTss,
							leftIdxArray, rightIdxArray, range, segmentLength,
							allPairs);
				}
			}
             
			log.debug("allPairs = " + allPairs.size() / 2);
			// System.out.println("allPairs.size() = " + allPairs.size());
			// clear cache tag
			for (int j = 0; j < graph.getVertexList().size(); j++) {
				Vertex vertex = graph.getVertexList().get(j);
				vertex.setInCache(false);
			}
		}
		//long tt=(allPairs.size() / 2)-fornowPairs;
		double rrr=(double)allcomparisonsInNodes/comparsionsInNodes;
		double rrr2=(double)((allPairs.size() / 2)-allcomparisonsInNodes)/alltimes;
		System.out.println("  *** capacity="+this.capacity+" ***   in Nodes   effectiveness  of computations   "+rrr+"  inter nodes   effectiveness  "+rrr2+"   inner size  "+allcomparisonsInNodes);
		double rate2 = (double) countU / nodeList.size();
		//System.out.println(" all size   is   " + allsize);
	//	System.out.println("  node prue by single upper bound "+countU+
		//		"   prune time series   is  " + upperPruneSingle
			//	+ "  node rate  is  " + rate2);
		System.out.println(" actual number is  " + actualNumber
				+ "  rate  is  " + (double) actualNumber
				/ (allsize * (allsize - 1) / 2));
		log.debug("graph vertex visit count:"
				+ graph.getTotalVertexVisitCount());
		log.debug("graph vertex disk load count:"
				+ graph.getTotalVertexDiskLoadCount());
		System.out.println("graph vertex visit count:"
				+ graph.getTotalVertexVisitCount());
		System.out.println("graph vertex disk load count:"
				+ graph.getTotalVertexDiskLoadCount());

	}

	private double[][] getVertexTimeSeries(Vertex vertex) throws IOException {
		Node node = (Node) vertex.getData();
		String fileName = node.getFileName();
		return TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName,
				tsLength);
	}

	public void findAllPairs(AutoExpandIntArray allPairs, double range, int type,boolean basic)
			throws IOException {
		// find pairs in node
		int pruneNodeCount = 0;
		int pruneNumber = 0;
		long acturalNumber = 0;
		long size2 = (nodeList.size() * (nodeList.size() - 1)) / 2;
		//FileWriter fw = new FileWriter("/home/hadoop/lqh/singlenode_out.txt");// ����FileWriter��������д���ַ���
		//FileWriter fw = new FileWriter("c:\\data\\singlenode_out_"+capacity+"_"+segmentSize+".txt");// ����FileWriter��������д���ַ���
		//BufferedWriter bw = new BufferedWriter(fw);
		for (int i = 0; i < idxArrayList.size(); i++) {
		//	double upbound2 = upperBound(nodeList.get(i));
			//double lbboundreal = lowerBoundReal(nodeList.get(i));
			//double ubboundreal=upperBoundReal(nodeList.get(i));
			// System.out.println("  upper bound  of  node "+i+"   is           "+upbound);
		//	bw.write("" +upbound2+"\t"+ lbboundreal + "\t" + ubboundreal + "\t"
			//		+ nodeList.get(i).getSize()+"\t"+nodeList.get(i).getSegmentSize());
	    //	bw.newLine();
			int[] idxArray2 = idxArrayList.get(i);
			if(useUpperBound)
			{
				double upbound = upperBound(nodeList.get(i));
				if (upbound <= range) {
					// add all pairs in the node
	
					pruneNodeCount++;
					pruneNumber += idxArray2.length * (idxArray2.length - 1) / 2;
					for (int ii = 0; ii < idxArray2.length; ii++)
						for (int jj = ii + 1; jj < idxArray2.length; jj++) {
							allPairs.append(idxArray2[ii], idxArray2[jj]);
	
						}
					continue;
				}
			}
			int[] idxArray = idxArrayList.get(i);
			double[][] tss = new double[idxArray.length][];
			double[][] reducedTss = new double[idxArray.length][];

			for (int j = 0; j < idxArray.length; j++) {
				tss[j] = timeSeries[idxArray[j]];
				reducedTss[j] = reducedTimeSeries[idxArray[j]];
			}
			acturalNumber += idxArray2.length * (idxArray2.length - 1) / 2;
			AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, tss,
					reducedTss, segmentLength, range, allPairs);
		}
		//bw.close();
		System.out.println("  the number  of pruning   inner node   is  "
				+ pruneNodeCount + "  time series " + pruneNumber);
		// search the nodeList and get possible node pairs
		log.debug("Begin to find pairs   ");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<int[]> nodeIdxPairList = findNodePairsNew(range, type,basic);
	 //   List<int[]> nodeIdxPairList = findNodePairs(range,type);
		log.debug("nodeIdxPairList.size() = " + nodeIdxPairList.size());
		stopWatch.stop();
		double rate = (double) nodeIdxPairList.size() / size2;
		System.out.println("nodeIdxPairList.size() = " + nodeIdxPairList.size()
				+ "    time    is   " + stopWatch.getTime() + "  rate   is  "
				+ rate);
		// verify the time series between node pair
		long time1 = System.currentTimeMillis();
		for (int i = 0; i < nodeIdxPairList.size(); i++) {
			int[] nodeIdxPair = nodeIdxPairList.get(i);
			int nodeIdx0 = nodeIdxPair[0];
			int nodeIdx1 = nodeIdxPair[1];

			int[] leftIdxArray = idxArrayList.get(nodeIdx0);
			int[] rightIdxArray = idxArrayList.get(nodeIdx1);
			acturalNumber += leftIdxArray.length * rightIdxArray.length;
			if (i % 100000 == 0) {
				long time2 = System.currentTimeMillis();
				long sec = (time1 - time2) / 1000;
				System.out.println("  i  same time  is  " + i + "  time  is  "
						+ sec + "    actual Number  " + acturalNumber);
			}
			AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeSeries,
					reducedTimeSeries, leftIdxArray, rightIdxArray, range,
					segmentLength, allPairs);
		}
        System.out.println("size    is   "+allsize);
		System.out.println("  actural   comparing   count   is   "
				+ acturalNumber + "  rate  is  " + (double) acturalNumber
				/ (allsize * (allsize - 1) / 2));
		System.out.println(" AllPairReduceBruteFinder.lowerBoundCount "
				+ AllPairReduceBruteFinder.lowerBoundCount
				+ "  AllPairReduceBruteFinder.distLessThanCount  "
				+ AllPairReduceBruteFinder.distLessThanCount
				+ "   AllPairReduceBruteFinder.lowerBoundPruneCount  "
				+ AllPairReduceBruteFinder.lowerBoundPruneCount);
	}

	private List<int[]> findNodePairs(double range, int type) {
		List<int[]> ret = new ArrayList<int[]>();
		int count = 0;
		for (int i = 0; i < nodeList.size(); i++) {
			Node node1 = nodeList.get(i);
			node1.setId(i);
			for (int j = i + 1; j < nodeList.size(); j++) {
				Node node2 = nodeList.get(j);
				node2.setId(j);
				double lb = 0.0;
				if (type == 1)
					lb = lowerBound(node1, node2);
				else
					lb = lowerBound_different_segmentsize(node1, node2);

				if (lb <= range) {
					// System.out.println("  lowerbound  is    "+lowerBound(node1,
					// node2));
					ret.add(new int[] { i, j });
				}

			}
		}

		return ret;
	}

	private double upperBound(Node node1) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		NodeSegmentSketch[] nodeSegmentSketches = node1
				.getNodeSegmentSketches();
		for (int i = 0; i < nodeSegmentSketches.length; i++) {
			// nodeSegmentSketch.indicators[0] = Float.MAX_VALUE * -1; //for max
			// mean
			// nodeSegmentSketch.indicators[1] = Float.MAX_VALUE; //for min mean
			// nodeSegmentSketch.indicators[2] = Float.MAX_VALUE * -1; //for max
			// stdev
			// nodeSegmentSketch.indicators[3] = Float.MAX_VALUE; //for min
			// stdev

			double node1MaxAvg = node1.getNodeSegmentSketches()[i].indicators[0];
			double node1MinAvg = node1.getNodeSegmentSketches()[i].indicators[1];
			double node1MaxStd = node1.getNodeSegmentSketches()[i].indicators[2];
			double node1MinStd = node1.getNodeSegmentSketches()[i].indicators[3];
			// System.out.println(" segment   "+i+"  max mean "+node1MaxAvg+"   min   is "+node1MinAvg+"   max std  "+node1MaxStd+"   min std   is  "+node1MinStd);
			int segmentLength1 = node1.getSegmentLength(i);
			sum += ((node1MaxAvg - node1MinAvg) * (node1MaxAvg - node1MinAvg) + (2 * node1MaxStd)
					* (2 * node1MaxStd))
					* segmentLength1;

		}
		sum = Math.sqrt(sum);

		return sum;
	}

	private double upperBoundReal(Node node1) throws IOException {
		double upper = 0.0;
		if (node1.getSize() <= 1) {
			upper = Double.MAX_VALUE;
			return upper;
		}
		String fileName = node1.getFileName();
		double[][] timeseries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		for (int ii = 0; ii < timeseries.length - 1; ii++)
			for (int jj = ii + 1; jj < timeseries.length; jj++) {
				double dis = DistUtil.euclideanDist(timeseries[ii],
						timeseries[jj]);
				if (dis > upper)
					upper = dis;
			}
		return upper;
	}

	private double lowerBoundReal(Node node1) throws IOException {
		double lower = Double.MAX_VALUE;
		if (node1.getSize() <= 1) {
			lower = 0;
			return lower;
		}
		String fileName = node1.getFileName();
		double[][] timeseries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		for (int ii = 0; ii < timeseries.length - 1; ii++)
			for (int jj = ii + 1; jj < timeseries.length; jj++) {
				double dis = DistUtil.euclideanDist(timeseries[ii],
						timeseries[jj]);
				if (dis < lower)
					lower = dis;
			}
		return lower;
	}

	private double upperBoundReal_two(Node node1, Node node2)
			throws IOException {
		double upper = 0.0;
		String fileName = node1.getFileName();
		String fileName2 = node2.getFileName();
		double[][] timeseries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		double[][] timeseries2 = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName2, tsLength);
		for (int ii = 0; ii < timeseries.length; ii++)
			for (int jj = 0; jj < timeseries2.length; jj++) {
				double dis = DistUtil.euclideanDist(timeseries[ii],
						timeseries2[jj]);
				if (dis > upper)
					upper = dis;
			}
		return upper;
	}

	private double lowerBoundReal_two(Node node1, Node node2)
			throws IOException {
		double lower = Double.MAX_VALUE;
		String fileName = node1.getFileName();
		String fileName2 = node2.getFileName();
		double[][] timeseries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		double[][] timeseries2 = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName2, tsLength);
		for (int ii = 0; ii < timeseries.length; ii++)
			for (int jj = 0; jj < timeseries2.length; jj++) {
				double dis = DistUtil.euclideanDist(timeseries[ii],
						timeseries2[jj]);
				if (dis < lower)
					lower = dis;
			}
		return lower;
	}

	private double upperBound(Node node1, Node node2) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		NodeSegmentSketch[] nodeSegmentSketches = node1
				.getNodeSegmentSketches();
		for (int i = 0; i < nodeSegmentSketches.length; i++) {
			// nodeSegmentSketch.indicators[0] = Float.MAX_VALUE * -1; //for max
			// mean
			// nodeSegmentSketch.indicators[1] = Float.MAX_VALUE; //for min mean
			// nodeSegmentSketch.indicators[2] = Float.MAX_VALUE * -1; //for max
			// stdev
			// nodeSegmentSketch.indicators[3] = Float.MAX_VALUE; //for min
			// stdev

			double node1MaxAvg = node1.getNodeSegmentSketches()[i].indicators[0];
			double node1MinAvg = node1.getNodeSegmentSketches()[i].indicators[1];
			double node1MaxStd = node1.getNodeSegmentSketches()[i].indicators[2];
			double node1MinStd = node1.getNodeSegmentSketches()[i].indicators[3];

			double node2MaxAvg = node2.getNodeSegmentSketches()[i].indicators[0];
			double node2MinAvg = node2.getNodeSegmentSketches()[i].indicators[1];
			double node2MaxStd = node2.getNodeSegmentSketches()[i].indicators[2];
			double node2MinStd = node2.getNodeSegmentSketches()[i].indicators[3];

			int segmentLength1 = node1.getSegmentLength(i);

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}

			Range node1StdRange = new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = new Range(node2MinStd, node2MaxStd);

			// double stdDistance = Range.distance(node1StdRange,
			// node2StdRange);
			double stdDistance = node1MaxStd + node2MaxStd;
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}
		}
		sum = Math.sqrt(sum);
		return sum;
	}

	private double lowerBound(Node node1, Node node2) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		NodeSegmentSketch[] nodeSegmentSketches = node1
				.getNodeSegmentSketches();
		for (int i = 0; i < nodeSegmentSketches.length; i++) {
			// nodeSegmentSketch.indicators[0] = Float.MAX_VALUE * -1; //for max
			// mean
			// nodeSegmentSketch.indicators[1] = Float.MAX_VALUE; //for min mean
			// nodeSegmentSketch.indicators[2] = Float.MAX_VALUE * -1; //for max
			// stdev
			// nodeSegmentSketch.indicators[3] = Float.MAX_VALUE; //for min
			// stdev

			double node1MaxAvg = node1.getNodeSegmentSketches()[i].indicators[0];
			double node1MinAvg = node1.getNodeSegmentSketches()[i].indicators[1];
			double node1MaxStd = node1.getNodeSegmentSketches()[i].indicators[2];
			double node1MinStd = node1.getNodeSegmentSketches()[i].indicators[3];

			double node2MaxAvg = node2.getNodeSegmentSketches()[i].indicators[0];
			double node2MinAvg = node2.getNodeSegmentSketches()[i].indicators[1];
			double node2MaxStd = node2.getNodeSegmentSketches()[i].indicators[2];
			double node2MinStd = node2.getNodeSegmentSketches()[i].indicators[3];

			int segmentLength1 = node1.getSegmentLength(i);

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}

			Range node1StdRange = new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = new Range(node2MinStd, node2MaxStd);

			double stdDistance = Range.distance(node1StdRange, node2StdRange);
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}
		}
		sum = Math.sqrt(sum);
		return sum;
	}

	/*
	 * @param node
	 * 
	 * @param end_pre
	 * 
	 * @param end
	 */
	private double addition_item_of_minstd(Node node, int end_pre, int end) {
		Double[] segAvgs = new Double[end - end_pre];
		Integer[] segLens = new Integer[end - end_pre];
		List<Integer> candidate = new ArrayList<Integer>();
		List<Integer> ready = new ArrayList<Integer>();

		double totalAvg = 0.0;
		int totalLen = 0;
		for (int jj = end_pre + 1; jj <= end; jj++) {
			Integer index = jj - end_pre - 1;
			double segAvg = node.getNodeSegmentSketches()[jj].indicators[0];
			int segLen = node.getSegmentLength(jj);

			segAvgs[index] = segAvg;
			segLens[index] = segLen;

			totalAvg += segAvg * segLen;
			totalLen += segLen;
		}
		totalAvg = totalAvg / totalLen;

		int readySegLen = 0;
		double readySum = 0.0;
		for (int jj = end_pre + 1; jj <= end; jj++) {
			Integer index = jj - end_pre - 1;

			if (segAvgs[index] >= totalAvg) {
				// adjust the point bigger than totalAvg
				candidate.add(index);
			} else {
				ready.add(index);
				readySegLen += segLens[index];
				readySum += segAvgs[index] * segLens[index];
			}
		}
		double readyAvg = readySum / readySegLen;

		while (!candidate.isEmpty() && !ready.isEmpty()) {
			double shrinkCoef = 0.0;
			int scIndex = -1;
			// compute the shrink coefficient
			for (int jj = 0; jj < candidate.size(); jj++) {
				Integer index = candidate.get(jj);
				double segAvgMin = node.getNodeSegmentSketches()[index
						+ end_pre + 1].indicators[1];
				double sc = (Math.max(segAvgMin, readyAvg) - readyAvg)
						/ (segAvgs[index] - readyAvg);
				if (sc > shrinkCoef) {
					shrinkCoef = sc;
					scIndex = jj;
				}
			}
			// adjust the value of candidates
			for (int jj = 0; jj < candidate.size(); jj++) {
				Integer index = candidate.get(jj);
				if (scIndex == jj) {
					double tmp = node.getNodeSegmentSketches()[index + end_pre
							+ 1].indicators[1];
					segAvgs[index] = tmp;
				} else
					segAvgs[index] = shrinkCoef * (segAvgs[index] - readyAvg)
							+ readyAvg;
			}

			// totalAvg after adjust, shrink with the same rate!!!
			totalAvg = shrinkCoef * (totalAvg - readyAvg) + readyAvg;

			// recompute candidate and ready sets.
			readySegLen = 0;
			readySum = 0.0;

			candidate.clear();
			ready.clear();

			for (int jj = end_pre + 1; jj <= end; jj++) {
				Integer index = jj - end_pre - 1;

				if (segAvgs[index] >= totalAvg
						&& segAvgs[index] > node.getNodeSegmentSketches()[index
								+ end_pre + 1].indicators[1]) {
					// adjust the point bigger than totalAvg
					candidate.add(index);
				} else {
					ready.add(index);
					readySegLen += segLens[index];
					readySum += segAvgs[index] * segLens[index];
				}
			}
			if (readySegLen > 0) {
				readyAvg = readySum / readySegLen;
				if (readyAvg == totalAvg)
					break;
			}

		}
		/*
		 * double sum=0.0; for(int jj=0; jj<end-end_pre; jj++) {
		 * sum+=segAvgs[jj]*segLens[jj]; }
		 * 
		 * sum=sum/totalLen; if(sum!=totalAvg)
		 * System.out.println("avg true "+sum+" compute avg "+totalAvg);
		 */
		double addStd = 0.0;
		for (int jj = 0; jj < end - end_pre; jj++) {
			double tmp = segAvgs[jj] - totalAvg;
			addStd += segLens[jj] * tmp * tmp;
		}
		return addStd;
	}

	/*
	 * @param node
	 * 
	 * @param end_pre
	 * 
	 * @param end
	 */
	private double addition_item_of_maxstd(Node node, int end_pre, int end) {
		Double[] segMaxAvgs = new Double[end - end_pre];
		Stack<Integer> segValStack = null;
		Double[] segMinAvgs = new Double[end - end_pre];
		Integer[] segLens = new Integer[end - end_pre];

		int totalLen = 0;

		for (int ii = 0; ii < end - end_pre; ii++) {
			segMaxAvgs[ii] = (double) node.getNodeSegmentSketches()[ii
					+ end_pre + 1].indicators[0];
			segMinAvgs[ii] = (double) node.getNodeSegmentSketches()[ii
					+ end_pre + 1].indicators[1];

			int segLen = node.getSegmentLength(ii + end_pre + 1);
			segLens[ii] = segLen;

			totalLen += segLen;
		}

		double[] selval = new double[end - end_pre];
		double addStd = 1000000000;
		for (int ii = 0; ii < (1 << (end - end_pre)); ii++) {
			double meanval = 0.0;
			int jj;

			for (jj = 0; jj < end - end_pre; jj++) {
				if ((ii & (1 << jj)) == 0)
					selval[jj] = segMinAvgs[jj];
				else
					selval[jj] = segMaxAvgs[jj];
				meanval += selval[jj];
			}
			meanval = meanval / totalLen;

			for (jj = 0; jj < end - end_pre; jj++) {
				if ((selval[jj] == segMinAvgs[jj]) && (selval[jj] >= meanval))
					break;
				if ((selval[jj] == segMaxAvgs[jj]) && (selval[jj] <= meanval))
					break;
			}
			if (jj < end - end_pre)
				break;

			double sum = 0.0;
			for (jj = 0; jj < end - end_pre; jj++) {
				double tmp = selval[jj] - meanval;
				sum += segLens[jj] * tmp * tmp;
			}
			if (sum < addStd)
				addStd = sum;
		}

		return addStd;
	}

	private double lowerBound_different_segmentsize(Node node1, Node node2) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		int size1 = node1.getSegmentSize();
		int size2 = node2.getSegmentSize();
		short[] info1 = node1.nodePoints;
		short[] info2 = node2.nodePoints;
		boolean allsame = true;
		if (info1.length == info2.length) {
			for (int ii = 0; ii < info1.length; ii++) {
				if (info1[ii] != info2[ii]) {
					allsame = false;
					break;
				}

			}
			// allsame=true;
		} else
			allsame = false;
		if (allsame) {
			double lb = lowerBound(node1, node2);
			return lb;
		}

		/*
		 * if(size1==size2 && size1==10) { double lb=lowerBound(node1,node2);
		 * return lb; }
		 */

		int length = tsLength;
		int i = 0;
		int j = 0;
		List<int[]> result = new ArrayList();
		while (info1[i] != length || info2[j] != length) {
			while (info1[i] != info2[j]) {
				if (info1[i] > info2[j] && j < (size2 - 1))
					j++;
				else {
					if (i < (size1 - 1))
						i++;
				}

			}
			int end1 = i;
			int end2 = j;
			if (i < (size1 - 1))
				i++;
			if (j < (size2 - 1))
				j++;
			int[] item = new int[2];
			item[0] = end1;
			item[1] = end2;
			result.add(item);
			// System.out.println("  end1   is   "+end1+"  end2   is  "+end2);

		}
		// System.out.println("  common segment   is  "+result.size());

		int info1_start = 0;
		int end1_pre = -1;
		int info2_start = 0;
		int end2_pre = -1;
		for (int ii = 0; ii < result.size(); ii++) {

			if (ii >= 1) {
				int[] item = result.get(ii - 1);
				end1_pre = item[0];
				info1_start = info1[end1_pre];
				end2_pre = item[1];
				info2_start = info2[end2_pre];

			}
			int[] item2 = result.get(ii);
			int end1 = item2[0];
			int end2 = item2[1];
			Range node1AvgRange = null;// new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = null;// new Range(node2MinAvg, node2MaxAvg);
			Range node1StdRange = null;// new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = null;// new Range(node2MinStd, node2MaxStd);
			int segmentLength1 = 0;// initial value
			
		//	System.out.println("All  greate ************"+(end1 - end1_pre)+"  2nd   is "+(end2 - end2_pre));
			if ((end1 - end1_pre) > 1) {
				double node1MaxAvg = 0.0;
				double node1MinAvg = 0.0;
				double node1MaxStd = 0.0;
				double node1MinStd = 0.0;
				// System.out.println("  end1_pre    is   "+end1_pre+"   point is  "+info1[end1_pre]);
				// System.out.println("  end1    is   "+end1_pre+"   point is  "+info1[end1]);
				if ((end1 - end1_pre) == 2) {
					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);

						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;

					double Avgmin1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1];
					double Avgmax1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0];
					double Avgmin2 = node1.getNodeSegmentSketches()[end1].indicators[1];
					double Avgmax2 = node1.getNodeSegmentSketches()[end1].indicators[0];
					if (Avgmin2 > Avgmax1) {
						double temp = Avgmin2 - Avgmax1;
						node1MinStd += (node1.getSegmentLength(end1_pre + 1)
								* node1.getSegmentLength(end1) * temp * temp)
								/ (segmentLength1 * segmentLength1);
						node1MinStd = Math.sqrt(node1MinStd / segmentLength1);
					} else {
						if (Avgmin1 > Avgmax2) {
							double temp = Avgmin1 - Avgmax2;
							node1MinStd += (node1
									.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
									/ (segmentLength1 * segmentLength1);
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						} else {
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						}
					}

					double temp = Math
							.max(Math
									.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0]
											- node1.getNodeSegmentSketches()[end1].indicators[1]),
									Math.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1]
											- node1.getNodeSegmentSketches()[end1].indicators[0]));
					node1MaxStd = node1MaxStd
							/ segmentLength1
							+ (node1.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node1MaxStd = Math.sqrt(node1MaxStd);
				} else {
					double addMinStd = addition_item_of_minstd(node1, end1_pre,
							end1);
					double addMaxStd = addition_item_of_maxstd(node1, end1_pre,
							end1);

					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);
						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;

					node1MinStd = Math.sqrt((node1MinStd + addMinStd)
							/ segmentLength1);
					node1MaxStd = Math.sqrt((node1MaxStd + addMaxStd)
							/ segmentLength1);
				}

				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				target = null;
				long id = node1.id;
				String key = "" + id + "\t" + info1_start + "\t" + info1[end1];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node1, info1_start,
							info1[end1]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info1_start && old[t] == info1[end1]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}
					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);
						// System.out.println(" Parent   min avg  "+nodeMinAvg_o+"  max avg  "+nodeMaxAvg_o+"  min std  "+nodeMinStd_o+"  max  std   "+nodeMaxStd_o);
						// System.out.println("   min avg  "+node1MinAvg+"  max avg  "+node1MaxAvg+"  min std  "+node1MinStd+"  max  std   "+node1MaxStd);

					}
				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);

				}
				
				node1MinAvg = Math.max(nodeMinAvg_o, node1MinAvg);
				node1MaxAvg = Math.min(nodeMaxAvg_o, node1MaxAvg);
				node1MinStd = Math.max(nodeMinStd_o, node1MinStd);
				node1MaxStd = Math.min(nodeMaxStd_o, node1MaxStd);

			} else {
				double node1MaxAvg = node1.getNodeSegmentSketches()[end1].indicators[0];
				double node1MinAvg = node1.getNodeSegmentSketches()[end1].indicators[1];
				double node1MaxStd = node1.getNodeSegmentSketches()[end1].indicators[2];
				double node1MinStd = node1.getNodeSegmentSketches()[end1].indicators[3];
				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				segmentLength1 = node1.getSegmentLength(end1);

			}
			if ((end2 - end2_pre) > 1) {
				double node2MaxAvg = 0.0;
				double node2MinAvg = 0.0;
				double node2MaxStd = 0.0;
				double node2MinStd = 0.0;
                
				if ((end2 - end2_pre) == 2) {
					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);

					}
					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;

					double Avgmin1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1];
					double Avgmax1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0];
					double Avgmin2 = node2.getNodeSegmentSketches()[end2].indicators[1];
					double Avgmax2 = node2.getNodeSegmentSketches()[end2].indicators[0];
					if (Avgmin2 > Avgmax1) {
						double temp = Avgmin2 - Avgmax1;
						node2MinStd += (node2.getSegmentLength(end2_pre + 1)
								* node2.getSegmentLength(end2) * temp * temp)
								/ (segmentLength1 * segmentLength1);
						node2MinStd = Math.sqrt(node2MinStd / segmentLength1);
					} else {
						if (Avgmin1 > Avgmax2) {
							double temp = Avgmin1 - Avgmax2;
							node2MinStd += (node2
									.getSegmentLength(end2_pre + 1)
									* node2.getSegmentLength(end2) * temp * temp)
									/ (segmentLength1 * segmentLength1);
							node2MinStd = Math.sqrt(node2MinStd
									/ segmentLength1);
						} else {
							node2MinStd = Math.sqrt(node2MinStd
									/ segmentLength1);
						}
					}

					double temp = Math
							.max(Math
									.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0]
											- node2.getNodeSegmentSketches()[end2].indicators[1]),
									Math.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1]
											- node2.getNodeSegmentSketches()[end2].indicators[0]));
					node2MaxStd = node2MaxStd
							/ segmentLength1
							+ (node2.getSegmentLength(end2_pre + 1)
									* node2.getSegmentLength(end2) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node2MaxStd = Math.sqrt(node2MaxStd);
				} else {
					double addMinStd = addition_item_of_minstd(node2, end2_pre,
							end2);
					double addMaxStd = addition_item_of_maxstd(node2, end2_pre,
							end2);

					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);
						// segmentLength1+=node1.getSegmentLength(jj);
					}

					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;

					node2MinStd = Math.sqrt((node2MinStd + addMinStd)
							/ segmentLength1);
					node2MaxStd = Math.sqrt((node2MaxStd + addMaxStd)
							/ segmentLength1);
					//System.out.println(" std  min   "+node2MinStd+"  max  "+node2MaxStd);
				}// else

				target = null;
				long id = node2.id;
				String key = "" + id + "\t" + info2_start + "\t" + info2[end2];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node2, info2_start,
							info2[end2]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info2_start && old[t] == info2[end2]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}

					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);

					}

				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);
				}
				node2MinAvg = Math.max(nodeMinAvg_o, node2MinAvg);
				node2MaxAvg = Math.min(nodeMaxAvg_o, node2MaxAvg);
				node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
				node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
			//	System.out.println("  cache  std  min  "+nodeMinStd_o+"  max  "+nodeMaxStd_o);
				if (node2MinAvg > node2MaxAvg) {
					node2MaxAvg = node2MinAvg;
				}
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				if (node2MinStd > node2MaxStd) {
					node2MaxStd = node2MinStd;
				}
				node2StdRange = new Range(node2MinStd, node2MaxStd);

			} else {
				// (end2-end2_pre)==1
				double node2MaxAvg = node2.getNodeSegmentSketches()[end2].indicators[0];
				double node2MinAvg = node2.getNodeSegmentSketches()[end2].indicators[1];
				double node2MaxStd = node2.getNodeSegmentSketches()[end2].indicators[2];
				double node2MinStd = node2.getNodeSegmentSketches()[end2].indicators[3];
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				node2StdRange = new Range(node2MinStd, node2MaxStd);
			}
			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}
			double stdDistance = Range.distance(node1StdRange, node2StdRange);
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}

		}

		sum = Math.sqrt(sum);

		// System.out.println("Different     node  size   common segment   is  "+result.size()+"          distance  is   "+sum);
		return sum;
	}

	
   private double lowerBound_different_segmentsize_basic(Node node1, Node node2) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		int size1 = node1.getSegmentSize();
		int size2 = node2.getSegmentSize();
		short[] info1 = node1.nodePoints;
		short[] info2 = node2.nodePoints;
		boolean allsame = true;
		if (info1.length == info2.length) {
			for (int ii = 0; ii < info1.length; ii++) {
				if (info1[ii] != info2[ii]) {
					allsame = false;
					break;
				}

			}
			// allsame=true;
		} else
			allsame = false;
		if (allsame) {
			double lb = lowerBound(node1, node2);
			return lb;
		}

		/*
		 * if(size1==size2 && size1==10) { double lb=lowerBound(node1,node2);
		 * return lb; }
		 */

		int length = tsLength;
		int i = 0;
		int j = 0;
		List<int[]> result = new ArrayList();
		while (info1[i] != length || info2[j] != length) {
			while (info1[i] != info2[j]) {
				if (info1[i] > info2[j] && j < (size2 - 1))
					j++;
				else {
					if (i < (size1 - 1))
						i++;
				}

			}
			int end1 = i;
			int end2 = j;
			if (i < (size1 - 1))
				i++;
			if (j < (size2 - 1))
				j++;
			int[] item = new int[2];
			item[0] = end1;
			item[1] = end2;
			result.add(item);
			// System.out.println("  end1   is   "+end1+"  end2   is  "+end2);

		}
		// System.out.println("  common segment   is  "+result.size());
//  result represents the alignment  end points for two nodes
		int info1_start = 0;
		int end1_pre = -1;
		int info2_start = 0;
		int end2_pre = -1;
		for (int ii = 0; ii < result.size(); ii++) {

			if (ii >= 1) {
				int[] item = result.get(ii - 1);
				end1_pre = item[0];
				info1_start = info1[end1_pre];
				end2_pre = item[1];
				info2_start = info2[end2_pre];

			}
			int[] item2 = result.get(ii);
			int end1 = item2[0];
			int end2 = item2[1];
			Range node1AvgRange = null;// new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = null;// new Range(node2MinAvg, node2MaxAvg);
			Range node1StdRange = null;// new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = null;// new Range(node2MinStd, node2MaxStd);
			int segmentLength1 = 0;// initial value
			
		//	System.out.println("All  greate ************"+(end1 - end1_pre)+"  2nd   is "+(end2 - end2_pre));
			if ((end1 - end1_pre) > 1) {
				double node1MaxAvg = 0.0;
				double node1MinAvg = 0.0;
				double node1MaxStd = 0.0;
				double node1MinStd = 0.0;
				// System.out.println("  end1_pre    is   "+end1_pre+"   point is  "+info1[end1_pre]);
				// System.out.println("  end1    is   "+end1_pre+"   point is  "+info1[end1]);
				/*if ((end1 - end1_pre) == 2) {
					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);

						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;

					double Avgmin1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1];
					double Avgmax1 = node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0];
					double Avgmin2 = node1.getNodeSegmentSketches()[end1].indicators[1];
					double Avgmax2 = node1.getNodeSegmentSketches()[end1].indicators[0];
					if (Avgmin2 > Avgmax1) {
						double temp = Avgmin2 - Avgmax1;
						node1MinStd += (node1.getSegmentLength(end1_pre + 1)
								* node1.getSegmentLength(end1) * temp * temp)
								/ (segmentLength1 * segmentLength1);
						node1MinStd = Math.sqrt(node1MinStd / segmentLength1);
					} else {
						if (Avgmin1 > Avgmax2) {
							double temp = Avgmin1 - Avgmax2;
							node1MinStd += (node1
									.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
									/ (segmentLength1 * segmentLength1);
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						} else {
							node1MinStd = Math.sqrt(node1MinStd
									/ segmentLength1);
						}
					}

					double temp = Math
							.max(Math
									.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0]
											- node1.getNodeSegmentSketches()[end1].indicators[1]),
									Math.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1]
											- node1.getNodeSegmentSketches()[end1].indicators[0]));
					node1MaxStd = node1MaxStd
							/ segmentLength1
							+ (node1.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node1MaxStd = Math.sqrt(node1MaxStd);
				}
				*/ 
				//else {
				//	double addMinStd = addition_item_of_minstd(node1, end1_pre,
					//		end1);
					//double addMaxStd = addition_item_of_maxstd(node1, end1_pre,
						//	end1);

					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);
						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;

					node1MinStd = Math.sqrt((node1MinStd )
							/ segmentLength1);
					node1MaxStd = Math.sqrt((node1MaxStd )
							/ segmentLength1);
				//}

				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				target = null;
				long id = node1.id;
				String key = "" + id + "\t" + info1_start + "\t" + info1[end1];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node1, info1_start,
							info1[end1]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info1_start && old[t] == info1[end1]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}
					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);
					    System.out.println(" Parent   min avg  "+nodeMinAvg_o+"  max avg  "+nodeMaxAvg_o+"  min std  "+nodeMinStd_o+"  max  std   "+nodeMaxStd_o);
						System.out.println("   min avg  "+node1MinAvg+"  max avg  "+node1MaxAvg+"  min std  "+node1MinStd+"  max  std   "+node1MaxStd);

					}
				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);

				}
				
				node1MinAvg = Math.max(nodeMinAvg_o, node1MinAvg);
				node1MaxAvg = Math.min(nodeMaxAvg_o, node1MaxAvg);
				//node1MinStd = Math.max(nodeMinStd_o, node1MinStd);
				//node1MaxStd = Math.min(nodeMaxStd_o, node1MaxStd);
				//modify by lqh 2016/5/4
				//node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
				//node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
				node1MinStd = nodeMinStd_o;
				node1MaxStd = nodeMaxStd_o;
				//System.out.println();

			} else {
				double node1MaxAvg = node1.getNodeSegmentSketches()[end1].indicators[0];
				double node1MinAvg = node1.getNodeSegmentSketches()[end1].indicators[1];
				double node1MaxStd = node1.getNodeSegmentSketches()[end1].indicators[2];
				double node1MinStd = node1.getNodeSegmentSketches()[end1].indicators[3];
				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				segmentLength1 = node1.getSegmentLength(end1);

			}
			if ((end2 - end2_pre) > 1) {
				double node2MaxAvg = 0.0;
				double node2MinAvg = 0.0;
				double node2MaxStd = 0.0;
				double node2MinStd = 0.0;

			/*	if ((end2 - end2_pre) == 2) {
					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);

					}
					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;

					double Avgmin1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1];
					double Avgmax1 = node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0];
					double Avgmin2 = node2.getNodeSegmentSketches()[end2].indicators[1];
					double Avgmax2 = node2.getNodeSegmentSketches()[end2].indicators[0];
					if (Avgmin2 > Avgmax1) {
						double temp = Avgmin2 - Avgmax1;
						node2MinStd += (node2.getSegmentLength(end2_pre + 1)
								* node2.getSegmentLength(end2) * temp * temp)
								/ (segmentLength1 * segmentLength1);
						node2MinStd = Math.sqrt(node2MinStd / segmentLength1);
					} else {
						if (Avgmin1 > Avgmax2) {
							double temp = Avgmin1 - Avgmax2;
							node2MinStd += (node2
									.getSegmentLength(end2_pre + 1)
									* node2.getSegmentLength(end2) * temp * temp)
									/ (segmentLength1 * segmentLength1);
							node2MinStd = Math.sqrt(node2MinStd
									/ segmentLength1);
						} else {
							node2MinStd = Math.sqrt(node2MinStd
									/ segmentLength1);
						}
					}

					double temp = Math
							.max(Math
									.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0]
											- node2.getNodeSegmentSketches()[end2].indicators[1]),
									Math.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1]
											- node2.getNodeSegmentSketches()[end2].indicators[0]));
					node2MaxStd = node2MaxStd
							/ segmentLength1
							+ (node2.getSegmentLength(end2_pre + 1)
									* node2.getSegmentLength(end2) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node2MaxStd = Math.sqrt(node2MaxStd);
				} 
				*///else {
				//	double addMinStd = addition_item_of_minstd(node2, end2_pre,
					//		end2);
					//double addMaxStd = addition_item_of_maxstd(node2, end2_pre,
						//	end2);

					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);
						// segmentLength1+=node1.getSegmentLength(jj);
					}

					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;

					node2MinStd = Math.sqrt((node2MinStd )
							/ segmentLength1);
					node2MaxStd = Math.sqrt((node2MaxStd )
							/ segmentLength1);
				//}// else

				target = null;
				long id = node2.id;
				String key = "" + id + "\t" + info2_start + "\t" + info2[end2];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node2, info2_start,
							info2[end2]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info2_start && old[t] == info2[end2]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}

					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);

					}

				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);
				}
				node2MinAvg = Math.max(nodeMinAvg_o, node2MinAvg);
				node2MaxAvg = Math.min(nodeMaxAvg_o, node2MaxAvg);
			//modify by lqh 2016/5/4
				//node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
				//node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
				node2MinStd = nodeMinStd_o;
				node2MaxStd = nodeMaxStd_o;
				if (node2MinAvg > node2MaxAvg) {
					node2MaxAvg = node2MinAvg;
				}
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				if (node2MinStd > node2MaxStd) {
					node2MaxStd = node2MinStd;
				}
				node2StdRange = new Range(node2MinStd, node2MaxStd);

			} else {
				// (end2-end2_pre)==1
				double node2MaxAvg = node2.getNodeSegmentSketches()[end2].indicators[0];
				double node2MinAvg = node2.getNodeSegmentSketches()[end2].indicators[1];
				double node2MaxStd = node2.getNodeSegmentSketches()[end2].indicators[2];
				double node2MinStd = node2.getNodeSegmentSketches()[end2].indicators[3];
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				node2StdRange = new Range(node2MinStd, node2MaxStd);
			}
			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}
			double stdDistance = Range.distance(node1StdRange, node2StdRange);
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}

		}

		sum = Math.sqrt(sum);

		// System.out.println("Different     node  size   common segment   is  "+result.size()+"          distance  is   "+sum);
		return sum;
	}
	private double upperBound_different_segmentsize(Node node1, Node node2) {
		double sum = 0;
		// assume the node1 and node2 have the same segmentation
		int size1 = node1.getSegmentSize();
		int size2 = node2.getSegmentSize();
		short[] info1 = node1.nodePoints;
		short[] info2 = node2.nodePoints;
		boolean allsame = true;
		if (info1.length == info2.length) {
			for (int ii = 0; ii < info1.length; ii++) {
				if (info1[ii] != info2[ii]) {
					allsame = false;
					break;
				}

			}
			// allsame=true;
		} else
			allsame = false;
		if (allsame) {
			double lb = upperBound(node1, node2);
			return lb;
		}

		/*
		 * if(size1==size2 && size1==10) { double lb=lowerBound(node1,node2);
		 * return lb; }
		 */

		int length = tsLength;
		int i = 0;
		int j = 0;
		List<int[]> result = new ArrayList();
		while (info1[i] != length || info2[j] != length) {
			while (info1[i] != info2[j]) {
				if (info1[i] > info2[j] && j < (size2 - 1))
					j++;
				else {
					if (i < (size1 - 1))
						i++;
				}

			}
			int end1 = i;
			int end2 = j;
			if (i < (size1 - 1))
				i++;
			if (j < (size2 - 1))
				j++;
			int[] item = new int[2];
			item[0] = end1;
			item[1] = end2;
			result.add(item);
			// System.out.println("  end1   is   "+end1+"  end2   is  "+end2);

		}
		// System.out.println("  common segment   is  "+result.size());

		int info1_start = 0;
		int end1_pre = -1;
		int info2_start = 0;
		int end2_pre = -1;
		for (int ii = 0; ii < result.size(); ii++) {

			if (ii >= 1) {
				int[] item = result.get(ii - 1);
				end1_pre = item[0];
				info1_start = info1[end1_pre];
				end2_pre = item[1];
				info2_start = info2[end2_pre];

			}
			int[] item2 = result.get(ii);
			int end1 = item2[0];
			int end2 = item2[1];
			Range node1AvgRange = null;// new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = null;// new Range(node2MinAvg, node2MaxAvg);
			Range node1StdRange = null;// new Range(node1MinStd, node1MaxStd);
			Range node2StdRange = null;// new Range(node2MinStd, node2MaxStd);
			int segmentLength1 = 0;// initial value
			double node1MaxAvg = 0.0;
			double node1MinAvg = 0.0;
			double node1MaxStd = 0.0;
			double node1MinStd = 0.0;
			if ((end1 - end1_pre) > 1) {

				// System.out.println("  end1_pre    is   "+end1_pre+"   point is  "+info1[end1_pre]);
				// System.out.println("  end1    is   "+end1_pre+"   point is  "+info1[end1]);
				if ((end1 - end1_pre) == 2) {
					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj);

						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;
					node1MinStd = Math.sqrt(node1MinStd / segmentLength1);
					double temp = Math
							.max(Math
									.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[0]
											- node1.getNodeSegmentSketches()[end1].indicators[1]),
									Math.abs(node1.getNodeSegmentSketches()[end1_pre + 1].indicators[1]
											- node1.getNodeSegmentSketches()[end1].indicators[0]));
					node1MaxStd = node1MaxStd
							/ segmentLength1
							+ (node1.getSegmentLength(end1_pre + 1)
									* node1.getSegmentLength(end1) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node1MaxStd = Math.sqrt(node1MaxStd);
				} else {
					for (int jj = end1_pre + 1; jj <= end1; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node1.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node1.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node1.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node1.getNodeSegmentSketches()[jj].indicators[3];
						node1MaxAvg += nodeMaxAvg * node1.getSegmentLength(jj);
						node1MinAvg += nodeMinAvg * node1.getSegmentLength(jj);
						node1MinStd += nodeMinStd * nodeMinStd
								* node1.getSegmentLength(jj);
						double temp = Math.max(Math.abs(node1MaxAvg),
								Math.abs(node1MinAvg));
						node1MaxStd += nodeMaxStd * nodeMaxStd
								* node1.getSegmentLength(jj) + temp * temp
								* node1.getSegmentLength(jj);
						segmentLength1 += node1.getSegmentLength(jj);
					}
					node1MaxAvg = node1MaxAvg / segmentLength1;
					node1MinAvg = node1MinAvg / segmentLength1;
					node1MinStd = Math.sqrt(node1MinStd / segmentLength1);
					double temp2 = Math.min(Math.abs(node1MaxAvg),
							Math.abs(node1MinAvg));
					node1MaxStd = Math.sqrt(node1MaxStd / segmentLength1
							- temp2 * temp2);
				}

				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				target = null;
				long id = node1.id;
				String key = "" + id + "\t" + info1_start + "\t" + info1[end1];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node1, info1_start,
							info1[end1]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info1_start && old[t] == info1[end1]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}
					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);
						// System.out.println(" Parent   min avg  "+nodeMinAvg_o+"  max avg  "+nodeMaxAvg_o+"  min std  "+nodeMinStd_o+"  max  std   "+nodeMaxStd_o);
						// System.out.println("   min avg  "+node1MinAvg+"  max avg  "+node1MaxAvg+"  min std  "+node1MinStd+"  max  std   "+node1MaxStd);

					}
				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);

				}
				node1MinAvg = Math.max(nodeMinAvg_o, node1MinAvg);
				node1MaxAvg = Math.min(nodeMaxAvg_o, node1MaxAvg);
				node1MinStd = Math.max(nodeMinStd_o, node1MinStd);
				node1MaxStd = Math.min(nodeMaxStd_o, node1MaxStd);

			} else {
				node1MaxAvg = node1.getNodeSegmentSketches()[end1].indicators[0];
				node1MinAvg = node1.getNodeSegmentSketches()[end1].indicators[1];
				node1MaxStd = node1.getNodeSegmentSketches()[end1].indicators[2];
				node1MinStd = node1.getNodeSegmentSketches()[end1].indicators[3];
				node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
				node1StdRange = new Range(node1MinStd, node1MaxStd);
				segmentLength1 = node1.getSegmentLength(end1);

			}
			double node2MaxAvg = 0.0;
			double node2MinAvg = 0.0;
			double node2MaxStd = 0.0;
			double node2MinStd = 0.0;
			if ((end2 - end2_pre) > 1) {

				if ((end2 - end2_pre) == 2) {
					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj);

					}
					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;
					node2MinStd = Math.sqrt(node2MinStd / segmentLength1);
					double temp = Math
							.max(Math
									.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[0]
											- node2.getNodeSegmentSketches()[end2].indicators[1]),
									Math.abs(node2.getNodeSegmentSketches()[end2_pre + 1].indicators[1]
											- node2.getNodeSegmentSketches()[end2].indicators[0]));
					node2MaxStd = node2MaxStd
							/ segmentLength1
							+ (node2.getSegmentLength(end2_pre + 1)
									* node2.getSegmentLength(end2) * temp * temp)
							/ (segmentLength1 * segmentLength1);
					node2MaxStd = Math.sqrt(node2MaxStd);
				} else {
					for (int jj = end2_pre + 1; jj <= end2; jj++) {
						// merge the segments from end1_pre+1 to end1
						double nodeMaxAvg = node2.getNodeSegmentSketches()[jj].indicators[0];
						double nodeMinAvg = node2.getNodeSegmentSketches()[jj].indicators[1];
						double nodeMaxStd = node2.getNodeSegmentSketches()[jj].indicators[2];
						double nodeMinStd = node2.getNodeSegmentSketches()[jj].indicators[3];
						node2MaxAvg += nodeMaxAvg * node2.getSegmentLength(jj);
						node2MinAvg += nodeMinAvg * node2.getSegmentLength(jj);
						node2MinStd += nodeMinStd * nodeMinStd
								* node2.getSegmentLength(jj);
						double temp = Math.max(Math.abs(nodeMaxAvg),
								Math.abs(nodeMinAvg));
						node2MaxStd += nodeMaxStd * nodeMaxStd
								* node2.getSegmentLength(jj) + temp * temp
								* node2.getSegmentLength(jj);
						// segmentLength1+=node1.getSegmentLength(jj);
					}
					node2MaxAvg = node2MaxAvg / segmentLength1;
					node2MinAvg = node2MinAvg / segmentLength1;
					node2MinStd = Math.sqrt(node2MinStd / segmentLength1);
					double temp2 = Math.min(Math.abs(node2MaxAvg),
							Math.abs(node2MinAvg));
					node2MaxStd = Math.sqrt(node2MaxStd / segmentLength1
							- temp2 * temp2);
				}

				target = null;
				long id = node2.id;
				String key = "" + id + "\t" + info2_start + "\t" + info2[end2];
				Object value = cache.get(key);
				double nodeMaxAvg_o = 0.0;
				double nodeMinAvg_o = 0.0;
				double nodeMaxStd_o = 0.0;
				double nodeMinStd_o = 0.0;
				if (value == null) {
					boolean tt = findCloseParent(root, node2, info2_start,
							info2[end2]);
					// find the segment in the original
					short[] old = target.nodePoints;
					int same = -1;
					for (int t = 0; t < old.length; t++) {
						// System.out.println("  444444444    "+old[t]+"  start "+info1[end1_pre+1]+"  end  "+info1[end1]);
						int old_start = 0;
						if (t > 0)
							old_start = old[t - 1];
						if (old_start == info2_start && old[t] == info2[end2]) {
							same = t;
							// System.out.println(" 11111111111111111111111  "+node1.id+"   node2   "+node2.id);
							break;
						}
					}

					if (same != -1) {
						nodeMaxAvg_o = target.getNodeSegmentSketches()[same].indicators[0];
						nodeMinAvg_o = target.getNodeSegmentSketches()[same].indicators[1];
						nodeMaxStd_o = target.getNodeSegmentSketches()[same].indicators[2];
						nodeMinStd_o = target.getNodeSegmentSketches()[same].indicators[3];
						String vv = "" + nodeMinAvg_o + "\t" + nodeMaxAvg_o
								+ "\t" + nodeMinStd_o + "\t" + nodeMaxStd_o;
						cache.put(key, vv);

					}

				} else {
					String values = (String) value;
					String items[] = values.split("\t");
					nodeMinAvg_o = Double.parseDouble(items[0]);
					nodeMaxAvg_o = Double.parseDouble(items[1]);
					nodeMinStd_o = Double.parseDouble(items[2]);
					nodeMaxStd_o = Double.parseDouble(items[3]);
					// System.out.println("**************88   "+nodeMaxStd_o);
				}
				node2MinAvg = Math.max(nodeMinAvg_o, node2MinAvg);
				node2MaxAvg = Math.min(nodeMaxAvg_o, node2MaxAvg);
				node2MinStd = Math.max(nodeMinStd_o, node2MinStd);
				node2MaxStd = Math.min(nodeMaxStd_o, node2MaxStd);
				if (node2MinAvg > node2MaxAvg) {
					node2MaxAvg = node2MinAvg;
				}
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				if (node2MinStd > node2MaxStd) {
					node2MaxStd = node2MinStd;
				}
				node2StdRange = new Range(node2MinStd, node2MaxStd);

			} else {
				// (end2-end2_pre)==1
				node2MaxAvg = node2.getNodeSegmentSketches()[end2].indicators[0];
				node2MinAvg = node2.getNodeSegmentSketches()[end2].indicators[1];
				node2MaxStd = node2.getNodeSegmentSketches()[end2].indicators[2];
				node2MinStd = node2.getNodeSegmentSketches()[end2].indicators[3];
				node2AvgRange = new Range(node2MinAvg, node2MaxAvg);
				node2StdRange = new Range(node2MinStd, node2MaxStd);
			}
			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength1;
			}
			// double stdDistance = Range.distance(node1StdRange,
			// node2StdRange);
			double stdDistance = node1MaxStd + node2MaxStd;
			if (stdDistance != 0) {
				sum += stdDistance * stdDistance * segmentLength1;
			}

		}

		sum = Math.sqrt(sum);

		// System.out.println("Different     node  size   common segment   is  "+result.size()+"          distance  is   "+sum);
		return sum;
	}

	public Graph makeGraph(List<Node> nodes, List<int[]> nodePairs) {
		List<Vertex> vertexList = new ArrayList<Vertex>();
		Map<Integer, Vertex> vertexMap = new HashMap<Integer, Vertex>();
		for (int i = 0; i < nodes.size(); i++) {
			Node node = nodes.get(i);
			Vertex vertex = new Vertex(i, "" + i, node.getSize(), node);
			vertexList.add(vertex);
			vertexMap.put(vertex.getId(), vertex);
		}

		List<Edge> edgeList = new ArrayList<Edge>();
		for (int i = 0; i < nodePairs.size(); i++) {
			int[] ids = nodePairs.get(i);
			Vertex vertex1 = vertexMap.get(ids[0]);
			Vertex vertex2 = vertexMap.get(ids[1]);
			Edge edge = new Edge(vertex1, vertex2);
			edgeList.add(edge);
		}
		Graph graph = new Graph(vertexList, edgeList);
		boolean checkValid = graph.checkValid();
		System.out.println("graph checkValid = " + checkValid);
		return graph;
	}

}
