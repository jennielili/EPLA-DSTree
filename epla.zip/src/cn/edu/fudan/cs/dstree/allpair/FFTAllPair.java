package cn.edu.fudan.cs.dstree.allpair;
import java.util.*;
import java.io.*;
public class FFTAllPair {

	/**
	 * @param args
	 */
	public  int n=1024;
	public  int m=100000;
	public  complex[][] values=new complex[m][n];
    public  complex[][] dft_values=new complex[m][n];
    public  complex[][] norm_values2=new complex[m][n];
    public  complex[][] norm_values=new complex[m][n];
    public  complex[][] norm_dft_values=new complex[m][n];
//    public int[][] booleanMatrix=new int[m][m];
    public void generateTSfile(complex[][] dft_values,int m,int n,int fileId) throws IOException
    {
//    	String filename="d:\\testdata\\file"+fileId+".txt";
//    	FileWriter fw = new FileWriter(
//				filename);// ����FileWriter��������д���ַ���
//    	BufferedWriter bw = new BufferedWriter(fw); // ��������ļ������
    	String content="";
    	for(int i=0;i<m;i++)
    	{
    		content=""+fileId+" "+i;
    		for(int j=0;j<n;j++)
    		{
    			content+=" "+dft_values[i][j].r+" "+dft_values[i][j].i;
    			
    		}
    		content=content+"\n";
    	//	bw.write(content);
    	//	System.out.println("  content    is   "+content);
    	}
    //	bw.close();	
    	
    }
    public void generateTSfile_original(complex[][] dft_values,int m,int n,int fileId) throws IOException
    {
    	MyFFT dft=new MyFFT();
    	for(int ii=0;ii<100;ii++)
			for(int jj=ii;jj<100;jj++)
			{
				if(ii==998 && jj==999)
				{
					double dist3=dft.Edistance(dft_values[ii], dft_values[jj],128);
					System.out.println(ii+"    "+jj+"   "+dist3);
				}
			}
	//	double dist4=dft.Edistance(ori_values[ii], ori_values[jj],128);
    	String filename="d:\\testdata\\file_o"+fileId+".txt";
    	FileWriter fw = new FileWriter(
				filename);// ����FileWriter��������д���ַ���
    	BufferedWriter bw = new BufferedWriter(fw); // ��������ļ������
    	String content="";
    	for(int i=0;i<m;i++)
    	{
    		content=""+fileId+" "+i;
    		for(int j=0;j<n;j++)
    		{
    			content+=" "+dft_values[i][j].r;
    			
    		}
    		content=content+"\n";
    		if(i==998)
    		System.out.println("   id   is  "+i+"   original     is   "+content);
    		bw.write(content);
    	//	System.out.println("  content    is   "+content);
    	}
    	bw.close();	
    	
    }
    public int[][] booleanApproximation( complex[][] dft_values,double t,int m)
    {
    	int[][] booleanMatrix=new int[m][m];
    	double[][] UB=new double[m][m];
    	double[][] LB=new double[m][m];
    	for(int i=0;i<m;i++)
    		for(int j=0;j<m;j++)
    		{
    			UB[i][j]=Long.MAX_VALUE;
    			LB[i][j]=0;
    		}
    	for(int i=0;i<m-1;i++)
    	{
    		double dis=MyFFT.Pdistance(dft_values[i], dft_values[i+1], n);
    	//	System.out.println("dis    is  22222222222222222222222  "+dis);
    		UB[i][i+1]=dis;
    		LB[i][i+1]=dis;
    		if(dis<t)
    			booleanMatrix[i][i+1]=1;
    		else
    			booleanMatrix[i][i+1]=0;
    	}
    //	System.out.println("  Step 1 *****************************       done ");
    	for(int k=2;k<m;k++)
    		for(int i=0;i<m-k;i++)
    		{
    			int j=i+k;
    			double max=Long.MIN_VALUE;
    			double min=Long.MAX_VALUE;
    			for(int v=i+1;v<j;v++)
    			{
    				double temp=UB[i][v]+UB[v][j];
    				double temp2=Math.max(LB[i][v]-UB[v][j], LB[j][v]-UB[v][i]);
    			//	System.out.println(" temp   is  "+temp+"    i    "+i+"     j   "+j+"   v     "+v);
    				if(temp<=min)
    					min=temp;
    				if(temp2>max)
    				    max=temp2;
    			}
    			if(min<=t)
    			{
    				//System.out.println("111111111111111111111111111     is  "+min);
    				booleanMatrix[i][j]=1;
    			}
    			if(max>=t)
    			{
    				//System.out.println("222222222222222222222222222     is  "+max);
    				booleanMatrix[i][j]=0;
    			}
    			if(min>t && max<t)
    			{
    				double temp=UB[i][j]=LB[i][j]=MyFFT.Pdistance(dft_values[i], dft_values[j], n);
    				if(temp<=t)
    					booleanMatrix[i][j]=1;
    				else
    					booleanMatrix[i][j]=0;
    			}
    		//	System.out.println("  Step 2   **************************** "+i);
    			
    		}
    	return  booleanMatrix;
    }
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FFTAllPair ga=new FFTAllPair();
        Random ran=new Random();
        List<List<Double>> nums=new ArrayList();
        List<Double> nums2=new ArrayList();
        List<List<Double>> nums_norm=new ArrayList();
        List<Double> nums2_norm=new ArrayList();
        int n=ga.n;
        int m=ga.m;
        double t=5.0;
      /*  for(int i=0;i<m;i++)
        {
        	List<Double> ele=new ArrayList();
        	double previous=0.0;
	        for(int ii=0;ii<n;ii++)
	        {
	        	
	        	double gau=ran.nextGaussian()+previous;
	        	previous=gau;
	        	ele.add(gau);
	        	//ga.values[i][ii]=new complex();
	        	ga.values[i][ii]=new complex(gau,0);
	        	
	     //   	System.out.println("gau    is    "+gau);
	        }
	        nums.add(ele);
        }
        
        for(int i=0;i<m;i++)
        {
        	double sum=0.0;
        	double mean=Tool.mean(nums.get(i));      
        	double dev=Tool.deviation(nums.get(i));
        	double  devroot=Math.sqrt(dev);
        	List<Double> ele=new ArrayList();
	        for(int ii=0;ii<n;ii++)
	        {
	        	
	        	double gau=(nums.get(i).get(ii)-mean)/devroot;
	        	sum+=gau*gau;
	        	ele.add(gau);
	        	//ga.values[i][ii]=new complex();
	        	ga.norm_values[i][ii]=new complex(gau,0);
	        	ga.norm_values2[i][ii]=new complex(gau,0);
	        	
	        	//System.out.println("gau   norm  is    "+gau);
	        }
	        nums_norm.add(ele);
	    //    System.out.println("    the  sum  *********************** 1111***********    is  "+sum/n);
        }
        */
        MyFFT dft=new MyFFT();
        for(int i=0;i<m;i++)
        {
        //	 mf.b=mf.changedLow(mf.b,n);
        	 //ga.values[i]=dft.changedLow(ga.values[i],n);
        	// ga.dft_values[i]=dft.fft_2(ga.values[i],n,1);
        	 ga.values[i]=dft.changedLow(ga.norm_values[i],n);
        	 ga.dft_values[i]=dft.fft_2(ga.values[i],n,1); 
        	
        }
        int count=0;
        int count2=0;
        double edis1=-1;
        long time5=System.currentTimeMillis();
        for(int i=0;i<m;i++)
        {   
        	if(i%1000==0)
        		System.out.println("   i    is   "+i+"   count    is    "+count);
        	for(int j=i+1;j<m;j++)
        	{
        		edis1=dft.Edistance(ga.norm_values2[i],ga.norm_values2[j],n);
        		if(edis1<t)
        			count++;
          	}
        }
        long time6=System.currentTimeMillis();
        System.out.println("  Now count **************   "+count+"  time  is "+(time5-time6)/1000);
        count=0;
        int skip=0;
        double tt=t*32;
        for(int i=0;i<m;i++)
        {   
        	if(i%1000==0)
        		System.out.println("   i    is   "+i+"   count    is    "+count);
        	for(int j=i+1;j<m;j++)
        	{
        		//edis1=dft.Edistance(ga.norm_values2[i],ga.norm_values2[j],n);
        		double edis2=dft.Edistance(ga.dft_values[i],ga.dft_values[j],50);
        		//boolean temp3=dft.DFT_LessThan(ga.dft_values[i],ga.dft_values[j],100,(t*32)*(t*32));
        		//System.out.println("   the  dis    is   "+edis1+"    the   dis after  dft   is   "+edis2/32);
        		if(edis2>tt)
        	//	if(!temp3)
        		{
        			skip++;
        			continue;
        			
        		}
        		else
        		{
        			edis2=dft.Edistance(ga.dft_values[i],ga.dft_values[j],n);
        			if(edis2<tt)
            			count++;
        			
        		}
        		
        		
        	     	
             }
        }
        long time4=System.currentTimeMillis();
    	long inter3=time6-time4;
    	System.out.println("   take   time  **************   "+inter3+"   count  is  "+count+"   count2    is  "+count2+"  skip   is  "+skip);
     //   System.out.println("   the  mean    is    "+Tool.mean(nums.get(0)));
     //   System.out.println("   the  deviation   is   "+Tool.deviation(nums.get(0)));
     // ga.generateTSfile(ga.dft_values, m, n, 0); 
    //    ga.generateTSfile(ga.dft_values, m, n, 1); 
     //   ga.generateTSfile_original(ga.norm_values, m, n, 0); 
     //   ga.generateTSfile_original(ga.norm_values, m, n, 1); 
      //  int[][]  result=ga.booleanApproximation(ga.dft_values,400.00,m);
    /*    for(int i=0;i<m;i++)
        	for(int j=0;j<m;j++)
        		if(result[i][j]==1)
        		{
        			double dis=dft.Edistance(ga.dft_values[i],ga.dft_values[j],n);
        			System.out.println("  ********************   i   "+i+"    j  "+j+"    "+result[i][j]+"   dis    is  "+dis);
        		}
      */  
	}
	

}
