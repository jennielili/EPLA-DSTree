package cn.edu.fudan.cs.dstree.allpair;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class LPA_normal_window {

	/**
	 * @param args
	 */
	static HashMap mm=new HashMap();
	public static Integer number=100; 
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		for(int gg=1;gg<20;gg++)
		{
		
		
		 BufferedReader bb=new BufferedReader(new FileReader("D:\\cygwin_install\\home\\lqh\\hash"+(gg-1)+".txt"));
		 FileWriter fw = new FileWriter(
			"D:\\cygwin_install\\home\\lqh\\hash"+gg+".txt");// ����FileWriter��������д���ַ���
		 BufferedWriter bw = new BufferedWriter(fw); // ��������ļ������
		 long time5 = System.currentTimeMillis();
		 int ii=0;
		    String newLine="";
		    String[] values=new String[2];
		    while(bb.ready())
			{
				newLine=bb.readLine();
				//System.out.println("new  line   is  "+newLine);
				if(newLine!=null && !newLine.trim().equals(""))
				{
					//System.out.println("the size  is  "+);
			    	values=newLine.split("\t");
			    	if(values.length>1)
			    	{
			    	//	System.out.println("key   is  "+values[0]  +"  value  is "+values[1]);
			    	    mm.put(values[0].trim(), values[1].trim());
			    	    ii++;
			    	}
			    	
				}
				
			}
		   bb.close();
		   System.out.println("   mm   size    is  "+mm.size());
		   BufferedReader aab =new BufferedReader(new FileReader("D:\\cygwin_install\\home\\lqh\\hadoop_bak\\input_livejournal\\livejournal_all.txt"));
		//    BufferedReader aab =new BufferedReader(new FileReader("/home/hadoop/input.txt"));
			int jj=0;
			String newLine2="";
			String u="";
			HashMap map1 = new HashMap();
			int kk=0;
		    int[] counts_vertexes=new int[100];
		    int[] full_indicator=new int[100];
			while(aab.ready())
			{
				kk++;
				newLine2=aab.readLine();
		      //  System.out.println("   newLine    is   "+newLine2);
				String[] values2=newLine2.split("\t");
				int key=Integer.parseInt(values2[0].trim());
				String[] record = values2[1].toString().split(" ");
				if (record.length < 2)
					continue;
              //  System.out.println("   the   length  of record     is   "+record.length);
				// from map get community ID , and give a maxmal one
				int count = record.length;
				int[] nei = new int[count];
				List aa = new ArrayList();
				Random ran=new Random();
				// ��һ���б���ʾ�ھ������ڵ�����id����
				for (int i = 0; i < count; i++) {
					 u = (String) mm.get(record[i].trim());
					if (!(u == null) && ! (u.equals("")))
						aa.add(u);
					else
					{
						System.out.println("should not be here ***************");
					}
				}
			//	int mm = 0;
				Iterator tt = aa.iterator();
				map1.clear();
				// map1 �����ھ����ڵ�����id���Ӧ����Ŀ
				while (tt.hasNext()) {
					 u = (String) tt.next();
					// System.out.println("   u    is  "+u);
					if (map1.containsKey(u)) {
						Integer val = (Integer) map1.get(u);
						val = val + 1;
						map1.put(u, val);
					} else
						map1.put(u, 1);

				}
				int max = 0;
				Set set = map1.keySet();
				Iterator it = set.iterator();
				String id = new String();
				String pre2=new String();
				while (it.hasNext()) {
					String uu = (String)it.next();
					//if the community of uu is full, remove it 
					if(full_indicator[Integer.parseInt(uu)]==1)
						continue;
					int va = (Integer)map1.get(uu);
					if (va > max) {
					  	max = va;
						id = uu;
					}
				}
				// control the size  
				int mmax=100000;
				if(id.equals(""))
				{
					//System.out.println("  record     is     "+newLine2);
					String comm=(String)mm.get(values2[0].trim());
					bw.write(values2[0].trim()+"\t"+comm);
					continue;
				}
				if(counts_vertexes[Integer.parseInt(id)]< mmax)
				{
					bw.write(values2[0].trim()+"\t"+id);
					counts_vertexes[Integer.parseInt(id)]++;
				}
				else
				{
					id=ran.nextInt(number)+"";
					bw.write(values2[0].trim()+"\t"+id);
					full_indicator[Integer.parseInt(id)]=1;
				}
			//	System.out.println(" normal   "+values2[0].trim()+"\t"+id);w
				if(kk%10000==0)
					System.out.println("             kk       is      "+kk);
				bw.newLine();
				
			}
			System.out.println("2222222222222222222222222222222222222   "+kk);
			bw.close();
			aab.close();
			long time4 = System.currentTimeMillis();
			long inter3 = time5 - time4;
			System.out
					.println("****************the  time   of  iteration     is  "
							+ inter3 / (1000 * 60) +"  mins");
			System.out
			.println("****************the  time   of  iteration    is  "
					+ inter3 / (1000 ) +"  seconds");
			System.out.println("       mm          size     is   "+mm.size());

	     }
	}

}
