package cn.edu.fudan.cs.dstree.allpair;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.edu.fudan.cs.dstree.data.GaussianGenerator;
import cn.edu.fudan.cs.dstree.data.RandomSeriesGenerator;
import cn.edu.fudan.cs.dstree.data.RandomWalkGenerator;
import cn.edu.fudan.cs.dstree.data.SegmentGaussianGenerator;
import cn.edu.fudan.cs.dstree.data.SineGenerator;
import cn.edu.fudan.cs.dstree.dynamicsplit.FileBufferManager;
import cn.edu.fudan.cs.dstree.dynamicsplit.INodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.StdevNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevNodeSegmentSketchUpdater;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevRange;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.partition.FMPartitioner;
import cn.edu.fudan.cs.dstree.partition.PreorderPartitioner;
import cn.edu.fudan.cs.dstree.partition.RandomPartitioner;
import cn.edu.fudan.cs.dstree.partition.Partitioner;
import cn.edu.fudan.cs.dstree.util.CpuUsage;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;

public class LQHTestDSTree_different_segmentsize_disk {
	private static final Log log = LogFactory
			.getLog(DSTreeAllPairFinderTest.class);
	//public static String fileName = "c:\\data\\ucibinary";
	// public static String fileName = "/home/hadoop/lqh/ucibinary";
    public static String fileName = "c:\\data\\tao_normalize20";
	public static int threshold = 300;
	public static double range = 1.2;
	public static int segmentSize = 8;
	// public static int tsLength = 20;
	public static int tsLength = 512;
	public static long size = 10000;
	public static int tradeoff = 100;
	public static int partitionCount = 1000;
	public static List<Node> nodeList = new ArrayList();
	public static boolean basic=false;

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		long time_start = CpuUsage.getInstance().getCurrentCPUTime();
		long time1 = System.currentTimeMillis();
		System.out.println("  Usage:  java -Xms256m  -Xmx18192m -jar dstree.jar threshold range tsLength partitionCount size tradeoff basic");
		range = Double.parseDouble(args[1]);
		threshold = Integer.parseInt(args[0]); // capacity
		tsLength = Integer.parseInt(args[2]);
		// size = Integer.parseInt(args[3]);
		partitionCount = Integer.parseInt(args[3]);
		size = Integer.parseInt(args[4]);
		tradeoff = Integer.parseInt(args[5]);
		int isBasic=Integer.parseInt(args[6]);
		if(isBasic==1)
			basic=true;
		//fileName="/home/hadoop/lqhdata/tao_normalize20";
		//fileName = "c:\\data\\Series_1000_100000.z.bin";
		 fileName="/home/hadoop/lqhdata/ucibinary";
		// fileName="c:\\data\\billionSeries_256_1000.z.bin";
		// fileName = "/home/hadoop/lqh/Series_" + tsLength + "_" + size
		// + ".z.bin";
		// fileName="/home/hadoop/lqh/tao_new22";
		// fileName = "c:\\data\\tao_new_original20";
		// fileName="c:\\data\\Series_"+tsLength+"_"+size+".z.bin";
		System.out.println("   threshold range tsLength size");
		System.out.println(" dis threshold  is " + range
				+ "  node capacity  is  " + threshold);
		testBuildTree();
		// size=670878;
		long time2 = System.currentTimeMillis();
		long ttt = (time1 - time2) / 1000;
		System.out.println("   create tree use seconds    .................."
				+ ttt);
		testFindPairs();
		long time3 = System.currentTimeMillis();
		long all = (time3 - time1) / 1000;
		int page = Integer.parseInt(args[0]);
		long time_end = CpuUsage.getInstance().getCurrentCPUTime();
		System.out.println("   All time  seconds    .................." + all
				+ "  cpu time  is  " + (time_end - time_start) / 1000);
	}

	public static void testBuildTree() throws IOException,
			ClassNotFoundException {

		// Node.hsTradeOffFactor = 30000;
		Node.hsTradeOffFactor = tradeoff;
		SystemInfoUtils systemInfoUtils = new SystemInfoUtilsImpl();
		double bufferedMemorySize = systemInfoUtils.getTotalMemory() * 0.6; // 0.6
																			// for
																			// buffer
		buildDSTreeFromBinaryDataFile(fileName, null, threshold, segmentSize,
				bufferedMemorySize, -1, tsLength);
		System.out.println("Finished!!!");
	}

	public static void testFindPairs() throws IOException,
			ClassNotFoundException {

		// double range =42.667;
		double paaReduceRatio = 0.01;
		DSTreeAllPairFinder_lqh_exact_basic dsTreeAllPairFinder = new DSTreeAllPairFinder_lqh_exact_basic();
		// String index = "d:\\ucibinary.idx_dyn_"+threshold+"_10\\root.idx";
		String index = fileName + ".idx_dyn_" + threshold + "_" + segmentSize
				+ "\\root.idx";
		dsTreeAllPairFinder.setTsLength(tsLength);
		dsTreeAllPairFinder.setUseUpperBound(true);
		dsTreeAllPairFinder.setSegmentSize(segmentSize);
		dsTreeAllPairFinder.loadIndexAndData(index);
		dsTreeAllPairFinder.setCapacity(threshold);
		dsTreeAllPairFinder.setAllsize(size);

		System.out.println("  *****************   size  is  " + size);

		AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		// Partitioner partitioner = new FMPartitioner();
		Partitioner partitioner = new PreorderPartitioner();
		// Partitioner partitioner = new RandomPartitioner();
		partitioner.setPartitionCount(partitionCount);
		// partitionCount=32;
		int maxCacheSize = (int) (size * 1.0 / partitionCount * 1.2); // 1.01 is

		dsTreeAllPairFinder.findAllPairsWithPartition(allPairs, range,
				maxCacheSize, partitioner, 2,basic);
		stopWatch.stop();
		System.out.println("  Random   find  all pairs   time   is  "
				+ stopWatch.getTime());
		log.debug("stopWatch.getTime() = " + stopWatch.getTime());
		System.out
				.println("*****************             stopWatch.getTime() = "
						+ stopWatch.getTime());
		long size2 = allPairs.size() / 2;
		double selectivity = (double) size2 / (size * (size - 1) / 2);
		System.out.println("allPairs = " + size2 + "   selectivity  is "
				+ selectivity);

		// List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
		// Collections.sort(pairs);
		// System.out.println(" Using ********* dstree the  size of allpairs    is   "+pairs.size());
		// AllPairUtils.savePairList2File(pairs, fileName + ".DSTreePairs.txt");

	}

	public static void buildDSTreeFromBinaryDataFile(String fileName,
			String indexPath, int threshold, int segmentSize,
			double bufferedMemorySize, long maxTsCount, int tsLength)
			throws IOException, ClassNotFoundException {
		System.out.println("fileName = " + fileName);
		System.out.println("tsLength = " + tsLength);
		FileBufferManager.fileBufferManager = null;
		FileBufferManager.getInstance().tsLength = tsLength;
		FileBufferManager.getInstance().setBufferedMemorySize(
				bufferedMemorySize);
		FileBufferManager.getInstance().setThreshold(threshold);

		// init indexPath if null
		if (indexPath == null)
			indexPath = fileName;
		indexPath = indexPath + ".idx_dyn";
		indexPath = indexPath + "_" + threshold + "_" + segmentSize;
		if (maxTsCount > 0) {
			indexPath = indexPath + "_" + maxTsCount;
		}
		System.out.println("indexPath = " + indexPath);
		File file = new File(indexPath);
		if (file.exists()) {
			System.out.println("indexPath: " + indexPath
					+ " exists! cleaning...");
			FileUtils.cleanDirectory(file);
		} else {
			boolean b = file.mkdirs();
		}

		Node root = new Node(indexPath, threshold);

		// init helper class instances
		INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[2];
		nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
		nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
		root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

		MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
		root.setSeriesSegmentSketcher(seriesSegmentSketcher);
		root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(
				seriesSegmentSketcher));

		root.setRange(new MeanStdevRange());

		// calc the split points by segmentSize
		short[] points = IndexBuilder.calcPoints(tsLength, segmentSize);
		root.initSegments(points);

		long count = 0;

		/*
		 * int seriesLength = 20; int size=1000000; double[][] timeSeries=new
		 * double[size][seriesLength];
		 * 
		 * 
		 * RandomSeriesGenerator randomSeriesGenerator = new
		 * RandomSeriesGenerator(); SineGenerator sineGenerator = new
		 * SineGenerator(seriesLength,2,10,2,10,-5,5);
		 * randomSeriesGenerator.addGenerator(sineGenerator);
		 * 
		 * GaussianGenerator gaussianGenerator = new
		 * GaussianGenerator(seriesLength,-5,5,0,2);
		 * randomSeriesGenerator.addGenerator(gaussianGenerator);
		 * 
		 * RandomWalkGenerator randomWalkGenerator = new
		 * RandomWalkGenerator(seriesLength,-5,5,0,2);
		 * randomSeriesGenerator.addGenerator(randomWalkGenerator);
		 * 
		 * SegmentGaussianGenerator segmentGaussianGenerator = new
		 * SegmentGaussianGenerator(seriesLength,3,10,-5,5,0,2);
		 * randomSeriesGenerator.addGenerator(segmentGaussianGenerator);
		 * 
		 * for (int i = 0; i < size; i++) { timeSeries[i] =
		 * randomSeriesGenerator.generate();
		 * 
		 * }
		 */

		long fileSize = new File(fileName).length();
		count = (int) (fileSize / tsLength / 8);
		count = size;
		// count=1000000;
		System.out.println("  count    is    " + count);
		FileInputStream fis = new FileInputStream(fileName);
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		long count2 = 0;
		for (int i = 0; i < count; i++) {
			double[] tss = new double[tsLength];
			// String aa="";
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();
				// if(j<10)
				// aa+="	"+tss[j];

			}
			// tssn=TimeSeriesFileUtil.zNormalizeTS_binary(tss);
			root.insert(tss);
			// System.out.println(count2+ "  **********************   " +aa);
			count2++;
			// if(count2%1000==0)
			// System.out.println("  **********************   " + count2);

			if (maxTsCount > 0) {
				if (count >= maxTsCount)
					break;
			}

		}

		dis.close();
		bis.close();
		fis.close();
		size = count;
		FileBufferManager.getInstance().saveAllToDisk();
		String indexFileName = indexPath + "\\" + "root.idx";
		root.saveToFile(indexFileName);
		Node newRoot = Node.loadFromFile(indexFileName);
		//
		loadTerminalNodes(newRoot);
		/*
		 * FileWriter fw = new FileWriter(
		 * "/home/hadoop/lqh/segment_info"+threshold+"_.txt");//
		 * ����FileWriter��������д���ַ��� BufferedWriter bw = new BufferedWriter(fw);
		 * for (int ii = 0; ii < nodeList.size(); ii++) { Node tempNode =
		 * nodeList.get(ii); tempNode.getSegmentSize(); String info =
		 * tempNode.getSegmentSize() + "\t" + tempNode.getSize();
		 * bw.write(info); bw.newLine(); //
		 * System.out.println(tempNode.getSegmentSize
		 * ()+"\t"+tempNode.getSize()); } bw.close();
		 */
		System.out.println("newRoot = " + newRoot);
		System.out.println("FileBufferManager.getInstance().ioRead = "
				+ FileBufferManager.getInstance().ioRead);
		System.out.println("FileBufferManager.getInstance().ioWrite = "
				+ FileBufferManager.getInstance().ioWrite);
		System.out.println("FileBufferManager.getInstance().ioDelete = "
				+ FileBufferManager.getInstance().ioDelete);
	}

	public static void loadTerminalNodes(Node node) {
		if (node == null)
			return;

		if (node.isTerminal()) {
			nodeList.add(node);
		} else {
			Node left = node.getLeft();
			loadTerminalNodes(left);

			Node right = node.getRight();
			loadTerminalNodes(right);
		}
	}
}
