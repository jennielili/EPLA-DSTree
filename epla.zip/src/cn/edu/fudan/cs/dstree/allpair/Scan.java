package cn.edu.fudan.cs.dstree.allpair;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.edu.fudan.cs.dstree.dynamicsplit.FileBufferManager;
import cn.edu.fudan.cs.dstree.dynamicsplit.INodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevNodeSegmentSketchUpdater;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevRange;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;

public class Scan {
	private static final Log log = LogFactory
			.getLog(DSTreeAllPairFinderTest.class);
    public static String fileName = "c:\\data\\Series_1000_100000.z.bin";
   // public static String fileName = "/home/hadoop/lqh/Series_1000_100000.z.bin";
	public static int threshold = 50;
	public static int segmentSize = 10;
	public static int reducedDimensionCount;
	public static int dft_m;
	public static double t;
	public static int tsLength = 5120;
	public double[][] timeSeries;

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		// testBuildTree();
	
		testFindPairs();
	}

	public static void testBuildTree() throws IOException,
			ClassNotFoundException {

		Node.hsTradeOffFactor = 30000;
		SystemInfoUtils systemInfoUtils = new SystemInfoUtilsImpl();
		double bufferedMemorySize = systemInfoUtils.getTotalMemory() * 0.6; // 0.6
																			// for
																			// buffer

		buildDSTreeFromBinaryDataFile(fileName, null, 5120, 5120,
				bufferedMemorySize, -1, tsLength);
		System.out.println("Finished!!!");
	}

	public static void testFindPairs() throws IOException,
			ClassNotFoundException {

		int n = 5120;
		double[][] timeSeries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength, n);
		double[][] norm_series = new double[timeSeries.length][n];
		int count2=0;
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		for(int ii=0;ii<timeSeries.length-1;ii++)
		{
			timeSeries[ii]=TimeSeriesFileUtil.zNormalizeTS_binary(timeSeries[ii]);
			for(int jj=ii+1;jj<timeSeries.length;jj++)
		    {
	        	double dis=DistUtil.euclideanDist(timeSeries[ii], timeSeries[jj]);
	        	if(dis<80)
	        	System.out.println("   dis     is   "+dis);
			    if (DistUtil.euclideanDistLessThan(timeSeries[ii], timeSeries[jj], t))
                {
				  
                 	count2++;
                 }
		    }
		}
		stopWatch.stop();
		System.out.println("  time    is  "+stopWatch.getTime()+"  count   is   "+count2);

		
	}

	public static void buildDSTreeFromBinaryDataFile(String fileName,
			String indexPath, int threshold, int segmentSize,
			double bufferedMemorySize, int maxTsCount, int tsLength)
			throws IOException, ClassNotFoundException {
		System.out.println("fileName = " + fileName);
		System.out.println("tsLength = " + tsLength);
		FileBufferManager.fileBufferManager = null;
		FileBufferManager.getInstance().tsLength = tsLength;
		FileBufferManager.getInstance().setBufferedMemorySize(
				bufferedMemorySize);
		FileBufferManager.getInstance().setThreshold(threshold);

		// init indexPath if null
		if (indexPath == null)
			indexPath = fileName;
		indexPath = indexPath + ".idx_dyn";
		indexPath = indexPath + "_" + threshold + "_" + segmentSize;
		if (maxTsCount > 0) {
			indexPath = indexPath + "_" + maxTsCount;
		}
		System.out.println("indexPath = " + indexPath);
		File file = new File(indexPath);
		if (file.exists()) {
			System.out.println("indexPath: " + indexPath
					+ " exists! cleaning...");
			FileUtils.cleanDirectory(file);
		} else {
			boolean b = file.mkdirs();
		}

		Node root = new Node(indexPath, threshold);

		// init helper class instances
		INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[1];
		nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
		// nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
		root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

		MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
		root.setSeriesSegmentSketcher(seriesSegmentSketcher);
		root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(
				seriesSegmentSketcher));

		root.setRange(new MeanStdevRange());

		// calc the split points by segmentSize
		short[] points = IndexBuilder.calcPoints(tsLength, segmentSize);
		root.initSegments(points);

		int count = 0;
		double[][] timeSeries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		log.debug("timeSeries.length = " + timeSeries.length);

		for (int i = 0; i < timeSeries.length; i++) {
			double[] timeSery = timeSeries[i];
			root.insert(timeSery);
			count++;
			if (count % 10000 == 0)
				log.debug("count = " + count);
			if (maxTsCount > 0) {
				if (count >= maxTsCount)
					break;
			}
		}
		FileBufferManager.getInstance().saveAllToDisk();
		String indexFileName = indexPath + "\\" + "root.idx";
		root.saveToFile(indexFileName);
		Node newRoot = Node.loadFromFile(indexFileName);
		System.out.println("newRoot = " + newRoot);
		System.out.println("FileBufferManager.getInstance().ioRead = "
				+ FileBufferManager.getInstance().ioRead);
		System.out.println("FileBufferManager.getInstance().ioWrite = "
				+ FileBufferManager.getInstance().ioWrite);
		System.out.println("FileBufferManager.getInstance().ioDelete = "
				+ FileBufferManager.getInstance().ioDelete);
	}
}
