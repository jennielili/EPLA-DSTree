package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class DistTreeNode implements Comparable<DistTreeNode> {
    DistTreeNode parent;
    int idx;
    int level;
    int distanceTimes;
    double range;
    AutoExpandIntArray pairIdxArray = new AutoExpandIntArray(100);
    List<DistTreeNode> children = new ArrayList<DistTreeNode>(10);
    int count = 0;

    public boolean isLeaf() {
        return children.size() == 0;
    }

    double[][] timeSeries;
    double[][] reducedTimeSeries;
    int segmentLength;

    public DistTreeNode(DistTreeNode parent, int idx, int distanceTimes, double[][] timeSeries, double range, double[][] reducedTimeSeries, int segmentLength) {
        this.parent = parent;
        this.idx = idx;
        this.distanceTimes = distanceTimes;
        this.timeSeries = timeSeries;
        this.range = range;
        this.reducedTimeSeries = reducedTimeSeries;
        this.segmentLength = segmentLength;
        if (parent != null)
            level = parent.level + 1;
    }

    public void addPairIdx(int pairIdx) {
        pairIdxArray.append(pairIdx);
    }

    public void appendTimeSeries(int appendIdx) {
//        System.out.println("appendIdx = " + appendIdx);
        count++;
        double[] thisTs = timeSeries[idx];
        double[] appendTs = timeSeries[appendIdx];
        double distance = DistUtil.euclideanDist(thisTs, appendTs);
        distCount++;
//        int times = (int) Math.ceil(distance / range);
        if (distance <= range) {
            addPairIdx(appendIdx);
        } else {
            int times = (int) (distance / range);
            if (times * range >= distance)
                times--;
            DistTreeNode childNode = getChildNode(times);
            if (childNode == null) {
                childNode = new DistTreeNode(this, appendIdx, times, timeSeries, range, reducedTimeSeries, segmentLength);
                children.add(childNode);
                Collections.sort(children);
            } else {
                childNode.appendTimeSeries(appendIdx);
            }
        }
    }

    public DistTreeNode getChildNode(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return distTreeNode;
        }
        return null;
    }

    public int getChildNodeIdx(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return i;
        }
        return -1;
    }


    @Override
    public int compareTo(DistTreeNode o) {
        return this.distanceTimes - o.distanceTimes;
    }

    public void findAllParis(AutoExpandIntArray allPairs) {
        //deal with self
//        System.out.println("pairIdxArray = " + pairIdxArray.size());
//        System.out.println("children = " + children.size());
//        System.out.println("this = " + this); todo:
        pairIdxArray.shrink();
        //deal with idx and distanceTimes 0
        int[] array = pairIdxArray.getArray();
        for (int i = 0; i < array.length; i++) {
            allPairs.append(idx, array[i]);
        }

        //deal with distanceTimes 0
        findAllPairsForIdxArray(array, allPairs);

        //deal with distanceTimes 0 and times 1, move down  //for this level
        DistTreeNode childNode = getChildNode(1);
        findAllPairsBetweenIdxArrayAndNodeDown(idx, array, childNode, allPairs);
//

        //compare with other node //move up

        List<DistTreeNode> parentNodes = getParentSearchNodes();
        for (int i = 0; i < parentNodes.size(); i++) {
            DistTreeNode distTreeNode = parentNodes.get(i);
//            findAllPairsBetweenIdxArrayAndNodeDown(idx, array, distTreeNode, allPairs);
        }


        //deal with children
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode distTreeNode = children.get(i);
            distTreeNode.findAllParis(allPairs);
        }

//        System.out.println("countForDown = " + countForDown);
    }

    private List<DistTreeNode> getParentSearchNodes() {
        List<DistTreeNode> ret = new ArrayList<DistTreeNode>();

        DistTreeNode p = parent;
        int distTimes = distanceTimes;

        while (p != null) {
            DistTreeNode childNode = p.getChildNode(distTimes + 1);
            if (childNode != null)
                ret.add(childNode);
            distTimes = p.distanceTimes;
            p = p.parent;
        }

        return ret;
    }

    public static int countForDown = 0;
    public static int countForDownWorked = 0;

    private void findAllPairsBetweenIdxArrayAndNodeDown(int refIdx, int[] refArray, DistTreeNode node, AutoExpandIntArray allPairs) {
        int allPairsOldSize = allPairs.size();
        countForDown++;
        if (node == null)
            return;
        //
        int idx1 = node.idx;

        double distance = distance(refIdx, idx1);
        if (distance <= range) {
            allPairs.append(refIdx, node.idx);
        }

        double times = distance / range;
//        if (distance <= 3 * range) {
        if (times <= 3) {
            AutoExpandIntArray pairIdxArray1 = node.pairIdxArray;
            pairIdxArray1.shrink();
            int[] array = pairIdxArray1.getArray();

            findAllPairsBetweenIdxArrays(refArray, array, allPairs);
            //miss node.idx time series? so check it
            findAllPairsBetweenIdxArrays(refArray, new int[]{node.idx}, allPairs);

            findAllPairsBetweenIdxArrays(new int[]{refIdx}, array, allPairs);
        }

        //deal with children
        for (int i = 0; i < node.children.size(); i++) {
            DistTreeNode distTreeNode = node.children.get(i);
            if ((times <= distTreeNode.distanceTimes + 3) && (times > distTreeNode.distanceTimes - 2))
//            if (times <= distTreeNode.distanceTimes + 3)
                findAllPairsBetweenIdxArrayAndNodeDown(refIdx, refArray, distTreeNode, allPairs);
        }

        if (allPairs.size() > allPairsOldSize) {
            countForDownWorked++;
        }
    }

    public static int distCount = 0;

    public double distance(int idx1, int idx2) {
        distCount++;
        return DistUtil.euclideanDist(timeSeries[idx1], timeSeries[idx2]);
    }

    public static int lowerBoundCount = 0;
    public static int distLessThanCount = 0;

    public void findAllPairsForIdxArray(int[] idxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        for (int i = 0; i < idxArray.length; i++) {
            int idx1 = idxArray[i];
            double[] ts1 = timeSeries[idx1];
            for (int j = i + 1; j < idxArray.length; j++) {
                int idx2 = idxArray[j];
                double[] ts2 = timeSeries[idx2];

                //use early abandon and reduced dimension
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    lowerBoundCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        distLessThanCount++;
                        pairsArray.append(idx1, idx2);
                    }
                }
                //use early abandon
//                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
//                    pairsArray.append(idx1, idx2);
//                double distance = DistUtil.euclideanDist(ts1, ts2);
//                if (distance <= range) {
//                    pairsArray.append(idx1, idx2);
//                }
            }
        }
    }

    public void findAllPairsBetweenIdxArrays(int[] leftIdxArray, int[] rightIdxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        for (int i = 0; i < leftIdxArray.length; i++) {
            int idx1 = leftIdxArray[i];
            double[] ts1 = timeSeries[idx1];
            for (int j = 0; j < rightIdxArray.length; j++) {
                int idx2 = rightIdxArray[j];
                double[] ts2 = timeSeries[idx2];


                //use early abandon and reduced dimension
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    lowerBoundCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        distLessThanCount++;
                        pairsArray.append(idx1, idx2);
                    }
                }

                //use early abandon
//                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
//                    pairsArray.append(idx1, idx2);

//                double distance = DistUtil.euclideanDist(ts1, ts2);
//                if (distance <= range) {
//                    pairsArray.append(idx1, idx2);
//                }
            }
        }
    }

    public double[][] getNodeTimeSeries() {
        double[][] ret = new double[pairIdxArray.size() + 1][timeSeries[0].length];
        //add those ts in pair
        for (int i = 0; i < ret.length; i++) {
            ret[i] = timeSeries[pairIdxArray.get(i)];
        }
        ret[ret.length - 1] = timeSeries[idx]; //append node idx

        return ret;
    }

    @Override
    public String toString() {
        return "DistTreeNode{" +
                "parent.idx=" + (parent == null ? "null" : parent.idx) +
                ", idx=" + idx +
                ", count=" + count +
                ", distanceTimes=" + distanceTimes +
                ", pairIdxArray=" + pairIdxArray.size() +
                ", children=" + children.size() +
                '}';
    }

    public String toXml() {

        pairIdxArray.shrink();
        int[] array = pairIdxArray.getArray();
        StringBuilder sb = new StringBuilder();
        String tagStart = MessageFormat.format("<node idx=\"{0}\" count=\"{1}\" pdTimes=\"{2}\" array=\"{3}\" parent=\"{4}\" level=\"{5}\">", idx + "", count + "", distanceTimes, joinArray(array), parent == null ? null : parent.idx + "", level + "");
        sb.append(tagStart).append("\n");

        for (int i = 0; i < children.size(); i++) {
            DistTreeNode distTreeNode = children.get(i);
            sb.append(distTreeNode.toXml());
        }

        sb.append("</node>").append("\n");
        return sb.toString();
    }

    public String joinArray(int[] array) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(array.length,4); i++) {
            int i1 = array[i];
            sb.append(i1);
            sb.append(",");
        }
        return sb.toString();
    }
}
