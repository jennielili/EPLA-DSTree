package cn.edu.fudan.cs.dstree.allpair;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.partition.Edge;
import cn.edu.fudan.cs.dstree.partition.Graph;
import cn.edu.fudan.cs.dstree.partition.Vertex;
public class GraphPartitioning_2 {
	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		GraphPartitioning_2 gp=new GraphPartitioning_2();
		Graph graph=gp.getGraphFromFile("d:\\dstree\\graph4");
		List<Vertex>  vertexes_o=graph.getVertexList();
		List<Edge>  edges_o=graph.getEdgeList();
		System.out.println("  number  of  vertexes  is  "+vertexes_o.size()+"   number of edges   is  "+edges_o.size());
		int k=128;
		int[] count=new int[k];
		for(int ii=0;ii<vertexes_o.size();ii++)
		{
			Vertex ver=vertexes_o.get(ii);
			ver.bitSet=new BitSet(k);
		}
		double cost=gp.computeCost(graph);
        System.out.println("  graph  load   number   is   "+graph.getTotalLoad()+"  mean  cost  is  "+cost/k);
        Graph[] subgraphs=gp.graphPartitioning(graph, k, cost/k);
        int num_vertex=0;
        int num_edges=0;
        for(int ii=0;ii<k;ii++)
        {
        	Graph sub=subgraphs[ii];
        	List<Vertex>  vertexes2=sub.getVertexList();
    		List<Edge>  edges2=sub.getEdgeList();
    		num_vertex+=vertexes2.size();
    		num_edges+=edges2.size();
        	double load=sub.getTotalLoad();
        	List vertexes=sub.getVertexList();
        	double cost2=gp.computeCost(sub);
        	System.out.println("   subgraph "+ii+"   load    is   "+load+"   vertexes is "+vertexes.size()+"  workload   is  "+cost2);
        	
        }
        System.out.println(" Cost   is   "+cost);
        System.out.println("  all partitioning  edges   is  "+num_edges+"   vertexes   is  "+num_vertex);
        int total_count=0;
        for(int ii=0;ii<vertexes_o.size();ii++)
		{
			Vertex ver=vertexes_o.get(ii);
			for(int jj=0;jj<k;jj++)
			{
				if(ver.bitSet.get(jj))
					count[jj]++;
			}
			
		}
        for(int ii=0;ii<k;ii++)
        {
        	System.out.println(" sub   graph "+count[ii]);
        	total_count+=count[ii];
        }
        System.out.println("vertex count:"+vertexes_o.size()+" total_count:"+total_count+" copy count:"+(total_count-vertexes_o.size()));
        
	}
	public Graph getGraphFromFile(String fineName) throws FileNotFoundException, IOException
	{
		 
		    FSTObjectInput in = new FSTObjectInput(new FileInputStream(fineName));
	        Graph graph = null;
	        try {
	            graph = (Graph) in.readObject(Graph.class);
	        } catch (Exception e) {
	            throw new IOException(e.getMessage());
	        }
	        in.close();
	        return graph;
	        
	}
	public Graph[] graphPartitioning_preorder(Graph graph, int k, double meanCost, double maxLoad)
	{
		Graph[] subgraphs=new Graph[k];
		List<Vertex>  vertexes=graph.getVertexList();
		int kk=0;
		List<Vertex>[] newVertexes=new ArrayList[k];
		List<Edge>[]   newEdges=new ArrayList[k];
		int pos=0;
		for(int sgId=0;sgId<k;sgId++)
		{
			    newVertexes[sgId]=new ArrayList();
			    newEdges[sgId]=new ArrayList();
			    subgraphs[sgId]=new Graph(newVertexes[sgId],newEdges[sgId]);
			    double load=0.0;
			    while(true)
			    {
			    	load+=vertexes.get(pos).getLoad();
			    	if(load<maxLoad)
			    	{
				    	newVertexes[sgId].add(vertexes.get(pos));
				    	vertexes.get(pos).setPartitionId(sgId);
				    	load+=vertexes.get(pos).getLoad();
				    	pos++;
			    	}
			    	else
			    	  break;
			    }
		}
		List<Edge>  edges_o=graph.getEdgeList();
		for(int ii=0;ii<edges_o.size();ii++)
		{
			Edge ee=edges_o.get(ii);
			Vertex v1=ee.getVertex1();
    		Vertex v2=ee.getVertex2();
    		double load1=v1.getLoad();
    		double load2=v2.getLoad();
    		if(load1<load2)
    			v1.bitSet.set(v2.getPartitionId(), true);
		}
		
		return subgraphs;
		
	}
	public Graph[] graphPartitioning(Graph graph, int k, double meanCost)
	{
	//	Collections.sort(graph.getVertexList(),new ComparatorClass());
		HashMap<Vertex, List<Edge>> neighbors=graph.computeNeighbors();
		List<Vertex>  vertexes=graph.getVertexList();
		List<Edge>  edges=null;
	    Graph[] subgraphs=new Graph[k];
	    Queue<Edge> queue=new LinkedList<Edge>();
	    int kk=0;
	    List<Vertex>[] newVertexes=new ArrayList[k];
	    List<Edge>[]   newEdges=new ArrayList[k];
	    double cost=0.0;
	    for(int sgId=0;sgId<k;sgId++)
	    {
		    newVertexes[sgId]=new ArrayList();
		    newEdges[sgId]=new ArrayList();
		    subgraphs[sgId]=new Graph(newVertexes[sgId],newEdges[sgId]);
		    if(sgId>0)
		    {
		    	System.out.println("   cost  of  "+(sgId-1)+"   is    "+cost);
		 //   	System.out.println("   compute cost  of  "+(sgId-1)+"   is    "+);
		    }
		    
		    cost=0.0;
		    
		    while(cost<meanCost)
		    {
		    	//System.out.println("  partitionid  "+vertexes.get(kk).getPartitionId());
		    	if(queue.isEmpty())
		    	{
			    	while(kk<vertexes.size() && vertexes.get(kk).getPartitionId()!=-1)
			    		kk++;
			    	if(kk>=vertexes.size())
			    		break;
			    	
			    	Vertex vv=vertexes.get(kk);
			    	vv.setPartitionId(sgId);
			    	vv.bitSet.set(sgId, true);
			    	newVertexes[sgId].add(vv);
					cost+=vv.getLoad()*(vv.getLoad()-1)/2;
					 if(cost>meanCost)
						 break;
			    	
					List<Edge> neighs=neighbors.get(vv);
			    	if(neighs!=null)
			    	for(int ii=0;ii<neighs.size();ii++)
			    	{
			    		Edge ee=neighs.get(ii);
			    		Vertex v1=ee.getVertex1();
			    		Vertex v2=ee.getVertex2();
			    		if(v1.getId()!=vv.getId())
			    		{
			    			if(v1.getPartitionId()!=-1)
			    				queue.add(ee);
			    		}
			    		if(v2.getId()!=vv.getId())
			    		{
			    			if(v2.getPartitionId()!=-1)
			    				queue.add(ee);
			    		}
			    	}
			    	
		    	}
		    	while(queue.size()>0)
				{
			    	
					Edge ed=queue.poll();
					cost+=ed.getVertex1().getLoad()*ed.getVertex2().getLoad();
					newEdges[sgId].add(ed);
		    		
					ed.getVertex1().bitSet.set(sgId, true);
					ed.getVertex2().bitSet.set(sgId, true);
					
					if(cost>=meanCost)
					{
						  break;
					}
					
				    Vertex v1=ed.getVertex1();
		    		if(v1.getPartitionId()!=-1)
		    		{
		    			v1=ed.getVertex2();
		    		}
		    		if(v1.getPartitionId()==-1)
		    		{
			    		 v1.setPartitionId(sgId);
			    		 v1.bitSet.set(sgId,true);
			    		 newVertexes[sgId].add(v1);
			    		 cost+=v1.getLoad()*(v1.getLoad()-1)/2;
			    		 
						 List<Edge> neighs=neighbors.get(v1);
					     for(int ii=0;ii<neighs.size();ii++)
					    {
					    		Edge ee=neighs.get(ii);
					    		Vertex v=ee.getVertex1();
					    		Vertex vv2=ee.getVertex2();

					    		if(v.getPartitionId()!=-1)
					    		{
					    			v=ee.getVertex2();
					    		}
					    		if(v.getPartitionId()==-1)
					    			queue.add(ee);
					    	}
						 if(cost>meanCost)
							 break;
		    		} 
		  		}	//while
									
		 	}
		  //  System.out.println("  number "+sgId+"   is  "+newVertexes[sgId].size());
	    }
	    return subgraphs;
	}
	public double computeCost(Graph graph)
	{
		double cost=0.0;
		List<Vertex> vertexList=graph.getVertexList();
		List<Edge> edgeList=graph.getEdgeList();
		for (int j = 0; j < edgeList.size(); j++) {
             Edge edge = edgeList.get(j);
             Vertex vertex1 = edge.getVertex1();
             Vertex vertex2 = edge.getVertex2();
             double load1=vertex1.getLoad();
             double load2=vertex2.getLoad();
             cost+=(load1*load2);
		}
		for (int j = 0; j < vertexList.size(); j++) {
			Vertex vertex1 = vertexList.get(j);
			double load1=vertex1.getLoad();
			cost+=load1*(load1-1)/2;
		}
		return cost;
		
	}

}
