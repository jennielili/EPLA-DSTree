package cn.edu.fudan.cs.dstree.allpair;

/*������
**/
public class complex{
public double r,i;
   public complex(){
   
   }
   public complex(double r,double i){
    this.r=r; //ʵ��
    this.i=i; //�鲿
   }
}
