package cn.edu.fudan.cs.dstree.allpair;
import java.util.*;

/**
 * Created by wangyang on 2014/8/12.
 */
public class FMPCANodePartitioner extends PCANodePartitioner {
    public List<List<PCATreeNode>> splitNodeList(List<PCATreeNode> inputNodeList, int maxSize) {
        List<List<PCATreeNode>> ret = new ArrayList<List<PCATreeNode>>();

        int currentSize = getTotalCount(inputNodeList);
        if (currentSize < maxSize) {
            ret.add(inputNodeList);
        } else {
            //
            int halfCurrentSize = currentSize / 2;

            List<PCATreeNode> leftList = new ArrayList<PCATreeNode>();
            List<PCATreeNode> rightList = new ArrayList<PCATreeNode>();
            int count = 0;
            for (int i = 0; i < inputNodeList.size(); i++) {
                PCATreeNode pcaTreeNode = inputNodeList.get(i);

                if ((count + pcaTreeNode.count) < halfCurrentSize) {
                    count += pcaTreeNode.count;
                    leftList.add(pcaTreeNode);
                } else {
                    for (int j = i; j < inputNodeList.size(); j++) {
                        PCATreeNode treeNode = inputNodeList.get(j);
                        rightList.add(treeNode);
                    }
                    break;
                }
            }
//            System.out.println("leftList.size() = " + leftList.size());
//            System.out.println("rightList.size() = " + rightList.size());

            HashSet leftSet = new HashSet(leftList);
            HashSet rightSet = new HashSet(rightList);

            //init weights
            for (int i = 0; i < inputNodeList.size(); i++) {
                PCATreeNode pcaTreeNode = inputNodeList.get(i);
                pcaTreeNode.innerWeight = 0;
                pcaTreeNode.outerWeight = 0;
            }
            initWeights(leftSet, rightSet);

            //move until gain not increase
            double totalGain = getTotalGain(leftList) + getTotalGain(rightList);
            int leftListCount = getTotalCount(leftList);
            int rightListCount = getTotalCount(rightList);

            while (true) {
                //sort leftList and rightList by gain
                Collections.sort(leftList, comparator);
//                Collections.reverse(leftList);
                Collections.sort(rightList, comparator);
//                Collections.reverse(rightList);

                PCATreeNode leftTopNode = leftList.get(0);
                PCATreeNode rightTopNode = rightList.get(0);

                if (leftListCount > rightListCount) //move a node from left to right
                {
                    if (leftTopNode.getGainWeight() < 0) {
                        leftList.remove(0);
                        rightList.add(leftTopNode);
                        leftSet.remove(leftTopNode);
                        rightSet.add(leftTopNode);
                        //update weights related to leftTopNode
                        int temp = leftTopNode.outerWeight;
                        leftTopNode.outerWeight = leftTopNode.innerWeight;
                        leftTopNode.innerWeight = temp;
                        //update others
                        List<PCATreeNode> pcaTreeNodes = nodePairMap.get(leftTopNode);
                        for (int i = 0; i < pcaTreeNodes.size(); i++) {
                            PCATreeNode pcaTreeNode = pcaTreeNodes.get(i);
                            if (leftSet.contains(pcaTreeNode))
                            {
                                pcaTreeNode.innerWeight --;
                                pcaTreeNode.outerWeight ++;
                            }

                            if (rightList.contains(pcaTreeNode))
                            {
                                pcaTreeNode.outerWeight --;
                                pcaTreeNode.innerWeight ++;
                            }
                        }
                        //update count
                        leftListCount -= leftTopNode.count;
                        rightListCount += leftTopNode.count;
                    } else
                        break;
                } else {
                    if (rightTopNode.getGainWeight() < 0) {
                        rightList.remove(0);
                        leftList.add(rightTopNode);
                        rightSet.remove(rightTopNode);
                        leftSet.add(rightTopNode);
                        //update weights related to leftTopNode
                        int temp = rightTopNode.outerWeight;
                        rightTopNode.outerWeight = rightTopNode.innerWeight;
                        rightTopNode.innerWeight = temp;
                        //update others
                        List<PCATreeNode> pcaTreeNodes = nodePairMap.get(rightTopNode);
                        for (int i = 0; i < pcaTreeNodes.size(); i++) {
                            PCATreeNode pcaTreeNode = pcaTreeNodes.get(i);
                            if (leftSet.contains(pcaTreeNode))
                            {
                                pcaTreeNode.innerWeight ++;
                                pcaTreeNode.outerWeight --;
                            }

                            if (rightList.contains(pcaTreeNode))
                            {
                                pcaTreeNode.outerWeight ++;
                                pcaTreeNode.innerWeight --;
                            }
                        }
                        //update count
                        leftListCount += rightTopNode.count;
                        rightListCount -= rightTopNode.count;
                    } else
                        break;
                }

                double newTotalGain = getTotalGain(leftList) + getTotalGain(rightList);
                if (newTotalGain > totalGain) {
                    totalGain = newTotalGain;
                } else //total gain not increase
                    break;
            }

            ret.addAll(splitNodeList(leftList, maxSize));
            ret.addAll(splitNodeList(rightList, maxSize));
        }

        return ret;
    }

    HashMap<PCATreeNode, List<PCATreeNode>> nodePairMap = new HashMap<PCATreeNode, List<PCATreeNode>>();
    @Override
    public void partition() {
        //init hashMap;
        for (int i = 0; i < nodePairList.size(); i++) {
            PCANodePair pcaNodePair = nodePairList.get(i);
            PCATreeNode node1 = pcaNodePair.node1;
            PCATreeNode node2 = pcaNodePair.node2;

            List<PCATreeNode> pcaTreeNodes1 = nodePairMap.get(node1);
            if (pcaTreeNodes1 == null)
            {
                pcaTreeNodes1 = new ArrayList<PCATreeNode>();
                nodePairMap.put(node1, pcaTreeNodes1);
            }
            pcaTreeNodes1.add(node2);

            List<PCATreeNode> pcaTreeNodes2 = nodePairMap.get(node2);
            if (pcaTreeNodes2 == null)
            {
                pcaTreeNodes2 = new ArrayList<PCATreeNode>();
                nodePairMap.put(node2, pcaTreeNodes2);
            }
            pcaTreeNodes2.add(node1);
        }

        List<List<PCATreeNode>> lists = splitNodeList(nodeList, threshold);
        for (int i = 0; i < lists.size(); i++) {
            List<PCATreeNode> pcaTreeNodes = lists.get(i);
            for (int j = 0; j < pcaTreeNodes.size(); j++) {
                PCATreeNode pcaTreeNode = pcaTreeNodes.get(j);
                pcaTreeNode.partitionId = i;
            }
        }
        partitionCount = lists.size();
    }

    private int getTotalCount(List<PCATreeNode> nodeList) {
        int ret = 0;
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);
            ret += pcaTreeNode.count;
        }
        return ret;
    }

    private int getTotalGain(List<PCATreeNode> nodeList) {
        int ret = 0;
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);
            ret += pcaTreeNode.getGainWeight();
        }
        return ret;
    }

    Comparator<PCATreeNode> comparator = new GainComparator();

    public void initWeights(HashSet<PCATreeNode> leftList, HashSet<PCATreeNode> rightList) {

        for (int i = 0; i < nodePairList.size(); i++) {
            PCANodePair pcaNodePair = nodePairList.get(i);
            PCATreeNode node1 = pcaNodePair.node1;
            PCATreeNode node2 = pcaNodePair.node2;
            if (leftList.contains(node1) && leftList.contains(node2)) {
                node1.innerWeight++;
                node2.innerWeight++;
            } else if (rightList.contains(node1) && rightList.contains(node2)) {
                node1.innerWeight++;
                node2.innerWeight++;
            } else if (leftList.contains(node1) && rightList.contains(node2)) {
                node1.outerWeight++;
                node2.outerWeight++;
            } else if (leftList.contains(node2) && rightList.contains(node1)) {
                node1.outerWeight++;
                node2.outerWeight++;
            }
        }
    }
}

class GainComparator implements Comparator<PCATreeNode> {
    @Override
    public int compare(PCATreeNode o1, PCATreeNode o2) {
        return Integer.compare(o1.getGainWeight(), o2.getGainWeight());
    }
}