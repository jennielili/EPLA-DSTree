package cn.edu.fudan.cs.dstree.allpair;

import java.util.List;

/**
 * Created by wangyang on 2014/8/13.
 */
public class RandomPCANodePartitioner extends PCANodePartitioner {
    @Override
    public void partition() {
        int totalCount = getTotalCount(nodeList);
        partitionCount = (int) Math.ceil(totalCount * 1.0 / threshold);
        System.out.println("totalCount = " + totalCount);
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);
            pcaTreeNode.partitionId = i % partitionCount;
        }

        for (int i = 0; i < partitionCount; i++) {
            List<PCATreeNode> nodeListByPartitionId = getNodeListByPartitionId(i);
            int totalCount1 = getTotalCount(nodeListByPartitionId);
            System.out.println("totalCount " + i +" = " + totalCount1);
        }

        int loadCount = getLoadCount();
        System.out.println("loadCount = " + loadCount);

        checkAndAdjustOrphanNode();

        loadCount = getLoadCount();
        System.out.println("loadCount = " + loadCount);
    }

    private int getTotalCount(List<PCATreeNode> nodeList) {
        int ret = 0;
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);
            ret += pcaTreeNode.count;
        }
        return ret;
    }
}
