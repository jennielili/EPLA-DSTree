package cn.edu.fudan.cs.dstree.allpair;
import cn.edu.fudan.cs.dstree.partition.Edge;
import java.util.Comparator;

public class EdgeComparatorClass implements Comparator{

	 public int compare(Object arg0, Object arg1) {
	  Edge edge1=(Edge)arg0;
	  Edge edge2=(Edge)arg1;
      Double dis1=edge1.getUb()-edge1.getLb();
      Double dis2=edge2.getUb()-edge2.getLb();
	  int flag=dis1.compareTo(dis2);
	  return flag;
	  }  
	 }

