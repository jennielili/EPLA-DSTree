package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.data.RandomWalkGenerator;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairFinderTest {
    private static final Log log = LogFactory.getLog(AllPairFinderTest.class);

    int tsSize = 10000;
    int tsLength = 1000;
    int threshold = 100;

    @Test
    public void test() {

        RandomWalkGenerator randomWalkGenerator = new RandomWalkGenerator(tsLength, -50, 50, 0, 10);
        double[][] timeSeries = new double[tsSize][tsLength];
        for (int i = 0; i < timeSeries.length; i++) {
            double[] generate = randomWalkGenerator.generate();
            timeSeries[i] = CalcUtil.z_Normalize(generate);
        }

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AllPairFinder allPairFinder = new AllPairFinder(timeSeries, 10, 0.01);
        DistTreeNode root = allPairFinder.buildTree();
        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
    }

    @Test
    public void testAllPairFinder() throws IOException {
        String fileName = "data\\Series_1000_100000.z.bin";
        tsLength = 1000;
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);
        int range = 10;

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AllPairFinder allPairFinder = new AllPairFinder(timeSeries, range, 0.01);
        DistTreeNode root = allPairFinder.buildTree();
        log.debug("root = " + root);
        FileUtils.writeStringToFile(new File(fileName + ".distTree.xml"), root.toXml());
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);

        root.findAllParis(allPairs);

        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        log.debug("root.countForDown = " + root.countForDown);
        log.debug("root.countForDownWorked = " + root.countForDownWorked);
        log.debug("root.lowerBoundCount = " + root.lowerBoundCount);
        log.debug("root.distLessThanCount = " + root.distLessThanCount);
        log.debug("root.distCount = " + root.distCount);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        boolean noDuplicate = AllPairUtils.checkNoDuplicate(allPairs);
        log.debug("noDuplicate = " + noDuplicate);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".distTree.txt");
    }


    @Test
    public void testAllPairFinder2_UCIDataSet() throws IOException {
        //the newest test for distance tree2
        String fileName = "data\\10w_1000_part\\10w_1000_part"; //0.1 million
        tsLength = 1000;
        tsSize = 100000;
        threshold = 150;
        log.debug("tsLength = " + tsLength);
        log.debug("threshold = " + threshold);
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromUCIFileAtOnce(fileName, tsLength, tsSize);
        log.debug("timeSeries.length = " + timeSeries.length);
        double range = 5;
        log.debug("range = " + range);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double paaReduceRatio = 0.01;
        AllPairFinder2 allPairFinder = new AllPairFinder2(timeSeries, range, paaReduceRatio, threshold);
        DistTreeNode2 root = allPairFinder.buildTree();
        log.debug("root = " + root);
        FileUtils.writeStringToFile(new File(fileName + ".distTree2.xml"), root.toXml());
        // Finish building a tree
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
        root.findAllParis(allPairs);
        stopWatch.stop();
        log.debug(" Build Tree and find all pairs cost :   " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("The similarity pairs  :  " + size);
        log.debug("root.countForDown = " + root.countForDown);
        log.debug("root.countForDownWorked = " + root.countForDownWorked);
        log.debug("root.lowerBoundCount = " + root.lowerBoundCount);
        log.debug("root.distLessThanCount = " + root.distLessThanCount);
        log.debug("root.distCount = " + root.distCount);
        // log.debug("root.prunedByParentBounds = " + root.prunedByParentBounds);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

//        boolean noDuplicate = AllPairUtils.checkNoDuplicate(allPairs);
//        log.debug("noDuplicate = " + noDuplicate);

//        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
//        Collections.sort(pairs);
//        AllPairUtils.savePairList2File(pairs, fileName + ".distTree2.txt");
    }

    @Test
    public void testAllPairFinder2() throws IOException {
        //the newest test for distance tree2
        String fileName = "data\\Series_1000_10000.z.bin"; //0.1 million
        tsLength = 100;
        threshold = 150;
        log.debug("tsLength = " + tsLength);
        log.debug("threshold = " + threshold);

        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);
        double range = 0.5;
        log.debug("range = " + range);
//        DistTreeNode2.newAlgorithm = false;
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double paaReduceRatio = 1;
        AllPairFinder2 allPairFinder = new AllPairFinder2(timeSeries, range, paaReduceRatio, threshold);
        DistTreeNode2 root = allPairFinder.buildTree();
        log.debug("root = " + root);
        FileUtils.writeStringToFile(new File(fileName + ".distTree2.xml"), root.toXml());
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
        log.debug("DistTreeNode2.newAlgorithm = " + DistTreeNode2.newAlgorithm);

        root.findAllParis(allPairs);

        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        log.debug("root.countForDown = " + root.countForDown);
        log.debug("root.countForDownWorked = " + root.countForDownWorked);
        log.debug("root.lowerBoundCount = " + root.lowerBoundCount);
        log.debug("root.distLessThanCount = " + root.distLessThanCount);
        log.debug("root.distCount = " + root.distCount);
        log.debug("root.prunedByParentBounds = " + root.prunedByParentBounds);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        boolean noDuplicate = AllPairUtils.checkNoDuplicate(allPairs);
        log.debug("noDuplicate = " + noDuplicate);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".distTree2.txt");
    }

    @Test
    public void testAllPairFinder3() throws IOException { //using DistTreeNode3
        //the newest test for distance tree2
        String fileName = "data\\Series_1000_100000.z.bin"; //0.1 million
        tsLength = 1000;
        threshold = 150;
        log.debug("tsLength = " + tsLength);
        log.debug("threshold = " + threshold);

        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);
        double range = 5;
        log.debug("range = " + range);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double paaReduceRatio = 0.01;
        StopWatch buildTree = new StopWatch();
        buildTree.start();
        AllPairFinder3 allPairFinder = new AllPairFinder3(timeSeries, range, paaReduceRatio, threshold);
        DistTreeNode3 root = allPairFinder.buildTree();
        buildTree.stop();
        log.debug(" Construct tree cost : " + buildTree.getTime());
        log.debug("root = " + root);
        FileUtils.writeStringToFile(new File(fileName + ".distTree3.xml"), root.toXml());
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);

//        root.findAllParis(allPairs);

        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        log.debug("root.countForDown = " + root.countForDown);
        log.debug("root.countForDownWorked = " + root.countForDownWorked);
        log.debug("root.lowerBoundCount = " + root.lowerBoundCount);
        log.debug("root.distLessThanCount = " + root.distLessThanCount);
        log.debug("root.distCount = " + root.distCount);
        log.debug("root.prunedByParentBounds = " + root.prunedByParentBounds);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        boolean noDuplicate = AllPairUtils.checkNoDuplicate(allPairs);
        log.debug("noDuplicate = " + noDuplicate);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".distTree2.txt");
    }

    @Test
    public void testReadFromFileBruteAndReduced_UCIDataSet() throws IOException {
        //the newest brute force test using paa and early abandon
        String fileName = "data\\10w_1000_part\\10w_1000_part"; //0.1 million
        tsLength = 1000;
        tsSize = 100000;

        log.debug("tsLength = " + tsLength);

        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromUCIFileAtOnce(fileName, tsLength, tsSize);
        log.debug("timeSeries.length = " + timeSeries.length);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double range = 5;
        log.debug("range = " + range);

        double paaReduceRatio = 0.01;
        log.debug("paaReduceRatio = " + paaReduceRatio);

        AllPairReduceBruteFinder allPairBruteFinder = new AllPairReduceBruteFinder(timeSeries, range, paaReduceRatio);
        log.debug("allPairBruteFinder = " + allPairBruteFinder);
        AutoExpandIntArray allPairs = allPairBruteFinder.findAllPairs();
        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);
        log.debug("allPairBruteFinder.lowerBoundCount = " + allPairBruteFinder.lowerBoundCount);
        log.debug("allPairBruteFinder.distLessThanCount = " + allPairBruteFinder.distLessThanCount);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".bruteReduce.txt");
    }


    @Test
    public void testReadFromFileBruteAndReduced() throws IOException {
        //the newest brute force test using paa and early abandon
        String fileName = "data\\Series_1000_10000.z.bin"; //0.1 million
        tsLength = 100;
        log.debug("tsLength = " + tsLength);

        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double range = 0.5;
        log.debug("range = " + range);

        double paaReduceRatio = 1;
        log.debug("paaReduceRatio = " + paaReduceRatio);

        AllPairReduceBruteFinder allPairBruteFinder = new AllPairReduceBruteFinder(timeSeries, range, paaReduceRatio);
        log.debug("allPairBruteFinder = " + allPairBruteFinder);
        AutoExpandIntArray allPairs = allPairBruteFinder.findAllPairs();
        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);
        log.debug("allPairBruteFinder.lowerBoundCount = " + allPairBruteFinder.lowerBoundCount);
        log.debug("allPairBruteFinder.distLessThanCount = " + allPairBruteFinder.distLessThanCount);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".bruteReduce.txt");
    }

    @Test
    public void testReadFromFileBrute() throws IOException {
        String fileName = "data\\Series_1000_10000.z.bin";
        tsLength = 1000;
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double range = 5;
        AllPairBruteFinder allPairBruteFinder = new AllPairBruteFinder(timeSeries, range);
        AutoExpandIntArray allPairs = allPairBruteFinder.findAllPairs();
        stopWatch.stop();
        log.debug("stopWatch = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs. = " + size);
        int total = timeSeries.length * timeSeries.length / 2;
        log.debug("total = " + total);
        log.debug("percent = " + size * 1.0 / total);

        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
        log.debug("verify = " + verify);

        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".brute.txt");
    }
}
