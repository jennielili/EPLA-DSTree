package cn.edu.fudan.cs.dstree.allpair;
import java.util.ArrayList;


public class Point {
	
	private static int dimention = 42;
	public ArrayList<Double> point;
	public int neighbor_id;
	public double distance;
	public int clusterId;
	public Integer getClusterId() {
		return clusterId;
	}
	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}
	
	public Point() {
		this.producePoint();
	}
	public Point(double[] values) {
		this.producePoint_real(values);
	}
	public Point(String[] values,int dimension) {
		this.dimention=dimension;
		this.producePoint_string(values);
	}
	public Point(double[] values,int dimension) {
		point = new ArrayList<Double>();
		this.dimention=dimension;
		for(int i=0; i<this.dimention; i++) {
			this.point.add(values[i]);
		}
	}
	public void producePoint() {
		point = new ArrayList<Double>();
		for(int i=0; i<this.dimention; i++) {
			double a = Math.random();
		//	System.out.println("double  first dimension "+i+"    "+a);
			this.point.add(a);
		}
	}
	public void producePoint_real(double[] values) {
		point = new ArrayList<Double>();
		for(int i=0; i<this.dimention; ++i) {
			double a = values[i];
			this.point.add(a);
		}
	}
	public void producePoint_string(String[] values) {
		point = new ArrayList<Double>();
		double[] newdoublearray=new double[values.length];
		for(int ii=0;ii<values.length;ii++)
		{
			newdoublearray[ii]=Double.parseDouble(values[ii]);
		}
		for(int i=0; i<this.dimention; ++i) {
			double a = newdoublearray[i];
		//	System.out.println("double    is   "+a);
			this.point.add(a);
		}
	}
	public String toString() {
		String str = "";
		for(int i=0; i<this.dimention; ++i) {
			str += this.point.get(i);
			str += " ";
		}
		return str;
	}

}
