package cn.edu.fudan.cs.dstree.allpair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 2014/8/12.
 */
public abstract class PCANodePartitioner {
    public abstract void partition();
    PCATreeNode node;

    List<PCATreeNode> nodeList;
    List<PCANodePair> nodePairList;

    public List<PCANodePair> getNodePairList() {
        return nodePairList;
    }

    public void setNodePairList(List<PCANodePair> nodePairList) {
        this.nodePairList = nodePairList;
    }

    int threshold;
    int partitionCount;

    public PCATreeNode getNode() {
        return node;
    }

    public void setNode(PCATreeNode node) {
        this.node = node;
    }

    public List<PCATreeNode> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<PCATreeNode> nodeList) {
        this.nodeList = nodeList;
    }

    public int getThreshold() {
        return threshold;
    }

    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }

    public int getPartitionCount() {
        return partitionCount;
    }

    public List<PCATreeNode> getNodeListByPartitionId(int partitionId)
    {
        List<PCATreeNode> ret = new ArrayList<PCATreeNode>();
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);
            if (pcaTreeNode.partitionId == partitionId)
                ret.add(pcaTreeNode);
        }
        return ret;
    }
}
