package cn.edu.fudan.cs.dstree.allpair;

import java.util.*;

/**
 * 
 * @author Administrator
 * This is a tool class to provide some methods used frequently
 * The methods in it are static,so you can use them by class Tool
 */
public class Tool {
	public static int dimension=26;
	public static double distanceSimple(Point p1, Point p2) {
		double sum = 0.0;
		double a = 0;
		if(p1==null || p2==null)
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
	//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p1.point.size(); i++) {
			a = Math.pow((p1.point.get(i)-p2.point.get(i)), 2);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
		}
		return Math.sqrt(sum);
	}
	
	public static double model(Point p1) {
		double sum = 0.0;
		double a = 0;
		if(p1==null )
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
	//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p1.point.size(); i++) {
			a = Math.pow((p1.point.get(i)), 2);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
		}
		return Math.sqrt(sum);
	}
	
	public static double cos(Point p1,Point p2) {
		double sum = 0.0;
		double sum1=0.0;
		double sum2=0.0;
		double a = 0;
		if(p1==null )
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
	//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p1.point.size(); i++) {
			a = p1.point.get(i)*p2.point.get(i);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
			sum1=(p1.point.get(i))*(p1.point.get(i));
			sum2=(p2.point.get(i))*(p2.point.get(i));
		}
		
		return  sum/((Math.sqrt(sum1))*(Math.sqrt(sum2)));
	}
	
	/*public static double distanceSimple(Point p1, Point p2) {
		double sum = 0.0;
		double a = 0;
		if(p1==null || p2==null)
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
		double piabs=0.0;
		double piabs2=0.0;
		for(int i=0; i<p1.point.size(); i++) {
			piabs+=p1.point.get(i);
		}
		for(int i=0; i<p2.point.size(); i++) {
			piabs2+=p2.point.get(i);
		}
		double ra1=Math.sqrt(piabs);
		double ra2=Math.sqrt(piabs2);
	//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p1.point.size(); i++) {
			a = Math.pow(((p1.point.get(i))/ra1-(p2.point.get(i))/ra2), 2);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
		}
		return sum;
	}
	*/
	public static double distanceFromSet(Point p1, List<Point> p2) {
		double sum = 0.0;
		double a = 0;
		if(p1==null || p2==null)
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
	    double min=100000.0;
		//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p2.size(); i++) {
			double d=distanceSimple(p1,p2.get(i));
		    if(d<min)
		    	min=d;
		}
		return min;
	}
	 public static  double getHashValue(Point a , double b, double w, Point vv )
	   	{
	   		double temp=0.0;
	   		double temp1=0.0;
	   		double temp2=0.0;
	   		double hash=0.0;
	   		double piabs=0.0;
			double piabs2=0.0;
			for(int i=0; i<a.point.size(); i++) {
				piabs+=a.point.get(i);
			}
			for(int i=0; i<vv.point.size(); i++) {
				piabs2+=vv.point.get(i);
			}
	   		for(int ii=0;ii<a.point.size();ii++)
	   		{
	   		//	temp=temp+(a.point.get(ii)*vv.point.get(ii))/(Math.sqrt(piabs))*(Math.sqrt(piabs2));
	   			temp=temp+(a.point.get(ii)*vv.point.get(ii));
	   		}
	   	//	System.out.println("  temp   is   "+temp);
	   		//System.out.println("  temp   is   "+temp+"   temp1   is  "+temp1+" temp2   is  "+temp2+"   size  is "+a.point.size()+"   vv  "+vv.toString());
	   		hash=Math.floor((temp+b)/w);
	   	    return hash;	
	   	}
	 public static Point getNearPoint(Point point,HashSet pointArray)
	    {
	    	int signal = -1;
	    	double tempDis = 0;
	    	double minDis = 10000;
	    	Iterator iit=pointArray.iterator();
	    	Point result=new Point();
	    	while(iit.hasNext())
	    	{
	    //	for (int j = 0; j < pointArray.length; j++) {
	    		Point pp=(Point)iit.next();
			    tempDis = Tool.distanceSimple(point, pp);
				if(tempDis < minDis) {
					minDis = tempDis;
					result = pp;
				}
								
			}
	    	return result;
	    }
	 public static WeightPoint getMedian(List<WeightPoint> al,int dimension)
	 {
		 Integer count=0;
		 double[] sum=new double[dimension];
		 for(int i=0;i<al.size();i++)
		 {
			 WeightPoint wp=al.get(i);
		     sum=Tool.getSum(sum,wp);
		     count+=wp.getWeight();
		 }
		 for(int jj=0;jj<dimension;jj++)
		 {
			sum[jj]=sum[jj]/count;
			//System.out.println("  center_sums["+ii+"]      is    "+center_sums[ii][0]);
		}
		 Point dp=new Point(sum);
		 double dis=100000;
		 int index=-1;
		 for(int ii=0;ii<al.size();ii++)
		 {
			 WeightPoint p=al.get(ii);
			 double dd=Tool.distanceSimple(p.getPoint(),dp);
			 if(dd<dis)
			 {
				 dis=dd;
				 index=ii;
			 }
		 }
		 double weights=0.0;
		 WeightPoint cen=null;
		 if(index!=-1)
		    cen=al.get(index);
		 else
		 {
			 System.out.println("  Can not get the  median in Tool  dis    is   "+dis+"      count   is   "+count);
			 System.out.println("  Here   exception   "+al.size());
		//	 return;
		 }
		 return  al.get(index);
		 
	 }
	 public static double[] getSum(double[] point,WeightPoint previous)
		{
			
			double[] newSum=new double[point.length];
			newSum=point;
			for(int ii=0;ii<point.length;ii++)
			{
				//newSum[ii]=newSum[ii]+previous.point.get(ii);
				Point pp=previous.getPoint();
				newSum[ii]=newSum[ii]+(pp.point.get(ii))*(previous.getWeight());
				
			}
			return newSum;
			
		}
	
	 public static double[] getSum2(double[] point,Point previous)
		{
			
			double[] newSum=new double[point.length];
			newSum=point;
			for(int ii=0;ii<point.length;ii++)
			{
				//newSum[ii]=newSum[ii]+previous.point.get(ii);
				Point pp=previous;
				newSum[ii]=newSum[ii]+(pp.point.get(ii));
			}
			return newSum;
			
		}
	 public static int checkDuplication(List center)
		{
			boolean ok=false;
			HashSet mySet=new HashSet();
			for(int ii=0;ii<center.size();ii++)
			{
				
					WeightPoint aa=(WeightPoint)center.get(ii);
					Point bb=aa.getPoint();
					if(!mySet.contains(aa))
						mySet.add(aa);
			}
			return mySet.size();
		}
	    public static double mean(List<Double> nums)
	    {
	    	double  mean=0.0;
	    	double sum=0.0;
	    	for(Double dd : nums)
	    	{
	    		sum=sum+dd;
	    	}
	    	mean=sum/nums.size();
	    	return mean;
	    }
	    public static double deviation(List<Double> nums)
	    {
	    	double mean=Tool.mean(nums);
	    	double dev=0.0;
	    	double sum=0.0;
	    	for(Double dd : nums)
	    	{
	    		double diff=(dd-mean)*(dd-mean);
	    		sum=sum+diff;
	    	}
	    	dev=sum/nums.size();
	    	return dev;
	    }
		public static int checkDuplication2(List center)
		{
			boolean ok=false;
			HashSet mySet=new HashSet();
			for(int ii=0;ii<center.size();ii++)
			{
				
					//WeightPoint aa=(WeightPoint)center.get(ii);
					Point bb=(Point)center.get(ii);
					if(!mySet.contains(bb))
						mySet.add(bb);
			}
			return mySet.size();
		}

}
