package cn.edu.fudan.cs.dstree.allpair;

import java.util.Comparator;

public class ComparatorClass implements Comparator{

	 public int compare(Object arg0, Object arg1) {
	  Vertex vertex1=(Line)arg0;
	  Line line2=(Line)arg1;

	  int flag=line1.getId().compareTo(line2.getId());
	  return flag;
	  }  
	 }

