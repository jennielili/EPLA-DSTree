package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.strtree.Node;
import cn.edu.fudan.cs.dstree.strtree.STRTree;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by wangyang on 2014/10/11.
 */
public class TouchAllPairFinder {
	private static final Log log = LogFactory.getLog(TouchAllPairFinder.class);
    double[][] timeSeries;
	public int reducedDimensionCount=2;
	public int type;
	public static int nums=0;
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getReducedDimensionCount() {
		return reducedDimensionCount;
	}

	public void setReducedDimensionCount(int reducedDimensionCount) {
		this.reducedDimensionCount = reducedDimensionCount;
	}

	public double[][] getReducedTimeSeries() {
		return reducedTimeSeries;
	}

	public void setReducedTimeSeries(double[][] reducedTimeSeries) {
		this.reducedTimeSeries = reducedTimeSeries;
	}

	double[][] reducedTimeSeries;
	int[] segments;
	int segmentLength;
	int pageSize;
	double range;

	public double getRange() {
		return range;
	}

	public void setRange(double range) {
		this.range = range;
	}

	List<Node> nodeList = new ArrayList<Node>();

	public TouchAllPairFinder(double[][] timeSeries, double reduceRatio,
			int pageSize, int reducedDimensionCount) {
		this.timeSeries = timeSeries;
		this.pageSize = pageSize;
        this.reducedDimensionCount=reducedDimensionCount;
		int originalLength = timeSeries[0].length;
		// reducedDimensionCount = (int) (originalLength * reduceRatio);
	//reducedDimensionCount = 8;
		//System.out.println("  originalLength   is   "+originalLength+"  reduced is "+reducedDimensionCount);
		if (originalLength % reducedDimensionCount != 0)
			throw new RuntimeException(
					"reduceDimensionCount can not be divided!");
		segmentLength = originalLength / reducedDimensionCount;

		reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];

		segments = AllPairUtils.calcPoints(originalLength,
				reducedDimensionCount);
		for (int i = 0; i < timeSeries.length; i++) {
			reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i],
					segments);
		}
	}

	STRTree strTree;
	Node root;

	public void buildTree() {
		double[][] tss = new double[reducedTimeSeries.length][];
		System.arraycopy(reducedTimeSeries, 0, tss, 0, tss.length);
		strTree = new STRTree(tss, pageSize);
		root = strTree.getRoot();
	}

	public void loadNodes() throws IOException {
		nodeList.clear();
		root.getLeafNodes(nodeList);
		log.debug("nodeList.size() = " + nodeList.size());
		log.debug("nodeList total pairs = " + nodeList.size()
				* (nodeList.size() - 1) / 2);
		System.out.println("nodeList total pairs = " + nodeList.size()
				* (nodeList.size() - 1) / 2);

		//FileWriter fw = new FileWriter("c:\\data\\touch_out_" + pageSize
		//		+ ".txt");// ����FileWriter��������д���ַ���
		//BufferedWriter bw = new BufferedWriter(fw);
		// load the time series by the node
		for (int i = 0; i < reducedTimeSeries.length; i++) {
			double[] rts = reducedTimeSeries[i];
			root.initIdxArray(rts, i);
		}

		// check idxArray
		boolean idxFullInitialized = true;
		for (int i = 0; i < nodeList.size(); i++) {
			Node node = nodeList.get(i);
			// add by lqh
		//	double lbreal = lowerBoundReal(node);
		//	double ubreal = upperBoundReal(node);
		//	bw.write(lbreal + "\t" + ubreal);
			//bw.newLine();
			if (!node.idxArrayInitialized()) {
				idxFullInitialized = false;
				break;
			}
		}
		//bw.close();
		System.out.println("idxFullInitialized = " + idxFullInitialized);
	}

	private double lowerBoundReal(Node node1) throws IOException {
		double lower = Double.MAX_VALUE;
		if (node1.getTsCount() <= 1) {
			lower = 0;
			return lower;
		}
		int[] IdxArray = node1.getIdArray();
		for (int ii = 0; ii < IdxArray.length - 1; ii++)
			for (int jj = ii + 1; jj < IdxArray.length; jj++) {
				double dis = DistUtil.euclideanDist(timeSeries[IdxArray[ii]],
						timeSeries[IdxArray[jj]]);
				if (dis < lower)
					lower = dis;
			}
		return lower;
	}

	private double lowerBoundReal_two(Node node1, Node node2)
			throws IOException {
		double lower = Double.MAX_VALUE;
		int[] leftIdxArray = node1.getIdArray();
		int[] rightIdxArray = node2.getIdArray();
		for (int ii = 0; ii < leftIdxArray.length; ii++)
			for (int jj = 0; jj < rightIdxArray.length; jj++) {
				double dis = DistUtil.euclideanDist(timeSeries[leftIdxArray[ii]],
						timeSeries[rightIdxArray[jj]]);
				if (dis < lower)
					lower = dis;
			}
		return lower;
	}

	private double upperBoundReal(Node node1) throws IOException {
		double upper = 0.0;
		if (node1.getTsCount() <= 1) {
			upper = Double.MAX_VALUE;
			return upper;
		}
		int[] IdxArray = node1.getIdArray();
		for (int ii = 0; ii < IdxArray.length - 1; ii++)
			for (int jj = ii + 1; jj < IdxArray.length; jj++) {
				double dis = DistUtil.euclideanDist(timeSeries[IdxArray[ii]],
						timeSeries[IdxArray[jj]]);
				if (dis > upper)
					upper = dis;
			}
		return upper;
	}

	public void printData(double[][] data) {
		for (int i = 0; i < data.length; i++) {
			System.out.println("row i = " + i);
			double[] doubles = data[i];
			for (int j = 0; j < doubles.length; j++) {
				double aDouble = doubles[j];
				System.out.print(aDouble);
				System.out.print(",");
			}
			System.out.println();
		}
	}

	public void printData(double[] data) {
		System.out.println("printData");
		for (int i = 0; i < data.length; i++) {
			double aDouble = data[i];
			System.out.print(aDouble);
			System.out.print(",");
		}
		System.out.println();
	}

	public void findAllPairs(AutoExpandIntArray allPairs, double range) throws IOException {
		// find pairs in node
		int compareCount = 0;
		for (int i = 0; i < nodeList.size(); i++) {
			Node node = nodeList.get(i);
			int[] idxArray = node.getIdArray();
			double[][] tss = new double[idxArray.length][];
			double[][] reducedTss = new double[idxArray.length][];

			for (int j = 0; j < idxArray.length; j++) {
				//System.out.println("j   is  "+j+"   "+idxArray[j]+"  "+idxArray.length);
				tss[j] = timeSeries[idxArray[j]];
				reducedTss[j] = reducedTimeSeries[idxArray[j]];
			}
			compareCount += idxArray.length * idxArray.length;
			//AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, tss,
				//	reducedTss, segmentLength, range, allPairs);
			
		     AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, tss,
						reducedTss, segmentLength, range, allPairs);
			
			
		}

		// search the nodeList and get possible node pairs
		List<int[]> nodeIdxPairList = findNodePairs(range);
		log.debug("nodeIdxPairList.size() = " + nodeIdxPairList.size());
		int totalNodePairs = nodeList.size() * (nodeList.size() - 1) / 2;
		log.debug("nodeIdxPairList ratio = " + nodeIdxPairList.size() * 1.0
				/ totalNodePairs);

		System.out
				.println("nodeIdxPairList.size() = " + nodeIdxPairList.size());
		System.out.println("nodeIdxPairList ratio = " + nodeIdxPairList.size()
				* 1.0 / totalNodePairs);
		// verify the time series between node pair
		for (int i = 0; i < nodeIdxPairList.size(); i++) {
			// if(i%10000==0)
			// System.out.println("      i     is     "+i);
			int[] nodeIdxPair = nodeIdxPairList.get(i);
			int nodeIdx0 = nodeIdxPair[0];
			int nodeIdx1 = nodeIdxPair[1];

			int[] leftIdxArray = nodeList.get(nodeIdx0).getIdArray();
			int[] rightIdxArray = nodeList.get(nodeIdx1).getIdArray();

			AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeSeries,
					reducedTimeSeries, leftIdxArray, rightIdxArray, range,
					segmentLength, allPairs);
		/*	AllPairReduceBruteFinder.findAllPairsLessthan (timeSeries,
					reducedTimeSeries, leftIdxArray, rightIdxArray, range,
					segmentLength, allPairs);*/
		}
	}

	private List<int[]> findNodePairs(double range) throws IOException {
		List<int[]> ret = new ArrayList<int[]>();
		//FileWriter fw = new FileWriter("c:\\data\\touch_between_"
		//		+ pageSize + ".txt");// ����FileWriter��������д���ַ���
	//	BufferedWriter bw = new BufferedWriter(fw);
		for (int i = 0; i < nodeList.size(); i++) {
			Node node1 = nodeList.get(i);
			if (i % 1000 == 0)
				System.out.println("   find pairs     i   is  " + i);
			for (int j = i + 1; j < nodeList.size(); j++) {
				Node node2 = nodeList.get(j);
				
				//double lower_real = lowerBoundReal_two(node1, node2);
				if(type==1)
				{
					boolean less= lowerBound_touch(node1,node2);
					if(less){
						ret.add(new int[] { i, j });
						//System.out.println("11111111111111111111");
					}
				}
				else
				{
					double lower_estimate=lowerBound(node1, node2);
					if (lower_estimate <= range) {
						ret.add(new int[] { i, j });
					}
				}
				
			//	boolean less= lowerBound_touch(node1,node2);
				//bw.write(lower_estimate+"\t"+lower_real);
				//bw.newLine();
				//if(less){
				
			}
		}
    //   bw.close();
		return ret;
	}

	public boolean lowerBound_touch(Node node1, Node node2) {
		double sum = 0;
      
		for (int i = 0; i < reducedDimensionCount; i++) {
			double node1MaxAvg = node1.getMbrUpper()[i];
			double node1MinAvg = node1.getMbrLower()[i];
			node1MaxAvg+=range/Math.sqrt(1000/reducedDimensionCount);
			node1MinAvg-=range/Math.sqrt(1000/reducedDimensionCount);
			
			double node2MaxAvg = node2.getMbrUpper()[i];
			double node2MinAvg = node2.getMbrLower()[i];
			
			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance == 0) {
				return true;
			}
			//System.out.println(" lower1  "+node1MinAvg+"   upper1  "+node1MaxAvg+"  lower2   "+node2MinAvg+" upper2  "+node2MaxAvg+"  i  is  "+i);
			
			
		//	if((mbrUpper1[i]>mbrLower2[i]))
			
		}

		return false;
	}
	public double lowerBound(Node node1, Node node2) {
		double sum = 0;

		for (int i = 0; i < reducedDimensionCount; i++) {
			double node1MaxAvg = node1.getMbrUpper()[i];
			double node1MinAvg = node1.getMbrLower()[i];

			double node2MaxAvg = node2.getMbrUpper()[i];
			double node2MinAvg = node2.getMbrLower()[i];

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength;
			}
		}

		sum = Math.sqrt(sum);
		return sum;
	}
}
