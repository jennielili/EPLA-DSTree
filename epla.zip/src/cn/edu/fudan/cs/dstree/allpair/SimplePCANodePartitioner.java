package cn.edu.fudan.cs.dstree.allpair;

import java.util.List;

/**
 * Created by wangyang on 2014/8/12.
 */
public class SimplePCANodePartitioner extends PCANodePartitioner {
    @Override
    public void partition() {
        int count = 0;
        int curPartitionId = 0;
        for (int i = 0; i < nodeList.size(); i++) {
            PCATreeNode pcaTreeNode = nodeList.get(i);

            if ((count + pcaTreeNode.count) < threshold) {
                pcaTreeNode.partitionId = curPartitionId;
                count += pcaTreeNode.count;
            }
            else
            {
                curPartitionId ++;
                count = 0;

                pcaTreeNode.partitionId = curPartitionId;
                count += pcaTreeNode.count;
            }
        }
        partitionCount = curPartitionId + 1;
    }
}
