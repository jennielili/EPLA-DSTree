package cn.edu.fudan.cs.dstree.allpair;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.edu.fudan.cs.dstree.dynamicsplit.FileBufferManager;
import cn.edu.fudan.cs.dstree.dynamicsplit.INodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevNodeSegmentSketchUpdater;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevRange;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;
public class LQH_FFTTest {
		private static final Log log = LogFactory.getLog(DSTreeAllPairFinderTest.class);
		public static String fileName = "d:\\data\\part-00000";
	    public static int threshold = 50;
	    public static int segmentSize = 10;
	    public static int tsLength = 1000;
	    public double[][] timeSeries;

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		//testBuildTree();
		testFindPairs();
	}
    public static void testBuildTree() throws IOException, ClassNotFoundException {
    	
    	    Node.hsTradeOffFactor = 30000;
	        SystemInfoUtils systemInfoUtils = new SystemInfoUtilsImpl();
	        double bufferedMemorySize = systemInfoUtils.getTotalMemory() * 0.6;    //0.6 for buffer

	        buildDSTreeFromBinaryDataFile(fileName, null, threshold, segmentSize, bufferedMemorySize, -1, tsLength);
	        System.out.println("Finished!!!");
	    }
    public static  void testFindPairs() throws IOException, ClassNotFoundException {
        
    	double range =36085.0;
        double paaReduceRatio = 0.01;
        int n=1024;
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength,1024);
        double[][] norm_series=new double[timeSeries.length][n];
        complex[] value=new complex[n];
        MyFFT dft=new MyFFT();
        int ll=timeSeries.length;
        complex[][] norm_values=new complex[ll][n];
        complex[][] dft_values=new complex[ll][n];
        complex[][] temp=new complex[ll][n];
        int count2=0;
      //  double t=1674595.0;
        double t=44.0;
        double ori_t=t;
        System.out.println("   amount  is   "+ll);
       // for(int ii=0;ii<100;ii++)
        //ll=100;
        for(int ii=0;ii<ll;ii++)
        {
        	norm_series[ii]=CalcUtil.z_Normalize(timeSeries[ii]);
        	for(int jj=0;jj<n;jj++)
        	    norm_values[ii][jj]=new complex(norm_series[ii][jj],0);
        	temp[ii]=dft.changedLow(norm_values[ii],n);
        	dft_values[ii]=dft.fft_2(temp[ii],n,1); 
        	        	
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        System.out.println("********************");
        int allpair=0;
        int skip=0;
        int skip2=0;
        int compare=0;
        int ori_count=0;
        int ori_count2=0;
        for(int ii=0;ii<ll;ii++)
        {
        	if(ii%2000==0)
        		System.out.println("   ii   is   "+ii+"   count2 is  "+count2+"  skip  is  "+skip+"  skip2   is  "+skip2);
        	for(int jj=ii+1;jj<ll;jj++)
        	{
        		//double ori_dis2=DistUtil.euclideanDist(norm_series[ii], norm_series[jj]);
        		double ori_dis=dft.DFT_Edistance( dft_values[ii],dft_values[jj],n);
        		
        	//	System.out.println("    original    is   "+ori_dis2  +" dft  is "+ori_dis/32);
        		if(ori_dis<t*32)
        			ori_count2++;
        		
        	}
        }
        System.out.println("   ori   count   is  "+ori_count2);
        for(int ii=0;ii<ll;ii++)
        {
        	if(ii%2000==0)
        		System.out.println("   ii   is   "+ii+"   count2 is  "+count2+"  skip  is  "+skip+"  skip2   is  "+skip2);
        	for(int jj=ii+1;jj<ll;jj++)
        	{
        		allpair++;
        		boolean temp2=dft.DFT_LessThan( dft_values[ii],dft_values[jj],200,(t*32)*(t*32));
        		if(!temp2)
        			skip2++;
        		if(temp2)
        		{
        			     boolean temp3=dft.DFT_LessThan( dft_values[ii],dft_values[jj],n,(t*32)*(t*32));
        			     if(!temp3)
        			    	 skip++;
        			     if(temp3)
        			     {
        			         double edis2=dft.DFT_Edistance( dft_values[ii],dft_values[jj],n);
        			         double ori_dis=DistUtil.euclideanDist(norm_series[ii], norm_series[jj]);
		        		//double edis3=dft.DFT_Edistance( norm_values[ii],norm_values[jj],50);
		        	//	double edis4=dft.DFT_Edistance( norm_values[ii],norm_values[jj],100);
		        	        // System.out.println("  the  distance   is  "+edis2+"   distance3   is  "+ori_dis);
		        		     if(edis2>t*32)
		        		     {
		        			     skip2++;
		        			     continue;
		        		      } 
				       		  else
				       		 {
				       			compare++;
				            	edis2=dft.DFT_Edistance( dft_values[ii],dft_values[jj],n);
				        		// System.out.println("  the  distance   is  "+edis2);
				        		if(edis2<t*32)
				        		    	count2++;
				        		}
        			     }
        		}
        
        	}
        }
       
        stopWatch.stop();
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime()+"  pairs  is  "+count2+"   allpair is "+allpair+"   skip  "+skip+" compare   is  "+compare+"  skip2  is  "+skip2);
       

      /*  AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        dsTreeAllPairFinder.findAllPairs(allPairs, range);
        stopWatch.stop();
        log.debug("stopWatch.getTime() = " + stopWatch.getTime());
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs = " + size);
        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        System.out.println("  the  size of allpairs    is   "+pairs.size());
        AllPairUtils.savePairList2File(pairs, fileName + ".DSTreePairs.txt");*/
    }
   

    public static void buildDSTreeFromBinaryDataFile(String fileName, String indexPath, int threshold, int segmentSize, double bufferedMemorySize, int maxTsCount, int tsLength) throws IOException, ClassNotFoundException {
        System.out.println("fileName = " + fileName);
        System.out.println("tsLength = " + tsLength);
        FileBufferManager.fileBufferManager = null;
        FileBufferManager.getInstance().tsLength = tsLength;
        FileBufferManager.getInstance().setBufferedMemorySize(bufferedMemorySize);
        FileBufferManager.getInstance().setThreshold(threshold);

        //init indexPath if null
        if (indexPath == null)
            indexPath = fileName;
        indexPath = indexPath + ".idx_dyn";
        indexPath = indexPath + "_" + threshold + "_" + segmentSize;
        if (maxTsCount > 0) {
            indexPath = indexPath + "_" + maxTsCount;
        }
        System.out.println("indexPath = " + indexPath);
        File file = new File(indexPath);
        if (file.exists()) {
            System.out.println("indexPath: " + indexPath + " exists! cleaning...");
            FileUtils.cleanDirectory(file);
        } else {
            boolean b = file.mkdirs();
        }

        Node root = new Node(indexPath, threshold);

        //init helper class instances
        INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[1];
        nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
//        nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
        root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

        MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
        root.setSeriesSegmentSketcher(seriesSegmentSketcher);
        root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(seriesSegmentSketcher));

        root.setRange(new MeanStdevRange());

        //calc the split points by segmentSize
        short[] points = IndexBuilder.calcPoints(tsLength, segmentSize);
        root.initSegments(points);

        int count = 0;
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);

        for (int i = 0; i < timeSeries.length; i++) {
            double[] timeSery = timeSeries[i];
            root.insert(timeSery);
            count++;
            if (count % 10000 == 0)
                log.debug("count = " + count);
            if (maxTsCount > 0) {
                if (count >= maxTsCount)
                    break;
            }
        }
        FileBufferManager.getInstance().saveAllToDisk();
        String indexFileName = indexPath + "\\" + "root.idx";
        root.saveToFile(indexFileName);
        Node newRoot = Node.loadFromFile(indexFileName);
        System.out.println("newRoot = " + newRoot);
        System.out.println("FileBufferManager.getInstance().ioRead = " + FileBufferManager.getInstance().ioRead);
        System.out.println("FileBufferManager.getInstance().ioWrite = " + FileBufferManager.getInstance().ioWrite);
        System.out.println("FileBufferManager.getInstance().ioDelete = " + FileBufferManager.getInstance().ioDelete);
    }
}
