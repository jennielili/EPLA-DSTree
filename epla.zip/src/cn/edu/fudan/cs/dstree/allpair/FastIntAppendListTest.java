package cn.edu.fudan.cs.dstree.allpair;

import org.apache.commons.lang.time.StopWatch;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class FastIntAppendListTest {

    private static final int MAX_COUNT = 1000 * 1000 * 100;
//    private static final int MAX_COUNT = 2 * 100;

    @Test
    public void test1()
    {
        StopWatch stopWatch = new StopWatch();
        FastIntAppendList fastList = new FastIntAppendList(100);
        stopWatch.start();
        for (int i = 0; i < MAX_COUNT; i++) {
             fastList.append(i);
        }

        stopWatch.stop();
        System.out.println("stopWatch = " + stopWatch.getTime());

        System.out.println("fastList.getCapacity() = " + fastList.getCapacity());

        System.out.println("fastList.get(0) = " + fastList.get(0));

        StopWatch stopWatch1 = new StopWatch();
        stopWatch1.start();
        int sum = 0;
        for (int i = 0; i < MAX_COUNT; i++) {
            int i1 = fastList.get(i);
            sum += i1;
        }
        stopWatch1.stop();
        System.out.println("stopWatch1 = " + stopWatch1.getTime());
        System.out.println("sum = " + sum);
    }

    @Test
    public void test2()
    {
        StopWatch stopWatch = new StopWatch();
        List<Integer> list = new ArrayList(100);
        stopWatch.start();
        for (int i = 0; i < MAX_COUNT; i++) {
            list.add(i);
        }

        stopWatch.stop();
        System.out.println("stopWatch = " + stopWatch.getTime());

        StopWatch stopWatch1 = new StopWatch();
        stopWatch1.start();
        int sum = 0;
        for (int i = 0; i < MAX_COUNT; i++) {
            int i1 = list.get(i);
            sum += i1;
        }
        stopWatch1.stop();
        System.out.println("stopWatch1 = " + stopWatch1.getTime());
        System.out.println("sum = " + sum);
    }

    @Test
    public void test3()
    {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        int[] array = new int[MAX_COUNT];
        for (int i = 0; i < MAX_COUNT; i++) {
            array[i] = i;
        }

        stopWatch.stop();
        System.out.println("stopWatch = " + stopWatch.getTime());

        StopWatch stopWatch1 = new StopWatch();
        stopWatch1.start();
        int sum = 0;
        for (int i = 0; i < MAX_COUNT; i++) {
            int i1 = array[i];
            sum += i1;
        }
        stopWatch1.stop();
        System.out.println("stopWatch1 = " + stopWatch1.getTime());
        System.out.println("sum = " + sum);
    }

    @Test
    public void test4()
    {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AutoExpandIntArray autoArray = new AutoExpandIntArray(100);
        autoArray.setExpandFactory(1.5);
        for (int i = 0; i < MAX_COUNT; i++) {
            autoArray.append(i);
        }

//        autoArray.shrink();
        stopWatch.stop();
        System.out.println("stopWatch = " + stopWatch.getTime());

        System.out.println("autoArray.getCapacity() = " + autoArray.getCapacity());

        StopWatch stopWatch1 = new StopWatch();
        stopWatch1.start();
        autoArray.shrink();
        int sum = 0;

        int[] array = autoArray.getArray();
        for (int i = 0; i < MAX_COUNT; i++) {
            int i1 = array[i];
            sum += i1;
        }
        stopWatch1.stop();
        System.out.println("stopWatch1 = " + stopWatch1.getTime());
        System.out.println("sum = " + sum);
    }
}
