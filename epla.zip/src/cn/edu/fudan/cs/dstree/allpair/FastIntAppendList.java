package cn.edu.fudan.cs.dstree.allpair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class FastIntAppendList {
    private int bucketSize;

    public FastIntAppendList(int bucketSize) {
        this.bucketSize = bucketSize;
        this.size = 0;
        this.offsetInBucket = bucketSize - 1; //trigger expand for the first time
    }

    List<int[]> innerList = new ArrayList<int[]>();

    private int size;
    private int offsetInBucket;
    private int[] bucket;
    public int getSize()
    {
        return size;
    }

    public void append(int value)
    {
        size ++;
        offsetInBucket ++;
        if (offsetInBucket == bucketSize)
        {
            bucket = new int[bucketSize];
            innerList.add(bucket);
            offsetInBucket = 0;
        }

        bucket[offsetInBucket] = value;
    }

    public int get(int i)
    {
        int bucketIdx = i / bucketSize;
        int offset = i % bucketSize;
        return innerList.get(bucketIdx)[offset];
    }

    public int getCapacity()
    {
        return bucketSize * innerList.size();
    }
}
