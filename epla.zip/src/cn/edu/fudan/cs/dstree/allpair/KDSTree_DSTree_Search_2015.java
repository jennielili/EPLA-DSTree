package cn.edu.fudan.cs.dstree.allpair;
//import java.util.*;
import java.text.DecimalFormat;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import org.apache.commons.lang.math.IntRange;
import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.io.IntWritable;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexExactSearcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import java.io.BufferedWriter;
import java.io.FileWriter;
public class KDSTree_DSTree_Search_2015 {

	/**
	 * @param args
	 */
	HashMap<Integer, String> node2IdxMap = new HashMap<Integer, String>();
	private int segmentLevel=6;
	List<IntRange> segments;
	private int dimCount;
    int threshold=100;
    private float sampleRate;
    public static int tsLength = 1000;
    public static int size = 400000;
    private KDSTreeNode root;
    private Node newroot;
	public  void buildTree(double[][] dataSet,int numCenters) throws IOException {
		
		// TODO Auto-generated method stub
		 System.out.println("  dataSet **************************       "+dataSet.length);
		 StopWatch stopWatch2 = new StopWatch();
		 stopWatch2.start();
		 segments = CalcUtil.generateSplitRanges(tsLength, segmentLevel);
		 dimCount = CalcUtil.generateSplitRanges(tsLength, segmentLevel).size();
		 System.out.println("  the size of segments  "+segments.size()+"   dimCount    is   "+dimCount);
		 double[][] temp=new double[dataSet.length][segments.size()];
		 int[] labels=new int[dataSet.length];
		 int[] interval=new int[segments.size()];
		 for (int i = 0; i < segments.size(); i++) {
             IntRange intRange = segments.get(i);
             int start = intRange.getMinimumInteger();
             int end = intRange.getMaximumInteger();
             interval[i]=end-start+1;
             System.out.println("  index    is   "+i+"    start   is  "+start+"   end   is   "+end);
          
         }
		 
		 for(int ii=0;ii<dataSet.length;ii++)
		 {
			 double[] ts = dataSet[ii];
             for (int i = 0; i < segments.size(); i++) {
                 IntRange intRange = segments.get(i);
                 int start = intRange.getMinimumInteger();
                 int end = intRange.getMaximumInteger();
            //    System.out.println("  start   is  "+start+"   end   is   "+end);
                 double avg = CalcUtil.avg(ts, start, end);
                 temp[ii][i] = avg;
               //  System.out.println("  ii  "+ii+"   i   "+i+"   "+temp[ii][i]);
                 
             }
           
		 }
		
		 int [] indexes=new int[dataSet.length];
		 for(int ii=0;ii<indexes.length;ii++)
		 {
			 indexes[ii]=ii;
		 }
		 root = new KDSTreeNode(temp, dimCount, 1, threshold,indexes);
		 System.out.println("*****************  indexes   length  "+indexes.length);
		 System.out.println("***************** root indexes   length  "+root.indexes.length);
		 root.buildTree();

        
	//	 String indexFileName="/home/hadoop/lqh/kdsindex";
		 List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         System.out.println("  number of leaves  "+leaves.size());
         
       //  root.saveToFile(indexFileName);
         StringBuilder  stringBuilder=new StringBuilder();
       //  root.printTree(stringBuilder);
         // clustering   here 
       //  List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         System.out.println("  number of leaves  "+leaves.size());
      //   double[][][] synopsis=new double[leaves.size()][dimCount][2];
         List<double[]> leafMins=new ArrayList();
         List<double[]> leafMaxs=new ArrayList();
         List<double[]>  medians=new ArrayList();
         double[][] medians2=new double[leaves.size()][1000];
       
    /*   for(int ii=0;ii<leaves.size();ii++)
         {
    	   String itemS="";
        	 KDSTreeNode leaf=leaves.get(ii);
        	 int start=leaf.getStart();
        	 int end=leaf.getEnd();
        	// for(int u=start;u<end;u++)
        		// itemS=itemS+" "+indexes[u];
        	 int median=(start+end)/2;
        	 int realIndex=indexes[median];
        	// System.out.println("   readIndex   *************   "+realIndex);
        	 medians.add(dataSet[realIndex]);
        	 double[][] temp2=leaf.getDataSet();
        	// System.out.println(" leaf   "+ii+" start  is "+leaf.getStart()+" end  "+leaf.getEnd()+"  splitValue  "+leaf.getParent().getSplitValue()+"  split dim  "+leaf.getParent().getSplitDim()+" weight "+leaf.getParent().getDimWeight(leaf.getParent().getSplitDim())+"     "+itemS);
        	 double[] synopsis_min=new double[dimCount];
        	 double[] synopsis_max=new double[dimCount];
        	 for(int k=0;k<dimCount;k++)
        	 {
        		 
        		 synopsis_min[k]=Double.MAX_VALUE;
        		 synopsis_max[k]=Double.MIN_VALUE; 
        	 }
        	 int start_dim=0;
        	 for(int k=start_dim;k<dimCount;k++)
        	 {
        		for(int jj=leaf.getStart();jj<leaf.getEnd();jj++)
        		{
        			if(temp2[jj][k]<synopsis_min[k])
        		          synopsis_min[k]=temp2[jj][k];
        			
        			if(temp2[jj][k]>synopsis_max[k])
      		          synopsis_max[k]=temp2[jj][k];
        	     }
        	 
               }
        	 leafMins.add(synopsis_min);
        	 leafMaxs.add(synopsis_max);
        //	 System.out.println("  leaf   ii "+ii+"   max  "+ synopsis_max[4]+"    min  "+synopsis_min[4] );
         }
         */
         //compute   the  prunning   rate 
         int sum=0;
         
     	/*String name = "/home/hadoop/lqh/bound.txt";
     	FileWriter fw = new FileWriter(name);// ����FileWriter��������д���ַ���
     	BufferedWriter bw = new BufferedWriter(fw);
      for(int ii=0;ii<1;ii++)
         {
        	 int cc=0;
             int ss=leaves.get(ii).getStart();
        	 int ee=leaves.get(ii).getEnd();
        	 double[] median=dataSet[indexes[(ss+ee)/2]];
        	 double max=Double.MIN_NORMAL;
        	 double min=Double.MAX_VALUE;
        	 for(int j=ss;j<=ee;j++)
        	 {
        		 double[] items=dataSet[indexes[j]];
        		 double dists= DistUtil.euclideanDist(median, items);
        		 if(dists>max)
        			 max=dists;
        		 if(dists<min)
        			 min=dists;
        		 bw.write("    from   median  "+ii+"    j  "+j+"     "+dists);
        		 bw.newLine();
        		 
        	 }
        	 bw.write("    from   median   max   "+ii+"    "+max+"       min     "+min);
        	 for(int jj=ii+1;jj<leaves.size();jj++)
             {
        		 double[] synopsis_min1=leafMins.get(ii);
        		 double[] synopsis_min2=leafMins.get(jj);
        		 double[] synopsis_max1=leafMaxs.get(ii);
        		 double[] synopsis_max2=leafMaxs.get(jj);
        		 double dis=lowerBound(synopsis_min1,synopsis_max1,3,6,synopsis_min2,synopsis_max2,interval);
        		 double dis2=lowerBound(synopsis_min1,synopsis_max1,1,2,synopsis_min2,synopsis_max2,interval);
        		 double dis3=lowerBound(synopsis_min1,synopsis_max1,7,14,synopsis_min2,synopsis_max2,interval);
        		 double dis4=lowerBound(synopsis_min1,synopsis_max1,15,30,synopsis_min2,synopsis_max2,interval);
        		 double dis5=lowerBound(synopsis_min1,synopsis_max1,31,62,synopsis_min2,synopsis_max2,interval);
        	  //  if(ii>1050  && ii<=1055)
        		bw.write("  ii   leaves "+ii+"  dim "+leaves.get(ii).getSplitDim()+"   jj  leaves "+jj+" dim "+leaves.get(jj).getSplitDim()+"    "  +dis+"  second "+dis2+"  third "+dis3+"  fourth  "+dis4+"   fifth    "+dis5);
        		bw.newLine(); 
        		if(dis>0.5)
        		 { 
        			 sum++;
        			 cc++;
        			 if(cc>=1)
        				 break;
        		 }
        	 
             }
         }
        bw.close();
        fw.close();*/
         double sum2=0.0;
         initMap();
        
	    
       //  for(int ii=0;ii<dataSet.length;ii++)
	    	root.printTree(stringBuilder);
	    	System.out.println(stringBuilder);
	    	int size=root.getDataSet().length;
	    /* for(int tt=0;tt<size;tt++)
	     {
	    	 System.out.println("  the UUUUUUUUUUUUU "+tt+"     "+root.indexes[tt]);
	     }*/
	    	 StopWatch stopWatch = new StopWatch();
	    	 stopWatch.start();
         for(int ii=0;ii<1000;ii++)
         {
        	// KDSTreeNode leafNode = root.approximateSearch(dataSet[ii]);
        	 double[] temp2=new double[segments.size()];
        	/* double[] query=new double[tsLength];
        	 for(int u=0;u<tsLength;u++)
        	 {
        		 query[u]=dataSet[ii][u];
        		 if(u==100)
        			 query[u]+=0.2;
        	 }*/
        	 for (int i = 0; i < segments.size(); i++) {
                 IntRange intRange = segments.get(i);
                 int start = intRange.getMinimumInteger();
                 int end = intRange.getMaximumInteger();
            //    System.out.println("  start   is  "+start+"   end   is   "+end);
              //   double avg = CalcUtil.avg(dataSet[ii], start, end);
                 double avg = CalcUtil.avg(dataSet[ii], start, end);
                 temp2[i] = avg;
               //  System.out.println("  ii  "+ii+"   i   "+i+"   "+temp[ii][i]);
                 
            }
        	 
        	 KDSTreeNode nn=root.approximateSearch(temp2);
        	 
        	// int id=node2IdxMap.get(nn).get();
        	// System.out.println("*************   nn   level    "+nn.level+"  split dim "+nn.getSplitDim()+"   value "+nn.getSplitValue()+"   id   "+nn.getId()+"  start "+nn.getStart()+"  end "+nn.getEnd());
        	// KDSTreeNode leaf=leaves.get(id);
        //	 int start=leaf.getStart();
        	// int end=leaf.getEnd();
        	 int start=nn.getStart();
        	 int end=nn.getEnd();
        	 double min=Double.MAX_VALUE;
        	 double dist=-1;
        	 for(int t=start;t<=end;t++)
        	 {
        	   int realIndex=indexes[t];
        	   double[] item=dataSet[realIndex].clone();
        	//   if(realIndex==735)
        	//	   System.out.println("EEEEEEEEEEEEEEEEEEEEEEEEEEEE   rror  tt "+t+"  index "+indexes[t]+"  realIndex "+realIndex);
        	   dist= DistUtil.euclideanDist(dataSet[ii], item);
        	//  System.out.println(" *** dist    is   **************  "+dist);
        	   if(dist<min)
        		   min=dist;
        	 }
        	 System.out.println("   ii   "+ii+"   dist   is   "+min);
        	
         }
         System.out.println("  time  SEARCH spent   is    "+stopWatch.getTime());
         for(int tt=0;tt<indexes.length;tt++)
         {
        	 if(indexes[tt]==0)
        		 System.out.println("WWWWWWWWWWWWWWWWW222        "+tt);
         }
         //  System.out.println(stringBuilder.toString());
        /* StopWatch stopWatch3 = new StopWatch();
         Node root_dstree = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         NodeUtil.initDSTreeWithKDSTree(root, root_dstree);
         System.out.println("Transform   to     DSTree     "+stopWatch3.getTime());
         IndexExactSearcher indexExact=new IndexExactSearcher();
         indexExact.exactSearch_kds(dataSet[0], root_dstree,indexes,dataSet,node2IdxMap,tsLength);
         */
         
   
	}
	
	public double lowerBound(double[] min, double[] max,int start,int end, double[] min2,double[] max2, int[] segmentLength) {
		double sum = 0;
		//for (int i = start; i < min.length; i++) {
		for (int i = start; i <= end; i++) {
			double node1MaxAvg = max[i];
			double node1MinAvg = min[i];

			double node2MaxAvg = max2[i];
			double node2MinAvg = min2[i];

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength[i];
			}
		}

		sum = Math.sqrt(sum);
		return sum;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 
		 tsLength=Integer.parseInt(args[0]);
		 size=Integer.parseInt(args[1]);
		 System.out.println("  tsLength   is   "+tsLength+"   size   is   "+size);
		 KDSTree_DSTree_Search_2015  KDS=new KDSTree_DSTree_Search_2015();
		 
	//	 int size=200000;
	//	 int tsLength=1000;
		 Integer numCenters=Integer.parseInt(args[0]);
		// Integer size=Integer.parseInt(args[1]);
		 StopWatch stopWatch = new StopWatch();
	     stopWatch.start();
		 double[][] dataSet=new double[size][tsLength];
		 int[] indexes=new int[size];
		 for(int ii=0;ii<size;ii++)
		 {
			 indexes[ii]=ii;
		 }
		 
	//	double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\ucibinary", tsLength,size);
	     double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("/home/hadoop/lqh/ucibinary", tsLength,size);
		 KDS.buildTree(timeSeries,numCenters);
         System.out.println("  time  spent   is    "+stopWatch.getTime());
		 System.out.println("  ************************        successfully");
	}
	 private void initMap() throws IOException {
         //first order traverse to visit leaf node
		// newroot = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
		// NodeUtil.initDSTreeWithKDSTree( root,newroot);
		 List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         for (int i = 0; i < leaves.size(); i++) {
        	 KDSTreeNode node = leaves.get(i);
             node2IdxMap.put(node.getId(), node.getStart()+"\t"+node.getEnd());
         }
     }
}
