package cn.edu.fudan.cs.dstree.allpair;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.partition.Edge;
import cn.edu.fudan.cs.dstree.partition.Graph;
import cn.edu.fudan.cs.dstree.partition.Vertex;
public class GraphPartitioning_lzs {
	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		GraphPartitioning_lzs gp=new GraphPartitioning_lzs();
		Graph graph=gp.getGraphFromFile("d:\\dstree\\graph3");
		List<Vertex>  vertexes_o=graph.getVertexList();
		List<Edge>  edges_o=graph.getEdgeList();
		System.out.println("  number  of  vertexes  is  "+vertexes_o.size()+"   number of edges   is  "+edges_o.size());
		int k=32;
		int[] count=new int[k];
		for(int ii=0;ii<vertexes_o.size();ii++)
		{
			Vertex ver=vertexes_o.get(ii);
			ver.bitSet=new BitSet(k);
		}
		double cost=gp.computeCost(graph);
        System.out.println("  graph  load   number   is   "+graph.getTotalLoad()+"  mean  cost  is  "+cost/k);
        Graph[] subgraphs=gp.graphPartitioning_preorder(graph, k);
        int num_vertex=0;
        int num_edges=0;
        for(int ii=0;ii<k;ii++)
        {
        	Graph sub=subgraphs[ii];
        	List<Vertex>  vertexes2=sub.getVertexList();
    		List<Edge>  edges2=sub.getEdgeList();
    		num_vertex+=vertexes2.size();
    		num_edges+=edges2.size();
        	double load=sub.getTotalLoad();
        	List vertexes=sub.getVertexList();
        	List edges=sub.getEdgeList();
        	double cost2=gp.computeCost(sub);
        	System.out.println("   subgraph "+ii+"   load    is   "+load+"   vertexes is "+vertexes.size()+"   edges is "+edges.size()+"  workload   is  "+cost2);
        	
        }
        System.out.println(" Cost   is   "+cost);
        System.out.println("  all partitioning  edges   is  "+num_edges+"   vertexes   is  "+num_vertex);
        int total_count=0;
        double[] countTimes=new double[k];
        for(int ii=0;ii<vertexes_o.size();ii++)
		{
			Vertex ver=vertexes_o.get(ii);
			for(int jj=0;jj<k;jj++)
			{
				if(ver.bitSet.get(jj))
				{
					count[jj]++;
					countTimes[jj]+=ver.getLoad();
				}
			}
			
		}
        for(int ii=0;ii<k;ii++)
        {
        	System.out.println(" sub   graph "+count[ii]+"   number of time series   "+countTimes[ii]);
        	total_count+=count[ii];
        }
        System.out.println("vertex count:"+vertexes_o.size()+" total_count:"+total_count+" copy count:"+(total_count-vertexes_o.size()));
        
	}
	public Graph getGraphFromFile(String fineName) throws FileNotFoundException, IOException
	{
		 
		    FSTObjectInput in = new FSTObjectInput(new FileInputStream(fineName));
	        Graph graph = null;
	        try {
	            graph = (Graph) in.readObject(Graph.class);
	        } catch (Exception e) {
	            throw new IOException(e.getMessage());
	        }
	        in.close();
	        return graph;
	        
	}
	public Graph[] graphPartitioning(Graph graph, int k, double meanCost)
	{
	//	Collections.sort(graph.getVertexList(),new ComparatorClass());
		HashMap<Vertex, List<Edge>> neighbors=graph.computeNeighbors();
		List<Vertex>  vertexes=graph.getVertexList();
		
		Graph[] subgraphs=new Graph[k];
	    Queue<Edge> queue=new LinkedList<Edge>();
	    int kk=0;
	    List<Vertex>[] newVertexes=new ArrayList[k];
	    List<Edge>[]   newEdges=new ArrayList[k];
	    
	    double meanVerCost=0.0;
	    for(int i=0;i<vertexes.size();i++)
	    {
	    	double load=vertexes.get(i).getLoad();
	    	meanVerCost+=load*(load-1)/2;
	    }
	    meanVerCost=meanVerCost/k;
	    double meanEdgCost=meanCost-meanVerCost;
	    
	    double cost=0.0;
	    for(int sgId=0;sgId<k;sgId++)
	    {
		    newVertexes[sgId]=new ArrayList();
		    newEdges[sgId]=new ArrayList();
		    subgraphs[sgId]=new Graph(newVertexes[sgId],newEdges[sgId]);
		    if(sgId>0)
		    {
		    	System.out.println("   cost  of  "+(sgId-1)+"   is    "+cost);
		 //   	System.out.println("   compute cost  of  "+(sgId-1)+"   is    "+);
		    }
		    
		    cost=0.0;
		    
		    while(cost<meanEdgCost)
		    {
		    	//System.out.println("  partitionid  "+vertexes.get(kk).getPartitionId());
		    	if(queue.isEmpty())
		    	{
			    	while(kk<vertexes.size() && vertexes.get(kk).getPartitionIdx()!=-1)
			    		kk++;
			    	if(kk>=vertexes.size())
			    		break;
			    	
			    	Vertex vv=vertexes.get(kk);
			    	vv.setPartitionIdx(sgId);
			    	vv.bitSet.set(sgId, true);
			    	newVertexes[sgId].add(vv);
			    	/*
					cost+=vv.getLoad()*(vv.getLoad()-1)/2;
					 if(cost>meanCost)
						 break;
						 */
			    	
					List<Edge> neighs=neighbors.get(vv);
			    	if(neighs!=null)
			    	for(int ii=0;ii<neighs.size();ii++)
			    	{
			    		Edge ee=neighs.get(ii);
			    		Vertex v1=ee.getVertex1();
			    		Vertex v2=ee.getVertex2();
			    		if(v1.getId()!=vv.getId())
			    		{
			    			if(v1.getPartitionIdx()!=-1)
			    				queue.add(ee);
			    		}
			    		if(v2.getId()!=vv.getId())
			    		{
			    			if(v2.getPartitionIdx()!=-1)
			    				queue.add(ee);
			    		}
			    	}
			    	
		    	}
		    	while(queue.size()>0)
				{
			    	
					Edge ed=queue.poll();
					cost+=ed.getVertex1().getLoad()*ed.getVertex2().getLoad();
					newEdges[sgId].add(ed);
		    		
					ed.getVertex1().bitSet.set(sgId, true);
					ed.getVertex2().bitSet.set(sgId, true);
					
					if(cost>=meanEdgCost)
					{
						  break;
					}
					
				    Vertex v1=ed.getVertex1();
		    		if(v1.getPartitionIdx()!=-1)
		    		{
		    			v1=ed.getVertex2();
		    		}
		    		if(v1.getPartitionIdx()==-1)
		    		{
			    		 v1.setPartitionIdx(sgId);
			    		 v1.bitSet.set(sgId,true);
			    		 newVertexes[sgId].add(v1);
			    		 /*
			    		 cost+=v1.getLoad()*(v1.getLoad()-1)/2;
			    		 */
			    		 
						 List<Edge> neighs=neighbors.get(v1);
					     for(int ii=0;ii<neighs.size();ii++)
					    {
					    		Edge ee=neighs.get(ii);
					    		Vertex v=ee.getVertex1();
					    		Vertex vv2=ee.getVertex2();

					    		if(v.getPartitionIdx()!=-1)
					    		{
					    			v=ee.getVertex2();
					    		}
					    		if(v.getPartitionIdx()==-1)
					    			queue.add(ee);
					    	}
					     /*
						 if(cost>meanCost)
							 break;
							 */
		    		} 
		  		}	//while
									
		 	}
		  //  System.out.println("  number "+sgId+"   is  "+newVertexes[sgId].size());
	    }
	    for(int ii=0;ii<k;ii++)
	    {
	        Graph sg=subgraphs[ii];
	        List<Edge> sgEdges=sg.getEdgeList();
	        List<Vertex> sgVertexes=sg.getVertexList();
	        //sgVertexes.clear();
	        
	        double edgesCost=0.0;
	        for(int jj=0; jj<sgEdges.size(); jj++)
	        {
	        	Vertex v1=sgEdges.get(jj).getVertex1();
	        	Vertex v2=sgEdges.get(jj).getVertex2();
	        	edgesCost+=v1.getLoad()*v2.getLoad();
	        }
	        for(int jj=0; jj<vertexes.size(); jj++)
	        {
	        	if(vertexes.get(jj).bitSet.get(ii) && vertexes.get(jj).getPartitionIdx()!=ii)
	        		sgVertexes.add(vertexes.get(jj));
	        	
	        }
	        
	        System.out.println("   edges count "+sgEdges.size()+ " cost  of  "+ii+"   is    "+edgesCost);
	        
	    }
	    /*
	    for(int ii=0;ii<vertexes.size();ii++)
	    {
	    	vertexes.get(ii).setPartitionId(-1);
	    }
	    */
	    return subgraphs;
	}
	
	public Graph[] graphPartitioning_preorder(Graph graph, int k)
	{
	//	Collections.sort(graph.getVertexList(),new ComparatorClass());
		HashMap<Vertex, List<Edge>> neighbors=graph.computeNeighbors();
		List<Vertex>  vertexes=graph.getVertexList();
		List<Edge>  edges=graph.getEdgeList();
		Graph[] subgraphs=new Graph[k];
	    int kk=0;
	    List<Vertex>[] newVertexes=new ArrayList[k];
	    List<Edge>[]   newEdges=new ArrayList[k];
	    double[] costs=new double[k];
	    double load=0.0;
	    for(int i=0;i<vertexes.size();i++)
	    {
	    	load+=vertexes.get(i).getLoad();
	    	
	    }
	    double meanLoad=load/k;
	    System.out.println("  meanLoad    is    "+meanLoad);
	    int pos=0;
	    for(int sgId=0;sgId<k;sgId++)
	    {
		    newVertexes[sgId]=new ArrayList();
		    newEdges[sgId]=new ArrayList();
		    subgraphs[sgId]=new Graph(newVertexes[sgId],newEdges[sgId]);
		    double subLoad=0.0;
		    while(subLoad<meanLoad && pos<vertexes.size())
		    {
		    	//System.out.println("  partitionid  "+vertexes.get(kk).getPartitionId());
		    	Vertex vv= vertexes.get(pos); 	
		    	newVertexes[sgId].add(vv);
		    	vv.setPartitionIdx(sgId);
		    	vv.bitSet.set(sgId, true);
		    	costs[sgId]+=vv.getLoad()*(vv.getLoad()-1)/2;
		    	pos++;
		    	subLoad+=vv.getLoad();
		    }
	    }
	    for(int ii=0;ii<edges.size();ii++)
	    {
	    	Edge edge=edges.get(ii);
	    	int partitionId1=edge.getVertex1().getPartitionIdx();
	    	int partitionId2=edge.getVertex2().getPartitionIdx();
	    	if(costs[partitionId1]>=costs[partitionId2])
	    	{
	    		subgraphs[partitionId2].getEdgeList().add(edge);
	    		edge.getVertex1().bitSet.set(partitionId2,true);
	    		
	    	}
	    	else
	    	{
	    		subgraphs[partitionId1].getEdgeList().add(edge);
	    		edge.getVertex2().bitSet.set(partitionId1,true);
	    	}
	    		
	    }
	    return subgraphs;
	}
	public double computeCost(Graph graph)
	{
		double cost=0.0;
		List<Vertex> vertexList=graph.getVertexList();
		List<Edge> edgeList=graph.getEdgeList();
		for (int j = 0; j < edgeList.size(); j++) {
             Edge edge = edgeList.get(j);
             Vertex vertex1 = edge.getVertex1();
             Vertex vertex2 = edge.getVertex2();
             double load1=vertex1.getLoad();
             double load2=vertex2.getLoad();
             cost+=(load1*load2);
		}
		for (int j = 0; j < vertexList.size(); j++) {
			Vertex vertex1 = vertexList.get(j);
			double load1=vertex1.getLoad();
			cost+=load1*(load1-1)/2;
		}
		return cost;
		
	}

}
