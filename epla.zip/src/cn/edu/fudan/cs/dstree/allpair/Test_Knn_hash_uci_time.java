package cn.edu.fudan.cs.dstree.allpair;
import java.io.*;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import java.util.*;
public class Test_Knn_hash_uci_time {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader aa=new BufferedReader(new FileReader("/home/hadoop/lqh/aa4.txt"));
	//	BufferedReader ac=new BufferedReader(new FileReader("/workspace/lqh/wiki/test2/part-r-00000"));
		//	BufferedReader bb=new BufferedReader(new FileReader("d:\\result_1000_new
		FileWriter fw2 =new FileWriter("test2.txt"); ;
		BufferedWriter bw = new BufferedWriter(fw2);
		int rep=0;
		int count=0;
		int length=1000;
		int m=20000;
		int[] mount=new int[10000];
		int max=10000;
		double[] a=new double[length];
		double[] p=new double[length];
		int maxHash=0;
		int minHash=0;
		double r=5;
		double b=0.01;
		for(int ii=0;ii<length;ii++)
		{
			a[ii]=1.0;
		}
	//	Point ap=new Point(a,length);
		double[] item_int1=new double[length];
		double[] sum_item_int1=new double[length];
		int kk=0;
	//	FileWriter fw2 =new FileWriter("uci0.txt");
		//BufferedWriter bw = new BufferedWriter(fw2); 
		int nn=0;
		List<Point> pointList=new ArrayList();
		Point[] pointArray=new Point[10000];
		List<Double[]> doubleList=new ArrayList();
		String newLine;
		String[] values;
		String items1[];
		List<Double> newd;
		Point np;
		Point p1;
		long begin = System.currentTimeMillis();
		while(aa.ready() && nn<10000)
		{
			
			nn++;
			newLine=aa.readLine();
			values=newLine.split("\t");
			items1=values[1].split(" ");
			if(kk%1000==0)
			{
				System.out.println("  kk  is "+kk+"   minHash  is  "+minHash+"  maxHash   is "+maxHash);
			}
			double mysum=0.0;
			if(items1.length==length)
			{
				
				p1=new Point(items1,length);
				newd=p1.normalized();
				Double[] temp=p1.normalized2();
				doubleList.add(temp);
				for (int jj=0;jj<newd.size();jj++)
				{
					mysum+=newd.get(jj)*newd.get(jj);
				}
				//System.out.println("   mysum    is  "+mysum);
				np=new Point(newd);
				
				pointList.add(np);
				pointArray[kk]=np;
				kk++;
			//	System.out.println("  point   is  "+np.toString());
			
				
				
			}
			else
				continue;
			
			
		}
		long ss=System.currentTimeMillis();
		for(int ii=0;ii<10000;ii++)
			for(int jj=ii+1;jj<10000;jj++)
			{
				//int diff=Math.abs(pointList.get(ii).hash-pointList.get(jj).hash);
				double dis=Tool.distanceSimple(pointList.get(ii), pointList.get(jj));
			//	double tt=(diff-1)*5/33;
			//	if(dis<tt)
			//	 System.out.println("  ii  is  "+ii+"  jj  is  "+jj+" hash diff is "+diff+"  distance  is  "+Tool.distanceSimple(pointList.get(ii), pointList.get(jj))+" dis should great than   "+tt*tt);
			}
		 long end = System.currentTimeMillis();
		 long second = (end - ss) ;
		 System.err.println(" takes " + second + " seconds");
		 int count_6=0;
		 for(int ii=0;ii<10000;ii++)
			 for(int jj=ii;jj<10000;jj++)
			 {
				 double temp=0.0;
				 double sum=0.0;
				 Double[] ele1=doubleList.get(ii);
				 Double[] ele2=doubleList.get(jj);
				 for(int i=0; i<1000; i++) {
						temp = (ele1[i]-ele2[i])*(ele1[i]-ele2[i]);
					//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
						sum += temp;
					}
				 if(sum<=6.63)
				 {
					 count_6++;
					 if(count_6%1000==0)
						 System.out.println("  the count  is  "+count_6);
						 
				 }
			 }
		 
		 long end2 = System.currentTimeMillis();
		 long second2 = (end-end2) / 1000;
		 System.err.println(" takes  22222222 " + second2 + " seconds2"+"  count  is "+count_6);
		
	}
	
	
	public static Double distanceSimpleDoubles(Double[] d1, Double[] d2) {
		double sum = 0.0;
		Double a = 0.0;
		//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<d1.length; i++) {
			a = (d1[i]-d2[i])*(d1[i]-d2[i]);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
		}
		//return Math.sqrt(sum);
		return sum;
	}

}
