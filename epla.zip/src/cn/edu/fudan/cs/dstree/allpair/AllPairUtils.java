package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairUtils {
    public static boolean verify(double[][] timeSeries, AutoExpandIntArray array, double range) {
        array.shrink();
        int[] array1 = array.getArray();
        for (int i = 0; i < array1.length; i += 2) {
            int i1 = array1[i];
            int i2 = array1[i + 1];
            double dist = DistUtil.euclideanDist(timeSeries[i1], timeSeries[i2]);
            if (dist > range) {
                System.out.println("i1 = " + i1);
                System.out.println("i2 = " + i2);
                System.out.println("dist = " + dist);
                return false;
            }
        }
        return true;
    }

    public static boolean checkNoDuplicate(AutoExpandIntArray array) {
        array.shrink();
        int[] array1 = array.getArray();
        int c = 0;

        HashSet<String> set = new HashSet();
        for (int i = 0; i < array1.length; i += 2) {
            int i1 = array1[i];
            int i2 = array1[i + 1];
            if (i1 == i2)
            {
                System.out.println("i2=i1 = " + i1);
//                return false;
            }

            String key = "";
            if (i1 < i2)
                key = i1 + ":" + i2;
            else
                key = i2 + ":" + i1;

            if (set.contains(key)) {
                System.out.println("key = " + key);
                c++;
//                return false;
            }
            set.add(key);

        }
//        System.out.println("c = " + c);
        return true;
    }

    public static List<Pair> array2PairList(AutoExpandIntArray inputArray) {
        List<Pair> list = new ArrayList<Pair>(inputArray.size()/2);
        inputArray.shrink();
        int[] array = inputArray.getArray();
        for (int i = 0; i < array.length; i+=2) {
            int i1 = array[i];
            int i2 = array[i+1];
            Pair pair = new Pair(i1, i2);
            pair.sort();
            list.add(pair);
        }
        return list;
    }

    public static void savePairList2File(List<Pair> pairList, String fileName) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < pairList.size(); i++) {
            Pair pair = pairList.get(i);
            sb.append(pair.getIdx1() + "," + pair.getIdx2()).append("\n");
        }
        FileUtils.writeStringToFile(new File(fileName), sb.toString());
    }

    public static int[] calcPoints(int tsLength, int segmentSize) {
        int avgLength = tsLength / segmentSize;
        int[] points = new int[segmentSize];
        for (int i = 0; i < points.length; i++) {
            points[i] = (short) ((i + 1) * avgLength);
        }

        //set the last one
        points[points.length - 1] = (short) tsLength;
        return points;
    }

    public static double[] avgBySegments(double[] timeSeries, int[] segments) {
        double[] ret = new double[segments.length];
        int start = 0, end;
        for (int i = 0; i < ret.length; i++) {
            end = segments[i];
            ret[i] = CalcUtil.avg(timeSeries, start, end);
            start = end;
        }
        return ret;
    }

    public static boolean lowerBoundLessThan(double[] ts1, double[] ts2, int segmentLength, double range) {
        double rangeSquare = range * range / segmentLength;
        double sumSquare = 0;
        for (int i = 0; i < ts1.length; i++) {
            final double dp = ts1[i] - ts2[i];
            sumSquare += dp * dp;
            if (sumSquare > rangeSquare)
                return false;
        }
        return true;
    }
}
