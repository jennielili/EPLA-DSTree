package cn.edu.fudan.cs.dstree.allpair;


public class MyFFT{
public MyFFT(){
  
}
/*
*ʵ�ֵ���
**/
public static complex[] changedLow(complex[] a,int length){
           int mr=0;   
           for(int m=1;m<length;++m){
           int l=length/2;
           while(mr+l>=length){
              l=l>>1;    //�����൱��,l����2
           }
           mr=mr%l+l;
           if(mr>m){
              complex t=new complex();
              t=a[m];
              a[m]=a[mr];
              a[mr]=t;
           }
           }

   return a;
}
/*
*�˻�����
**/
public static complex complex_exp(complex z){
   complex r=new complex();
   double expx=Math.exp(z.r);
   r.r=expx*Math.cos(z.i);
   r.i=expx*Math.sin(z.i);
   return r;
}
public double Edistance(complex[] value1,complex[] value2, int n)
{
	double sum=0.0;
	int limit=0;
	if(value1.length>=n)
		limit=n;
	else
		limit=value1.length;
	for(int i=0;i<limit;i++)
	{
	//	System.out.println("   2 i    is   "+value2[i].i+" 2 r is   "+value2[i].r+"    i    is   "+i);
	//	System.out.println("   1 i    is   "+value1[i].i+"1 r is   "+value1[i].r+"   i      is    "+i);
		double dis=(value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r);
	    sum+=dis;
	}
	//return sum;
	return Math.sqrt(sum);
	
}
public static double Pdistance(complex[] value1,complex[] value2, int n)
{
	double sum=0.0;
	int limit=0;
	if(value1.length>=n)
		limit=n;
	else
		limit=value1.length;
	for(int i=0;i<limit;i++)
	{
	//	System.out.println("   2 i    is   "+value2[i].i+" 2 r is   "+value2[i].r+"    i    is   "+i);
	//	System.out.println("   1 i    is   "+value1[i].i+"1 r is   "+value1[i].r+"   i      is    "+i);
		double dis=Math.sqrt((value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r));
	    sum+=dis;
	}
	return sum;
	
}
public double DFT_Edistance(complex[] value1,complex[] value2, int mm, int length)
{
	double sum=0.0;
	int limit=0;
	for(int i=0;i<mm;i++)
	{
	//	System.out.println("   2 i    is   "+value2[i].i+" 2 r is   "+value2[i].r+"    i    is   "+i);
	//	System.out.println("   1 i    is   "+value1[i].i+"1 r is   "+value1[i].r+"   i      is    "+i);
		double dis=(value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r);
	    sum+=dis;
	    
	}
	//return sum;
	//return Math.sqrt(sum);
	return Math.sqrt(sum/length);
	
}
public double DFT_Edistance_square(complex[] value1,complex[] value2, int n)
{
	double sum=0.0;
	int limit=0;
	if(value1.length>=n)
		limit=n;
	else
		limit=value1.length;
	for(int i=0;i<limit;i++)
	{
	//	System.out.println("   2 i    is   "+value2[i].i+" 2 r is   "+value2[i].r+"    i    is   "+i);
	//	System.out.println("   1 i    is   "+value1[i].i+"1 r is   "+value1[i].r+"   i      is    "+i);
		double dis=(value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r);
	    sum+=dis;
	    
	}
	//return sum;
	return sum/1024;
	
}
public boolean DFT_LessThan(complex[] value1,complex[] value2, int n,double t)
{
	double sum=0.0;
	int limit=0;
	if(value1.length>=n)
		limit=n;
	else
		limit=value1.length;
	for(int i=0;i<limit;i++)
	{
	//	System.out.println("   2 i    is   "+value2[i].i+" 2 r is   "+value2[i].r+"    i    is   "+i);
	//	System.out.println("   1 i    is   "+value1[i].i+"1 r is   "+value1[i].r+"   i      is    "+i);
		double dis=(value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r);
	    sum+=dis/value1.length;
	    if(sum>t)
	    	return false;
	    
	}
	return true;
	//return Math.sqrt(sum)/Math.sqrt(value1.length);
	
}
/*
*��-2 fft���α任 
*fft_tepy=1���任, -1���任
**/
public static complex[] fft_2(complex[] a,int length,int fft_tepy){
  
     double pisign=fft_tepy*Math.PI;
   // System.out.print(" pisign:"+pisign+"\n");
     complex t=new complex();
   int l=1;
  
   while(l<length){
    for(int m=0;m<l;++m){
     int temp_int=l*2; //�����൱��,l����2
     for(int i=m;temp_int<0?i>=(length-1):i<length;i+=temp_int){
      complex temp=new complex(0.0,m*pisign/l);

      complex temp_exp=complex_exp(temp);     
      t.r=a[i+l].r*temp_exp.r-a[i+l].i*temp_exp.i;
      t.i=a[i+l].r*temp_exp.i+a[i+l].i*temp_exp.r;
     
      a[i+l].r=a[i].r-t.r;
      a[i+l].i=a[i].i-t.i;
      a[i].r=a[i].r+t.r;
      a[i].i=a[i].i+t.i;
     
     } // end for i
   
    } // end for m
//    System.out.print("\n now is the loop and l="+l+"\n");
   for(int c=0;c<length;c++){          
    //     System.out.print(a[c].r+"+j"+a[c].i+"\n");
        }
   
    l=l*2;
   }//end while
    //�����൱��,l����2
   return a;
}


complex b[];
/*
*
*main
*
*
**/
public static void main(String arg[]){
	MyFFT mf=new MyFFT();
   final int n=16;
  
   int dd[]=new int[n];
   mf.b= new complex[n];
   for(int c=0;c<n;c++){ //������ֵ    
    mf.b[c]=new complex(c,0);         
         // System.out.print(mf.b[c].r+"+j"+mf.b[c].i+"\n");
        }
        System.out.print("\n\n");
        
        mf.b=mf.changedLow(mf.b,n);
        mf.b=mf.fft_2(mf.b,n,-1);
        //���
        for(int c=0;c<n;c++){          
         System.out.print(mf.b[c].r+"+j"+mf.b[c].i+"\n");
        }
         
  
}

}


