package cn.edu.fudan.cs.dstree.allpair;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.ruedigermoeller.serialization.FSTObjectOutput;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class DistTreeNode2_2016 implements Comparable<DistTreeNode2_2016>, Serializable {
	//int[] refs={91,10,16,88,7,12,9,76,999,38888};
	//int[] refs={91,10,16,88,7,99,6,8,5,4};
	public List<double[]> refList;
    private static final Log log = LogFactory.getLog(DistTreeNode2_2016.class);
    public static long staticId=0;
    public boolean original=true;
    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long id=staticId++;
    double[] rangeTimes = new double[200];

    private final int threshold; //150
    DistTreeNode2_2016 parent;
    AutoExpandIntArray bufferArray; // at most threshold
    int level = 1;
    int idx = -1;  //ref idx
    int distanceTimes=-1; //parent distance bounds
    int[] lowAndUpper={-1,-1};
    double range;
    AutoExpandIntArray pairIdxArray = new AutoExpandIntArray(100);
    List<DistTreeNode2_2016> children = new ArrayList<DistTreeNode2_2016>(10);
    int count = 0;

    public int getParentRefMinTimes() {
        return distanceTimes;
    }

    public int getParentRefMaxTimes() {
        return distanceTimes + 1;
    }

    public int getParentRefIdx() {
        return parent.idx;
    }

    int[][] allRefBounds;

    public int[][] getAllRefBounds() {
    	
        if (allRefBounds == null) {
            allRefBounds = new int[level - 1][2];
            DistTreeNode2_2016 p = parent;
            int times = distanceTimes;
            for (int i = 0; i < allRefBounds.length; i++) {
                int[] allRefBound = allRefBounds[i];
            //    allRefBound[0] = p.idx;  //ref idx
               allRefBound[0] =level-i-1;
              //  allRefBound[0] =level-1;
                allRefBound[1] = times; //ref idx bound
              //   System.out.println("  level   "+(level-i-1)+"   ref   idx "+allRefBound[0]+"   times "+times+"node id   "+this.getId());
             //   pp+="\t"+times;
                times = p.distanceTimes;
                
                p = p.parent;
            }
        }
      //  System.out.println(pp);
        return allRefBounds;
    }
   
    public long approximateSearch(double[] queryTs) {
//      System.out.println("this.getFileName() = " + this.getFileName());
    	
      if (this.isLeaf())
          return this.getId();
      else //internal node
      {
    	  double tt=DistUtil.euclideanDist(queryTs, refList.get(this.level-1));
    	 // long distanceTime=Math.round(tt/this.range);
    	  int distanceTime=(int)(tt/range);
    	  for (int i = 0; i < children.size(); i++) { //todo: performance
              DistTreeNode2_2016 distTreeNode = children.get(i);
           //   System.out.println("  the  times  of child  "+i+"    is   "+distTreeNode.distanceTimes);
              if(distTreeNode.distanceTimes==distanceTime)
              {
            	  return distTreeNode.approximateSearch(queryTs);
              }
              else
              {
            	  if(distTreeNode.distanceTimes==-1)
            	  {
            		  int[] bounds=distTreeNode.lowAndUpper;
            		//  System.out.println(" distanceTime  is   "+distanceTime+" lower  is  "+bounds[0]+"   upper   is "+bounds[1]+"  node  id  "+distTreeNode.getId());
            		  if(distanceTime<=bounds[1] && distanceTime>=bounds[0] )
            			  return distTreeNode.getId();
            	  }
              }
            	  
          }
      }
    	  return -1;
      
  }
    public void supplement()
    {
    
    	List<Integer> lists=new ArrayList();
    	for (int i = 0; i < children.size(); i++) { //todo: performance
            DistTreeNode2_2016 distTreeNode = children.get(i);
            lists.add(distTreeNode.distanceTimes);
             //   
        }
    	
    	if(lists.get(0)>0)
    	{
    		int[] aa={0,lists.get(0).intValue()-1};
    		DistTreeNode2_2016 node=new DistTreeNode2_2016(this,aa,10,false,timeSeries,reducedTimeSeries);
    		
    		children.add(node);
    	}
    	for(int ii=0;ii<lists.size()-1;ii++)
    	{
    		int first=lists.get(ii);
    		int second=lists.get(ii+1);
    		if(second-first>1)
    		{
    			int[] aa={first+1,second-1};
        		DistTreeNode2_2016 node=new DistTreeNode2_2016(this,aa,10,false,timeSeries,reducedTimeSeries);
        		
        		
        		children.add(node);
    		}
    	}
    	int[] bb={lists.get(lists.size()-1)+1,Integer.MAX_VALUE};
		DistTreeNode2_2016 node=new DistTreeNode2_2016(this,bb,10,false,timeSeries,reducedTimeSeries);
		
		children.add(node);
    }
    public boolean canPruned(int[][] allRefBounds1, int[][] allRefBounds2) {
    	int min=Math.min(allRefBounds1.length,allRefBounds2.length );
    	
       // for (int i = 0; i < allRefBounds1.length; i++) {
    	//reverese the allRefBounds
    	for (int i = 0; i < min; i++) {
            int[] bound1 = allRefBounds1[allRefBounds1.length-i-1];
            int idx1 = bound1[0];
            int time1 = bound1[1];
            int[] bound2 = allRefBounds2[allRefBounds2.length-i-1];
            int idx2 = bound2[0];
            int time2 = bound2[1];
            if(Math.abs(time1-time2)>1)
            	return true;
        }

        return false;
    }
    public boolean canPruned_supplement(DistTreeNode2_2016 firstNode, DistTreeNode2_2016 secondNode) {
    	int[][] ref1=firstNode.getAllRefBounds();
    	int[][] ref2=secondNode.getAllRefBounds();
    	int[] ranges=firstNode.lowAndUpper;
    	int[] ranges2=secondNode.lowAndUpper;
    	int level=firstNode.level;
    	if(firstNode.original && !secondNode.original)
    	{
    		int level2=secondNode.level;
    		if(ref1.length>level2-1)
    		{
    			int times=ref1[level2-1][1];
    			if(times-ranges[1]>1 || ranges[0]-times>1)
    			{
    				//System.out.println("Node 1  BBBBB   "+firstNode.getId()+"    Node2    "+secondNode.getId());
    				return true;
    			}
    		}
    	}
    	if(secondNode.original && !firstNode.original)
    	{
    		if(ref2.length>level-1)
    		{
    			int times=ref2[level-1][1];
    			if(times-ranges[1]>1 || ranges[0]-times>1)
    			{
    				//System.out.println("Node 1     "+firstNode.getId()+"    Node2    "+secondNode.getId());
    				return true;
    			}
    		}
    	}
    	if(!secondNode.original && !firstNode.original)
    	{
    		int level2=secondNode.level;
    		if(ref1.length>level2-1)
    		{
    			int times=ref1[level2-1][1];
    			if(times-ranges[1]>1 || ranges[0]-times>1)
    			{
    		//		System.out.println("Node 1  BBBBB   "+firstNode.getId()+"    Node2    "+secondNode.getId());
    				return true;
    			}
    		}
    		if(ref2.length>level-1)
    		{
    			int times=ref2[level-1][1];
    			if(times-ranges[1]>1 || ranges[0]-times>1)
    			{
    				//System.out.println("Node 1  BBBBB   "+firstNode.getId()+"    Node2    "+secondNode.getId());
    				return true;
    			}
    		}
    		
    		
    	}
    	/*int min=Math.min(allRefBounds1.length,allRefBounds2.length );
    	
       // for (int i = 0; i < allRefBounds1.length; i++) {
    	//reverese the allRefBounds
    	for (int i = 0; i < min; i++) {
            int[] bound1 = allRefBounds1[allRefBounds1.length-i-1];
            int idx1 = bound1[0];
            int time1 = bound1[1];
            int[] bound2 = allRefBounds2[allRefBounds2.length-i-1];
            int idx2 = bound2[0];
            int time2 = bound2[1];
            if(Math.abs(time1-time2)>1)
            	return true;
        }
*/
        return false;
    }
    public boolean isLeaf() {
        return children.size() == 0;
    }

    double[][] timeSeries;
    public double[][] getTimeSeries() {
		return timeSeries;
	}

	public void setTimeSeries(double[][] timeSeries) {
		this.timeSeries = timeSeries;
	}

	public double[][] getReducedTimeSeries() {
		return reducedTimeSeries;
	}

	public void setReducedTimeSeries(double[][] reducedTimeSeries) {
		this.reducedTimeSeries = reducedTimeSeries;
	}

	double[][] reducedTimeSeries;
    int segmentLength;
    public DistTreeNode2_2016(DistTreeNode2_2016 parent,int[] bounds,int threshold,boolean original,double[][] timeSeries,double[][] reducedTimeSeries)
    {
    	this.lowAndUpper=bounds;
    	this.threshold=threshold;
    	this.original=false;
    	this.parent=parent;
    	this.timeSeries=timeSeries;
    	this.reducedTimeSeries = reducedTimeSeries;
    	 if (parent != null) {
             level = parent.level + 1;
             rangeTimes = parent.rangeTimes;
         } else {
             for (int i = 0; i < rangeTimes.length; i++) {
                 rangeTimes[i] = range * i;
             }
         }
    }
    public DistTreeNode2_2016(DistTreeNode2_2016 parent, int distanceTimes, double[][] timeSeries, double range, double[][] reducedTimeSeries, int segmentLength, int threshold,List<double[]> refList) {
        this.parent = parent;
        
        this.distanceTimes = distanceTimes;
        this.timeSeries = timeSeries;
        this.range = range;
        this.reducedTimeSeries = reducedTimeSeries;
        this.segmentLength = segmentLength;
        this.threshold = threshold;
        this.bufferArray = new AutoExpandIntArray(threshold);
        this.refList=refList;
        if (parent != null) {
            level = parent.level + 1;
            rangeTimes = parent.rangeTimes;
        } else {
            for (int i = 0; i < rangeTimes.length; i++) {
                rangeTimes[i] = range * i;
            }
        }
        //add by lqh
        this.refList=refList;
        this.idx = level-1;
    }

    public void addPairIdx(int pairIdx) {
        pairIdxArray.append(pairIdx);
    }
    public void saveToFile(String fileName) throws IOException {
//      FileOutputStream fos = new FileOutputStream(fileName);
//      ObjectOutputStream oos = new ObjectOutputStream(fos);
//      oos.writeObject(this);
//      fos.close();
      FSTObjectOutput out = new FSTObjectOutput(new FileOutputStream(fileName));
      out.writeObject(this);
      out.close(); // required !
  }

    public void appendTimeSeries(int appendIdx) {
//        log.debug("appendIdx = " + appendIdx);
        count++;
      // System.out.println("  appendIdx    is   "+appendIdx+"   idx   is   "+idx);
        if((bufferArray.size() < threshold))  //not overflow
      //  if ((bufferArray.size() < threshold) && (idx < 0))  //not overflow
        {
            bufferArray.append(appendIdx);

            if (bufferArray.size() >= threshold) //just overflow
            {
                int[] buffer = bufferArray.getArray();
              //    int refIdx = buffer[0];   original
             //   int refIdx = refs[level-1];   //add by lqh
             //   idx = refIdx;  //set idx
                for (int i = 0; i < buffer.length; i++) {
            //   modified by lqh    for (int i = 1; i < buffer.length; i++) {
                    int idx2 = buffer[i];
                    double distance = distanceTwo(refList.get(level-1), timeSeries[idx2]);

                    if (distance <= range) {
                       // addPairIdx(idx2);
                    	 DistTreeNode2_2016 childNode = getChildNode(0);
                    	 if (childNode == null) {
                    		 
                             childNode = new DistTreeNode2_2016(this, 0, timeSeries, range, reducedTimeSeries, segmentLength, threshold,refList);
                             childNode.appendTimeSeries(idx2);
                             children.add(childNode);
                             Collections.sort(children);
                          //   System.out.println("  get  here");
                            // return;
                         } else {
                        	// System.out.println("    idx2    is          "+idx2+"  "+bufferArray.size()+"  child  id   "+childNode.getId());
                  
                        	 childNode.appendTimeSeries(idx2);
                         }
                    	 
                    } else {
                        int times = (int) (distance / range);
                        if (times * range >= distance) // =3 ==> 2
                        {
                        	//System.out.println("AAAAAAAAAAAAAAAAAAAAAAAA");
                            times--;
                        }
                        DistTreeNode2_2016 childNode = getChildNode(times);
                        if (childNode == null) {
                            childNode = new DistTreeNode2_2016(this, times, timeSeries, range, reducedTimeSeries, segmentLength, threshold,refList);
                            childNode.appendTimeSeries(idx2);
                            children.add(childNode);
                            Collections.sort(children);
                        } else {
                            childNode.appendTimeSeries(idx2);
                        }
                    }
                }
             //   bufferArray.clear();
            }
            return;
        }

        //is overflowed
//        double[] thisTs = timeSeries[idx];
//        double[] appendTs = timeSeries[appendIdx];
        double distance = distanceTwo(refList.get(level-1), timeSeries[appendIdx]);
//       System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBBBBBB            get     here  "+appendIdx);
//        distCount ++;
//        int times = (int) Math.ceil(distance / range);
        if (distance <= range) {
          //  addPairIdx(appendIdx);
        	 DistTreeNode2_2016 childNode = getChildNode(0);
        	 if (childNode == null) {
                 childNode = new DistTreeNode2_2016(this, 0, timeSeries, range, reducedTimeSeries, segmentLength, threshold,refList);
                 childNode.appendTimeSeries(appendIdx);
                 children.add(childNode);
                 Collections.sort(children);
             } else {
                 childNode.appendTimeSeries(appendIdx);
             }
        } else {
            int times = (int) (distance / range);
           // System.out.println(" Here   distance    is    "+times);
            if (times * range >= distance)
                times--;
            DistTreeNode2_2016 childNode = getChildNode(times);
            if (childNode == null) {
                childNode = new DistTreeNode2_2016(this, times, timeSeries, range, reducedTimeSeries, segmentLength, threshold,refList);
                childNode.appendTimeSeries(appendIdx);
                children.add(childNode);
                Collections.sort(children);
            } else {
                childNode.appendTimeSeries(appendIdx);
            }
        }
    }

    public DistTreeNode2_2016 getChildNode(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) { //todo: performance
            DistTreeNode2_2016 distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return distTreeNode;
        }
        return null;
    }

    public int getChildNodeIdx(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode2_2016 distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return i;
        }
        return -1;
    }


    @Override
    public int compareTo(DistTreeNode2_2016 o) {
        return this.distanceTimes - o.distanceTimes;
    }

    public void findAllParis(AutoExpandIntArray allPairs) {
        //deal with self
//        log.debug("pairIdxArray = " + pairIdxArray.size());
//        log.debug("children = " + children.size());
//        log.debug("this = " + this); todo:
        int[] array = null;
        if (idx < 0) //==-1 without children
        {
            bufferArray.shrink();
            array = bufferArray.getArray();
//            log.debug("findAllPairsForIdxArray begin " + array.length);
            findAllPairsForIdxArray(array, allPairs);
//            log.debug("findAllPairsForIdxArray end");
        } else  //>=0  have children
        {
            pairIdxArray.shrink();
            //deal with idx and distanceTimes 0
            array = pairIdxArray.getArray();
            for (int i = 0; i < array.length; i++) {
                allPairs.append(idx, array[i]);
            }
            //deal with distanceTimes 0
//            log.debug("findAllPairsForIdxArray begin " + array.length);
            findAllPairsForIdxArray(array, allPairs);
//            log.debug("findAllPairsForIdxArray end");

            //deal with distanceTimes 0 and times 1, move down  //for this level
            DistTreeNode2_2016 childNode = getChildNode(1);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown begin " + this.toString() + " " + childNode.toString());
            findAllPairsBetweenIdxArrayAndNodeDown(this, idx, array, childNode, allPairs);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown end ");
        }

        //compare with other node //move up
        List<DistTreeNode2_2016> parentNodes = getParentSearchNodes();
        for (int i = 0; i < parentNodes.size(); i++) {
            DistTreeNode2_2016 distTreeNode = parentNodes.get(i);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown begin " + this.toString() + " " + distTreeNode.toString());
            findAllPairsBetweenIdxArrayAndNodeDown(this, idx, array, distTreeNode, allPairs);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown end " + this.toString() + " " + distTreeNode.toString());
        }


        //deal with children
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode2_2016 distTreeNode = children.get(i);
            distTreeNode.findAllParis(allPairs);
        }

//        log.debug("countForDown = " + countForDown);
    }

    private boolean canPruned(DistTreeNode2_2016 node1, DistTreeNode2_2016 node2) {
        boolean ret = false;
        if (node1.idx >= 0 && node2.idx >= 0) {
            double distance = cacheDistance(node1.idx, node2.idx);
            double times = distance / range;
            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)) || (times <= (Math.abs(node1.distanceTimes - node2.distanceTimes) - 2)))
//            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)))
                ret = true;
        }
        return ret;
    }

    private List<DistTreeNode2_2016> getParentSearchNodes() {
        List<DistTreeNode2_2016> ret = new ArrayList<DistTreeNode2_2016>();

        DistTreeNode2_2016 p = parent;
        int distTimes = distanceTimes;

        while (p != null) {
            DistTreeNode2_2016 childNode = p.getChildNode(distTimes + 1);
            if (childNode != null)
                ret.add(childNode);
            distTimes = p.distanceTimes;
            p = p.parent;
        }

        return ret;
    }

    public static int countForDown = 0;
    public static int countForDownWorked = 0;

    public static int prunedByParentBounds = 0;

    public static boolean newAlgorithm = true;

    private void findAllPairsBetweenIdxArrayAndNodeDown(DistTreeNode2_2016 refNode, int refIdx, int[] refArray, DistTreeNode2_2016 node, AutoExpandIntArray allPairs) {
        int allPairsOldSize = allPairs.size();
        if (node == null)
            return;
        //

        if (refIdx < 0)
            if (canPruned(refNode.getAllRefBounds(), node.getAllRefBounds())) {
//            System.out.println(refNode.idx + " skip, prune by parent bounds! " + node.idx);
                prunedByParentBounds++;
                return;
            }

        countForDown++;
        int idx1 = node.idx;

        if (refIdx < 0) {
            if (idx1 < 0) {
                node.bufferArray.shrink();

                if (newAlgorithm) {
                    //filter the refArray and exclude those distance to node.parentNode.refId is not in the bounds
                    AutoExpandIntArray candidateIds = new AutoExpandIntArray(refArray.length);
                    int parentRefIdx = node.getParentRefIdx();
//                node.distanceTimes
                    for (int i = 0; i < refArray.length; i++) {
                        int i1 = refArray[i];
                        double distance = cacheDistance(i1, parentRefIdx);
                        if (distance >= rangeTimes[node.distanceTimes - 1] && distance <= rangeTimes[node.distanceTimes + 2]) {
                            candidateIds.append(i1);
                        }
                    }
                    candidateIds.shrink();
                    findAllPairsBetweenIdxArrays(candidateIds.getArray(), node.bufferArray.getArray(), allPairs);
                } else {
                    findAllPairsBetweenIdxArrays(refArray, node.bufferArray.getArray(), allPairs);
                }
                //for node children
                //deal with children//size should be 0
//                for (int i = 0; i < node.children.size(); i++) {
//                    DistTreeNode2 distTreeNode = node.children.get(i);
//                    findAllPairsBetweenIdxArrayAndNodeDown(refIdx, refArray, distTreeNode, allPairs);
//                }
            } else //idx1 >=0
            {
                node.pairIdxArray.shrink();
                findAllPairsBetweenIdxArrays(refArray, node.pairIdxArray.getArray(), allPairs);
                findAllPairsBetweenIdxArrays(refArray, new int[]{idx1}, allPairs);

                //for node children
                //deal with children
                if (refNode != null) {
                    DistTreeNode2_2016 refParentNode = refNode.parent;
                    int refParentIdx = refParentNode.idx;
                    double distance = cacheDistance(refParentIdx, idx1);
//                    double distance = distance(refParentIdx, idx1);
                    double times = distance / range;

                    for (int i = 0; i < node.children.size(); i++) {
                        DistTreeNode2_2016 distTreeNode = node.children.get(i);
                        if ((times <= distTreeNode.distanceTimes + refNode.distanceTimes + 3) && (times > Math.abs(distTreeNode.distanceTimes - refNode.distanceTimes) - 2))
//                        if ((times <= distTreeNode.distanceTimes + refNode.distanceTimes + 3))
                            findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                } else {
                    for (int i = 0; i < node.children.size(); i++) {  //todo:
                        DistTreeNode2_2016 distTreeNode = node.children.get(i);
                        findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                }
            }
        } else {
            if (idx1 < 0) {
                node.bufferArray.shrink();
                findAllPairsBetweenIdxArrays(refArray, node.bufferArray.getArray(), allPairs);
                findAllPairsBetweenIdxArrays(new int[]{refIdx}, node.bufferArray.getArray(), allPairs);

                //for node children
                //deal with children//size should be 0
//                for (int i = 0; i < node.children.size(); i++) {
//                    DistTreeNode2 distTreeNode = node.children.get(i);
//                    findAllPairsBetweenIdxArrayAndNodeDown(refIdx, refArray, distTreeNode, allPairs);
//                }
            } else //idx1 >=0
            {
                double distance = cacheDistance(refIdx, idx1);
//                double distance = distance(refIdx, idx1);
                if (distance <= range) {
                    allPairs.append(refIdx, node.idx);
                }

                double times = distance / range;
//        if (distance <= 3 * range) {
                if (times <= 3) {
                    AutoExpandIntArray pairIdxArray1 = node.pairIdxArray;
                    pairIdxArray1.shrink();
                    int[] array = pairIdxArray1.getArray();

                    findAllPairsBetweenIdxArrays(refArray, array, allPairs);
                    //miss node.idx time series? so check it
                    findAllPairsBetweenIdxArrays(refArray, new int[]{node.idx}, allPairs);

                    findAllPairsBetweenIdxArrays(new int[]{refIdx}, array, allPairs);
                }

                //deal with children of target node
                for (int i = 0; i < node.children.size(); i++) {
                    DistTreeNode2_2016 distTreeNode = node.children.get(i);
//            if (times <= distTreeNode.distanceTimes + 3)
                    if ((times <= distTreeNode.distanceTimes + 3) && (times > distTreeNode.distanceTimes - 2)) {
                        //do with refNode's parent node
/*
                        DistTreeNode2 p = refNode.parent;
                        int cTimes = refNode.distanceTimes;
                        boolean parentPruned = false;
                        while (p != null)
                        {
//                            if (canPruned(p.idx, cTimes,distTreeNode.parent.idx, distTreeNode.distanceTimes))
//                            if (canPruned(p, distTreeNode))
                            {
                                parentPruned = true;
//                                System.out.println(refNode + "is pruned by parent = " + p + " for node " + distTreeNode);
                            }
                            cTimes = p.distanceTimes;
                            p = p.parent;
                        }
                        if (parentPruned)
                            continue;
*/

                        findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                }
            }
        }

        if (allPairs.size() > allPairsOldSize) {
            countForDownWorked++;
        }
    }

    private boolean canPruned(int idx1, int times1, int idx2, int times2) {
        boolean ret = false;
        if (idx1 >= 0 && idx2 >= 0) {
            double distance = cacheDistance(idx1, idx2);
            double times = distance / range;
//            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)) || (times < (Math.abs(node1.distanceTimes - node2.distanceTimes) - 2)))
            if ((times > (times1 + times2 + 3)) || (times < (Math.abs(times1 - times2) - 2)))
                ret = true;
        }
        return ret;
    }

    public static int distCount = 0;

    public static HashMap<Long, Double> distMap = new HashMap<Long, Double>();

    public double distance(int idx1, int idx2) {
        distCount++;
        return DistUtil.euclideanDist(timeSeries[idx1], timeSeries[idx2]);
    }
    public double distanceTwo(double[] series1, double[] series2) {
        distCount++;
        return DistUtil.euclideanDist(series1, series2);
    }
    public double cacheDistance(int idx1, int idx2) {
        long key = idx1 * 100000L + idx2;
        if (!distMap.containsKey(key)) {
            double distance = distance(idx1, idx2);
            distMap.put(key, distance);
            return distance;
        }
        return distMap.get(key);
    }

    public static long lowerBoundCount = 0;
    public static long distLessThanCount = 0;

    public void findAllPairsForIdxArray(int[] idxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        double[][] newTimes = new double[idxArray.length][];
        double[][] newReduced = new double[idxArray.length][];
        for (int i = 0; i < newTimes.length; i++) {
            newTimes[i] = timeSeries[idxArray[i]];
            newReduced[i] = reducedTimeSeries[idxArray[i]];
        }
        AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, newTimes, newReduced, segmentLength, range, pairsArray);
        /*for (int i = 0; i < idxArray.length; i++) {
            final int idx1 = idxArray[i];
            final double[] ts1 = timeSeries[idx1];
            for (int j = i + 1; j < idxArray.length; j++) {
                final int idx2 = idxArray[j];
//                final double[] ts2 = timeSeries[idx2];

                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    distLessThanCount++;
                    final double[] ts2 = timeSeries[idx2];
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(idx1, idx2);
                    }
                }
            }
        }*/
    }

    public void findAllPairsBetweenIdxArrays(int[] leftIdxArray, int[] rightIdxArray, AutoExpandIntArray pairsArray) {
        //do brute force search and resort the array in new order
        double[][] leftTimes = new double[leftIdxArray.length][];
        double[][] leftReduced = new double[leftIdxArray.length][];
        for (int i = 0; i < leftTimes.length; i++) {
            leftTimes[i] = timeSeries[leftIdxArray[i]];
            leftReduced[i] = reducedTimeSeries[leftIdxArray[i]];
        }

        double[][] rightTimes = new double[rightIdxArray.length][];
        double[][] rightReduced = new double[rightIdxArray.length][];
        if(leftIdxArray==null || rightIdxArray==null )
        {	System.out.println("  Alert    it   is   null  maybe it is virtual ");
        	return;
        }
     //   System.out.println("  AAAAAAAA  time series length "+timeSeries.length);
       // System.out.println("  length   is   "+rightIdxArray.length+"  time series length "+timeSeries.length);
        for (int i = 0; i < rightTimes.length; i++) {
        //	System.out.println("  right Idx  is   "+rightIdxArray[i]);
            rightTimes[i] = timeSeries[rightIdxArray[i]];
            rightReduced[i] = reducedTimeSeries[rightIdxArray[i]];
        }

        for (int i = 0; i < leftTimes.length; i++) {
            double[] ts1 = leftTimes[i];
            for (int j = 0; j < rightTimes.length; j++) {
                double[] ts2 = rightTimes[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
            /*    if (leftTimes[0].length != leftReduced[0].length) {
                    lowerBoundCount++;
                    if (AllPairUtils.lowerBoundLessThan(leftReduced[i], rightReduced[j], segmentLength, range)) {
                        continue;
                    }
                }

                distLessThanCount++;*/
                double dis=DistUtil.euclideanDist(ts1, ts2);
            	//System.out.println("  dis   is   "+dis);
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                	
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }

/*
    public void findAllPairsBetweenIdxArrays(int[] leftIdxArray, int[] rightIdxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        for (int i = 0; i < leftIdxArray.length; i++) {
            int idx1 = leftIdxArray[i];
            double[] ts1 = timeSeries[idx1];
            for (int j = 0; j < rightIdxArray.length; j++) {
                int idx2 = rightIdxArray[j];
                double[] ts2 = timeSeries[idx2];

                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    distLessThanCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(idx1, idx2);
                    }
                }

                //use early abandon
//                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
//                    pairsArray.append(idx1, idx2);

//                double distance = DistUtil.euclideanDist(ts1, ts2);
//                if (distance <= range) {
//                    pairsArray.append(idx1, idx2);
//                }
            }
        }
    }
*/

    public double[][] getNodeTimeSeries() {
        double[][] ret = new double[pairIdxArray.size() + 1][timeSeries[0].length];
        //add those ts in pair
        for (int i = 0; i < ret.length; i++) {
            ret[i] = timeSeries[pairIdxArray.get(i)];
        }
        ret[ret.length - 1] = timeSeries[idx]; //append node idx

        return ret;
    }

    @Override
    public String toString() {
        return "DistTreeNode{" +
                "parent.idx=" + (parent == null ? "null" : parent.idx) +
                ", idx=" + idx +
                ", count=" + count +
                ", distanceTimes=" + distanceTimes +
                ", pairIdxArray=" + pairIdxArray.size() +
                ", children=" + children.size() +
                '}';
    }

    public String toXml() {

//        System.out.println("idx = " + idx);
//        if (parent != null)
//            System.out.println("parent = " + parent.idx);

        pairIdxArray.shrink();
        int[] array = pairIdxArray.getArray();
      
        if(bufferArray==null)
        	bufferArray=new AutoExpandIntArray(threshold);
        bufferArray.shrink();
        int[] buffer = bufferArray.getArray();
        StringBuilder sb = new StringBuilder();
        String tagStart = MessageFormat.format("<node2 idx=\"{0}\" count=\"{1}\" pdTimes=\"{2}\" array=\"{3}\" parent=\"{4}\" buffer=\"{5}\" level=\"{6}\" id=\"{7}\"> bounds=\"{8}\"", idx + "", count + "", distanceTimes, joinArray(array), parent == null ? null : parent.getId() + "", joinArray(buffer), level + "",id+"",lowAndUpper[0]+"-"+lowAndUpper[1]);
//        String tagStart = MessageFormat.format("<node2 idx=\"{0}\" count=\"{1}\" pdTimes=\"{2}\" array=\"{3}\" parent=\"{4}\" buffer=\"{5}\">", "0", "1", "2", "3", "4","5");
        sb.append(tagStart).append("\n");

        for (int i = 0; i < children.size(); i++) {
            DistTreeNode2_2016 distTreeNode = children.get(i);
            sb.append(distTreeNode.toXml());
        }

        sb.append("</node2>").append("\n");
        return sb.toString();
    }

    public String joinArray(int[] array) {
        StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < Math.min(array.length, 4); i++) {
        for (int i = 0; i < array.length; i++) {
            int i1 = array[i];
            sb.append(i1);
            sb.append(",");
        }
        return sb.toString();
    }
}
