package cn.edu.fudan.cs.dstree.allpair;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.edu.fudan.cs.dstree.dynamicsplit.FileBufferManager;
import cn.edu.fudan.cs.dstree.dynamicsplit.INodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevNodeSegmentSketchUpdater;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevRange;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;

public class LQHTestDSTree {
		private static final Log log = LogFactory.getLog(DSTreeAllPairFinderTest.class);
	//	public static String fileName = "d:\\temp\\Series_1000_100000.z.bin";
		public static String fileName = "/home/hadoop/lqh/ucibinary";
	    public static int threshold = 500;
	    public static int segmentSize = 4;
	    public static double range = 1.2;
	    public static int tsLength = 1000;
	    public static int size = 1000;
	    public static List<Node> nodeList=new ArrayList();

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		   range=Double.parseDouble(args[1]);
		   threshold=Integer.parseInt(args[0]);
		   tsLength=Integer.parseInt(args[2]);
		 //  size=Integer.parseInt(args[3]);
		 // fileName="c:\\data\\tao_new_original20";
		    fileName="c:\\data\\tao_new20";
		//  fileName="/home/hadoop/lqh/tao_new2";
		   System.out.println(" dis threshold  is "+range+"  node capacity  is  "+threshold+"  segment   is  "+segmentSize);
		long time1=System.currentTimeMillis();
	 	testBuildTree();
		 long time2=System.currentTimeMillis();
		   long ttt=(time1-time2);
		   System.out.println("   create tree use seconds    .................."+ttt);
		testFindPairs();
		long time3=System.currentTimeMillis();
		long all=(time3-time1);
		System.out.println("   All time  seconds    .................."+all);
	}
    public static void testBuildTree() throws IOException, ClassNotFoundException {
    	
    	  Node.hsTradeOffFactor = 30000000;
    	   // Node.hsTradeOffFactor = 3;
	        SystemInfoUtils systemInfoUtils = new SystemInfoUtilsImpl();
	        double bufferedMemorySize = systemInfoUtils.getTotalMemory() * 0.6;    //0.6 for buffer

	        buildDSTreeFromBinaryDataFile(fileName, null, threshold, segmentSize, bufferedMemorySize, -1, tsLength);
	        System.out.println("Finished!!!");
	    }
    public static  void testFindPairs() throws IOException, ClassNotFoundException {
        
     //	double range =42.667;
    	//double range=2.0;
        double paaReduceRatio = 0.01;
        DSTreeAllPairFinder_lqh_exact dsTreeAllPairFinder = new DSTreeAllPairFinder_lqh_exact();
        String index = fileName+".idx_dyn_"+threshold+"_"+segmentSize+"\\root.idx";
        dsTreeAllPairFinder.setTsLength(tsLength);
        dsTreeAllPairFinder.setSegmentSize(segmentSize);
        dsTreeAllPairFinder.loadIndexAndData(index);
        dsTreeAllPairFinder.setCapacity(threshold);
        dsTreeAllPairFinder.setAllsize(size);
        
        System.out.println("  ******************same  size   ");

       /* StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        //do brute force search using dstree data
        dsTreeAllPairFinder.getTimeSeries();
        AllPairReduceBruteFinder allPairReduceBruteFinder = new AllPairReduceBruteFinder(dsTreeAllPairFinder.getTimeSeries(), range, paaReduceRatio);
        AutoExpandIntArray allPairsArray1 = allPairReduceBruteFinder.findAllPairs();
        log.debug("allPairsCountByBrute = " + allPairsArray1.size() / 2);
        stopWatch.stop();
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
        List<Pair> pairs1 = AllPairUtils.array2PairList(allPairsArray1);
        System.out.println("  the  size of allpairs    is   "+pairs1.size());
        Collections.sort(pairs1);
        AllPairUtils.savePairList2File(pairs1, fileName + ".DSTree.Brute.txt");
        log.debug("Brute Result:" + fileName + ".DSTree.Brute.txt");
*/
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        dsTreeAllPairFinder.setUseUpperBound(false);
        dsTreeAllPairFinder.findAllPairs(allPairs, range,1);
        stopWatch.stop();
        log.debug("stopWatch.getTime() = " + stopWatch.getTime());
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
        long size = allPairs.size() / 2;
        System.out.println("allPairs = " + size);
      //  List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
    //    Collections.sort(pairs);
        System.out.println(" Using ********* dstree the  size of allpairs    is   "+size);
    //    AllPairUtils.savePairList2File(pairs, fileName + ".DSTreePairs.txt");
        
    }

    public static void buildDSTreeFromBinaryDataFile(String fileName, String indexPath, int threshold, int segmentSize, double bufferedMemorySize, int maxTsCount, int tsLength) throws IOException, ClassNotFoundException {
        System.out.println("fileName = " + fileName);
        System.out.println("tsLength = " + tsLength);
        FileBufferManager.fileBufferManager = null;
        FileBufferManager.getInstance().tsLength = tsLength;
        FileBufferManager.getInstance().setBufferedMemorySize(bufferedMemorySize);
        FileBufferManager.getInstance().setThreshold(threshold);

        //init indexPath if null
        if (indexPath == null)
            indexPath = fileName;
        indexPath = indexPath + ".idx_dyn";
        indexPath = indexPath + "_" + threshold + "_" + segmentSize;
        if (maxTsCount > 0) {
            indexPath = indexPath + "_" + maxTsCount;
        }
        System.out.println("indexPath = " + indexPath);
        File file = new File(indexPath);
        if (file.exists()) {
            System.out.println("indexPath: " + indexPath + " exists! cleaning...");
            FileUtils.cleanDirectory(file);
        } else {
            boolean b = file.mkdirs();
        }

        Node root = new Node(indexPath, threshold);

        //init helper class instances
        INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[1];
        nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
//        nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
        root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

        MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
        root.setSeriesSegmentSketcher(seriesSegmentSketcher);
        root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(seriesSegmentSketcher));

        root.setRange(new MeanStdevRange());

        //calc the split points by segmentSize
        short[] points = IndexBuilder.calcPoints(tsLength, segmentSize);
        root.initSegments(points);

        int count = 0;
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        log.debug("timeSeries.length = " + timeSeries.length);
        size=timeSeries.length;
        for (int i = 0; i < timeSeries.length; i++) {
            double[] timeSery = timeSeries[i];
            root.insert(timeSery);
            count++;
            if (count % 10000 == 0)
                log.debug("count = " + count);
            if (maxTsCount > 0) {
                if (count >= maxTsCount)
                    break;
            }
        }
        FileBufferManager.getInstance().saveAllToDisk();
        String indexFileName = indexPath + "\\" + "root.idx";
        root.saveToFile(indexFileName);
        Node newRoot = Node.loadFromFile(indexFileName);
        //
        loadTerminalNodes(newRoot);
        for(int ii=0;ii<nodeList.size();ii++)
        {
        	Node tempNode=nodeList.get(ii);
        	tempNode.getSegmentSize();
       // 	System.out.println("   Node   "+ii+"    segment size  is "+tempNode.getSegmentSize()+"   number  is "+tempNode.getSize());
        }
        System.out.println("newRoot = " + newRoot);
        System.out.println("FileBufferManager.getInstance().ioRead = " + FileBufferManager.getInstance().ioRead);
        System.out.println("FileBufferManager.getInstance().ioWrite = " + FileBufferManager.getInstance().ioWrite);
        System.out.println("FileBufferManager.getInstance().ioDelete = " + FileBufferManager.getInstance().ioDelete);
    }
    public static void loadTerminalNodes(Node node) {
        if (node == null)
            return;

        if (node.isTerminal()) {
            nodeList.add(node);
        } else {
            Node left = node.getLeft();
            loadTerminalNodes(left);

            Node right = node.getRight();
            loadTerminalNodes(right);
        }
    }
}
