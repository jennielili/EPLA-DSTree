package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.strtree.Node;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 2014/7/6.
 */
public class TouchAllPairFinderTest {
    private static final Log log = LogFactory.getLog(TouchAllPairFinderTest.class);

    static String fileName = "d:\\Series_1000_100000.z.bin";
    static int pageSize = 50;
    static int tsLength = 1000;

    public static void main(String[] args) throws IOException, ClassNotFoundException {
		   System.out.println("  hello you fool!");
		   testFindPairs();
	}
    @Test
    public static void testFindPairs() throws IOException, ClassNotFoundException {
        double range = 15;
        double paaReduceRatio = 0.005;
        System.out.println("fileName = " + fileName);
        System.out.println("pageSize = " + pageSize);
        System.out.println("tsLength = " + tsLength);
        System.out.println("range = " + range);
        System.out.println("paaReduceRatio = " + paaReduceRatio);
        long time1=System.currentTimeMillis();
        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
        TouchAllPairFinder finder = new TouchAllPairFinder(timeSeries, paaReduceRatio, pageSize);
       
        finder.buildTree();
       
        finder.loadNodes();
        long time2=System.currentTimeMillis();
        long diff=(time2-time1)/1000;
       
        System.out.println("     time of building the tree  is  "+diff);

//        finder.strTree.getRoot().printTreeInfo();
//        double v = DistUtil.euclideanDist(finder.timeSeries[0], finder.timeSeries[877]);
//        System.out.println("v = " + v);
//
//        double v1 = DistUtil.euclideanDist(finder.reducedTimeSeries[0], finder.reducedTimeSeries[877]);
//        System.out.println("v1 = " + v1);
//
//        boolean b = AllPairUtils.lowerBoundLessThan(finder.reducedTimeSeries[0], finder.reducedTimeSeries[877], 10, range);
//        System.out.println("b = " + b);
//
//        Node node1 = finder.strTree.getRoot().find(finder.reducedTimeSeries[0]);
//        Node node2 = finder.strTree.getRoot().find(finder.reducedTimeSeries[877]);
//
//        double v2 = finder.lowerBound(node1, node2);
//        System.out.println("v2 = " + v2);

        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        finder.findAllPairs(allPairs, range);

        stopWatch.stop();
        long time3=System.currentTimeMillis();
        long diff2=(time3-time1)/1000;
        System.out.println("     time of all  is  "+diff2);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
        log.debug("stopWatch.getTime() = " + stopWatch.getTime());
        int size = allPairs.size() / 2;
        log.debug("allPairs = " + size);
        log.debug("allPairs ratio = " + size * 1.0 / (timeSeries.length * (timeSeries.length - 1)));
        log.debug("AllPairReduceBruteFinder.lowerBoundCount = " + AllPairReduceBruteFinder.lowerBoundCount);
        log.debug("AllPairReduceBruteFinder.distLessThanCount = " + AllPairReduceBruteFinder.distLessThanCount);
        System.out.println("   size    is  "+size); 
        System.out.println("  AllPairReduceBruteFinder.lowerBoundCount = " + AllPairReduceBruteFinder.lowerBoundCount); 
        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        Collections.sort(pairs);
        AllPairUtils.savePairList2File(pairs, fileName + ".TouchPairs.txt");
    }
}
