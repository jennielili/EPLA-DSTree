package cn.edu.fudan.cs.dstree.allpair;
import java.util.*;
public class WeightPoint {
	private  int hash;
	public int getHash() {
		return hash;
	}
	public void setHash(int hash) {
		this.hash = hash;
	}
	private int weight;
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public Point getPoint() {
		return point;
	}
	public void setPoint(Point point) {
		this.point = point;
	}
	private Point point;
	public WeightPoint(int wei,Point po)
	{
		this.weight=wei;
		this.point=po;
	}
	public String toString() {
		String str = this.point.toString();
		str+="\t"+this.weight;
		return str;
	}
	public boolean eqa(WeightPoint wp)
	{
		boolean ok=true;
		Point p1=this.getPoint();
		Point p2=wp.getPoint();
		String s1=p1.point.toString();
		String s2=p2.point.toString();
		if(!s1.equals(s2))
		     return false;
		return ok;
	}

}
