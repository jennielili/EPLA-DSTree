package cn.edu.fudan.cs.dstree.allpair;
import cn.edu.fudan.cs.dstree.data.RandomWalkGenerator;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import cn.edu.fudan.cs.dstree.partition.Edge;
import cn.edu.fudan.cs.dstree.partition.FMPartitioner;
import cn.edu.fudan.cs.dstree.partition.Graph;
import cn.edu.fudan.cs.dstree.partition.PreorderPartitioner;
import cn.edu.fudan.cs.dstree.partition.RandomPartitioner;
import cn.edu.fudan.cs.dstree.partition.Partitioner;
import cn.edu.fudan.cs.dstree.partition.Vertex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
public class DistanceTreeTest {

	/**
	 * @param args
	 */
//	private static final Log log = LogFactory.getLog(AllPairFinderTest.class);

  //  static int tsSize = 10000000;
	static int tsSize = 1000;
    static int tsLength = 256;
    static int threshold = 50;
    static double range=2;
    static int partitionCount=5;
    List<DistTreeNode2> nodeList = new ArrayList<DistTreeNode2>();
    public static DistTreeNode2 root=null;
    public static Map<Long,DistTreeNode2> nodeMap = new HashMap<Long,DistTreeNode2>();
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	   double paaReduceRatio = 0.01;
	   StopWatch buildTree = new StopWatch();
	   buildTree.start();
	   String fileName = "c:\\data\\billionSeries_256_1000.z.bin";
	   
	 // String fileName = "/home/hadoop/lqh/billionSeries_256_10000000.z.bin";
	   double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryPart(fileName, tsLength,tsSize);
	   
	   AllPairFinder2 allPairFinder = new AllPairFinder2(timeSeries, range, paaReduceRatio, threshold);
       root = allPairFinder.buildTree();
       FileUtils.writeStringToFile(new File(fileName + ".distTree3.xml"), root.toXml());
       List<long[]>  pairs=findNodePairsNew(range);
       System.out.println("  AAAAAAAAAAAAAA     edge   is   "+pairs.size());
       List<DistTreeNode2> leaves=getLeafNodes();
       Partitioner partitioner = new FMPartitioner();
       partitioner.setPartitionCount(partitionCount);
		// partitionCount=32;
		int maxCacheSize = (int) (tsSize * 1.0 / partitionCount * 1.2); // 1.01 is
       Graph graph = makeGraph(leaves, pairs);
		List<Edge> edgeList = graph.getEdgeList();
		partitioner.setGraph(graph);
		partitioner.setCapacityThreshold(maxCacheSize);
		partitioner.partition();
		int partitionCount = partitioner.getPartitionCount();
		System.out.println("partitionCount = " + partitionCount);
		System.out.println("  edge  list   "+edgeList.size());
	//	System.out.println("   make graph    time ***************  "+sw.getTime());

       AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
  /*   for(int ii=0;ii<leaves.size();ii++)
       {
    	   for(int jj=ii+1;jj<leaves.size();jj++)
    	   {
    		   DistTreeNode2  node1=nodeMap.get(leaves.get(ii).getId());
        	   DistTreeNode2  node2=nodeMap.get(leaves.get(jj).getId());
        	   System.out.println("  AAAAAAAAAAAA      node1  id  "+node1.getId()+"  node2   "+node2.getId()+"    size   "+allPairs.size());
        	//   if(node1.getId()==3 && node2.getId()==38)
        	   {
	        	   int[] array = null;
	               array = node1.bufferArray.getArray();
	               int[] array2 = null;
	               array2 = node2.bufferArray.getArray();
	        	   node1.findAllPairsBetweenIdxArrays(array, array2, allPairs);
	        	   
        	   }
    	   }
       }*/
     for(int ii=0;ii<pairs.size();ii++)
       {
    	   DistTreeNode2  node1=nodeMap.get(pairs.get(ii)[0]);
    	   DistTreeNode2  node2=nodeMap.get(pairs.get(ii)[1]);
    	   int[] array = null;
           array = node1.bufferArray.getArray();
           int[] array2 = null;
           array2 = node2.bufferArray.getArray();
    	   node1.findAllPairsBetweenIdxArrays(array, array2, allPairs);

       }
       
       buildTree.stop();
      System.out.println("build tree time   "+buildTree.getTime()   );
       int count=0;
       for(int ii=0;ii<leaves.size();ii++)
       {
    	   DistTreeNode2 node=leaves.get(ii);
    	   double[][] timeseries=node.getTimeSeries();
    	   double[][] reducedtime=node.getReducedTimeSeries();
    	//   node.bufferArray.shrink();
    	   int[] array = null;
           array = node.bufferArray.getArray();
           count+=array.length;
//           log.debug("findAllPairsForIdxArray begin " + array.length);
      //     System.out.println("        leaf      "+node.joinArray(array));
           node.findAllPairsForIdxArray(array, allPairs);
        //   System.out.println(" allPairs   size    "+allPairs.size()+"   node id  "+node.getId());
    	   
       }
       System.out.println("  the size   is    *************  "+allPairs.size()/2+"  count   "+count);
       double rate=(double)pairs.size()/(leaves.size()*(leaves.size()+1)/2);
       System.out.println("The  rate    is     "+rate+"  leave number  "+leaves.size());
     //  for(int ii=0;ii<allPairs.size();ii+=2)
     //  	     System.out.println("   "+allPairs.get(ii)+"   "+allPairs.get(ii+1));

	}
	public static Graph makeGraph(List<DistTreeNode2> nodes, List<long[]> nodePairs) {
		List<Vertex> vertexList = new ArrayList<Vertex>();
		Map<Integer, Vertex> vertexMap = new HashMap<Integer, Vertex>();
		for (int i = 0; i < nodes.size(); i++) {
			DistTreeNode2 node = nodes.get(i);
			Vertex vertex = new Vertex(i, "" + i, node.bufferArray.size(), node);
			vertexList.add(vertex);
			vertexMap.put(vertex.getId(), vertex);
		}

		List<Edge> edgeList = new ArrayList<Edge>();
		for (int i = 0; i < nodePairs.size(); i++) {
			long[] ids = nodePairs.get(i);
			Vertex vertex1 = vertexMap.get(ids[0]);
			Vertex vertex2 = vertexMap.get(ids[1]);
			Edge edge = new Edge(vertex1, vertex2);
			edgeList.add(edge);
		}
		Graph graph = new Graph(vertexList, edgeList);
		
		boolean checkValid = graph.checkValid();
		System.out.println("graph checkValid = " + checkValid);
		return graph;
	}
	 public static void findAllPairsWithPaaAbandon(int[] idxArray, double[][] timeSeries, double[][] reducedTimeSeries, int segmentLength, double range, AutoExpandIntArray allPairs) {
	        for (int i = 0; i < timeSeries.length; i++) {
	            final double[] ts1 = timeSeries[i];
	            for (int j = i + 1; j < timeSeries.length; j++) {
//	                double[] ts2 = timeSeries[j];
	                //use early abandon and reduced dimension
	                if (reducedTimeSeries[0].length != timeSeries[0].length) {
	                   
	                    if (!AllPairUtils.lowerBoundLessThan(reducedTimeSeries[i], reducedTimeSeries[j], segmentLength, range)) {
	                       
	                        continue;
	                    }
	                }

	              
	                final double[] ts2 = timeSeries[j];
	                //   System.out.println("   range  is  "+range+"   dist  is "+DistUtil.euclideanDist(ts1, ts2));
	                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
	                    allPairs.append(idxArray[i], idxArray[j]);
	            }
	        }
	    }
	public static List<DistTreeNode2>  getLeafNodes()
	{
		 List<DistTreeNode2> ret=new ArrayList();
		 Stack<DistTreeNode2> traverseStack = new Stack<DistTreeNode2>();
		 traverseStack.push(root);
		 while (!traverseStack.isEmpty()) {
			DistTreeNode2 firstVisitNode = traverseStack.pop();
		//	System.out.println("   id   is   "+firstVisitNode.getId());
			if (firstVisitNode.isLeaf())
			{
				ret.add(firstVisitNode);
				nodeMap.put(firstVisitNode.getId(), firstVisitNode);
			}
			else
			{
				List<DistTreeNode2> children=firstVisitNode.children;
	            for(int ii=0;ii<children.size();ii++)
	            	traverseStack.push(children.get(ii));
			}
			
			
		}
		
	//	System.out.println("  the  number   of    leaf   nodes    is    "+ret.size());
		return ret;
	}
	public static  List<long[]> findNodePairsNew(double range)
	throws IOException
  {
		
	List<long[]> ret = new ArrayList<long[]>();
	
	int pruneC = 0;
	int allCompares = 0;
	int pruneC_lower = 0;
	int pruneC_upper = 0;
	// deep search
	Stack<DistTreeNode2> firstTraverseStack = new Stack<DistTreeNode2>();
	Stack<DistTreeNode2> secondTraverseStack = new Stack<DistTreeNode2>();
	firstTraverseStack.push(root);
	//String name = "/home/hadoop/lqh/out_pairs_" + capacity + ".txt";
//	FileWriter fw = new FileWriter(name);// ����FileWriter��������д���ַ���
//	BufferedWriter bw = new BufferedWriter(fw);
//	FileWriter fw = new FileWriter("c:\\data\\dstree_between_"+capacity+"_"+segmentSize+".txt");// ����FileWriter��������д���ַ���
//	BufferedWriter bw = new BufferedWriter(fw);
	int lbprune = 0;
	double lbprunerate = 0.0;
	int ubprune = 0;
	double ubprunerate = 0.0;
	while (!firstTraverseStack.isEmpty()) {
		DistTreeNode2 firstVisitNode = firstTraverseStack.pop();
		//System.out.println("   id   is   "+firstVisitNode.getId());
		if (firstVisitNode.isLeaf())
		{
			long i = firstVisitNode.getId();
          //  System.out.println("    i     is    "+i);
			// find pair node after the current node
			secondTraverseStack.clear();

			secondTraverseStack.addAll(firstTraverseStack);

			while (!secondTraverseStack.isEmpty()) {
				DistTreeNode2 secondVisitNode = secondTraverseStack.pop();
				long j=secondVisitNode.getId();
			//	System.out.println("   j      is    "+j);
				if (secondVisitNode.isLeaf()) {
					// calc lowerBound
					
					boolean canPruned=firstVisitNode.canPruned(firstVisitNode.getAllRefBounds(), secondVisitNode.getAllRefBounds());
					if (!canPruned)
						ret.add(new long[] { i, j });
				
					
				} 
		         else 
		         {
		             List<DistTreeNode2> children=secondVisitNode.children;
		             for(int ii=0;ii<children.size();ii++)
		            	 secondTraverseStack.push(children.get(ii));
			    
		          }
	        }//while 

		}//if 
		else
		{
			List<DistTreeNode2> children=firstVisitNode.children;
            for(int ii=0;ii<children.size();ii++)
           	 firstTraverseStack.push(children.get(ii));
		}
	}
	return ret;

}
	public static  void testAllPairFinder2() throws IOException { //using DistTreeNode3
        //the newest test for productDistance tree2
      // String fileName = "c:\\data\\ucibinary"; //0.1 million
		//String fileName = "/home/hadoop/lqh/billionSeries_256_10000000.z.bin";
		String fileName = "c:\\data\\billionSeries_256_1000.z.bin";
      //  tsLength = 1000;
       // threshold = 150;
      //  log.debug("tsLength = " + tsLength);
       // log.debug("threshold = " + threshold);

        double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryPart(fileName, tsLength,tsSize);
    //    log.debug("timeSeries.length = " + timeSeries.length);
       // double range = 5;
      //  log.debug("range = " + range);
        System.out.println(" range   is   "+range); 
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        double paaReduceRatio = 0.01;
        StopWatch buildTree = new StopWatch();
    
        
    //    log.debug(" Construct tree cost : " + buildTree.getTime());
        System.out.println(" Construct tree cost : " + buildTree.getTime());
    //    log.debug("root = " + root);
         FileUtils.writeStringToFile(new File(fileName + ".distTree3.xml"), root.toXml());
        AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);

       root.findAllParis(allPairs);
       List<long[]> nodePairs=findNodePairsNew(range);
       System.out.println("   the nodePairs size   is   "+nodePairs.size());

        stopWatch.stop();
    //    log.debug("stopWatch = " + stopWatch.getTime());
        System.out.println("  time    is    "+stopWatch.getTime());
        int size = allPairs.size() / 2;
     //   log.debug("allPairs. = " + size);
     //   log.debug("root.countForDown = " + root.countForDown);
    //    log.debug("root.countForDownWorked = " + root.countForDownWorked);
      //  log.debug("root.lowerBoundCount = " + root.lowerBoundCount);
        //log.debug("root.distLessThanCount = " + root.distLessThanCount);
        //log.debug("root.distCount = " + root.distCount);
        //log.debug("root.prunedByParentBounds = " + root.prunedByParentBounds);
        long total = 1l * timeSeries.length * timeSeries.length / 2;
        //log.debug("total = " + total);
        //log.debug("percent = " + size * 1.0 / total);
        System.out.println( "percent = " + size * 1.0 / total);
        boolean verify = AllPairUtils.verify(timeSeries, allPairs, range);
       // log.debug("verify = " + verify);
        boolean noDuplicate = AllPairUtils.checkNoDuplicate(allPairs);
       // log.debug("noDuplicate = " + noDuplicate);
        System.out.println("   noDuplicate   is   "+noDuplicate); 
        List<Pair> pairs = AllPairUtils.array2PairList(allPairs);
        System.out.println("  size   is    "+size);
        for(int ii=0;ii<allPairs.size()/2;ii+=2)
        	System.out.println("   "+allPairs.get(ii)+"   "+allPairs.get(ii+1));
       // Collections.sort(pairs);
      //  AllPairUtils.savePairList2File(pairs, fileName + ".distTree2.txt");
    }

}
