package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import cn.edu.fudan.cs.dstree.partition.Edge;
/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairReduceBruteFinder {
    private static final Log log = LogFactory.getLog(AllPairReduceBruteFinder.class);
    double[][] timeSeries;
    double[][] reducedTimeSeries;
    double range;
    int reducedDimensionCount;
    int[] segments;
    int segmentLength;

    public AllPairReduceBruteFinder(double[][] timeSeries, double range, double reduceRatio) {
        this.timeSeries = timeSeries;
        this.range = range;
        int originalLength = timeSeries[0].length;
        reducedDimensionCount = (int) (originalLength * reduceRatio);

        if (originalLength % reducedDimensionCount != 0)
            throw new RuntimeException("reduceDimensionCount can not be divided!");
        segmentLength = originalLength / reducedDimensionCount;

        reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];

        segments = AllPairUtils.calcPoints(originalLength, reducedDimensionCount);
        for (int i = 0; i < timeSeries.length; i++) {
            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i], segments);
        }
    }

    public static long lowerBoundCount = 0;
    public static long distLessThanCount = 0;
    public static long lowerBoundPruneCount = 0;

    public AutoExpandIntArray findAllPairs() {
        AutoExpandIntArray ret = new AutoExpandIntArray(1000);

        AutoExpandIntArray idxArray = new AutoExpandIntArray(100);
        for (int i = 0; i < timeSeries.length; i++) {
            idxArray.append(i);
        }
        idxArray.shrink();
        int[] array = idxArray.getArray();
//        stopWatch.start();
//        stopWatch.suspend();
//        findAllPairsForIdxArray(array,ret);
        findAllPairsForIdxArray1(array, ret);
//        for (int i = 0; i < timeSeries.length; i++) {
//            final double[] ts1 = timeSeries[i];
//            for (int j = i + 1; j < timeSeries.length; j++) {
////                double[] ts2 = timeSeries[j];
//                //use early abandon and reduced dimension
//                lowerBoundCount++;
//                stopWatch.resume();
//                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[i], reducedTimeSeries[j], segmentLength, range)) {
//                    distLessThanCount++;
//                    final double[] ts2 = timeSeries[j];
//                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
//                        ret.append(i, j);
//                }
//                stopWatch.suspend();
//            }
//        }
//        findAllPairsWithPaaAbandon(timeSeries, reducedTimeSeries, segmentLength, range, ret);
        return ret;
    }

    public static void findAllPairsWithPaaAbandon(double[][] timeSeries, double[][] reducedTimeSeries, int segmentLength, double range, AutoExpandIntArray allPairs) {
        for (int i = 0; i < timeSeries.length; i++) {
            final double[] ts1 = timeSeries[i];
            for (int j = i + 1; j < timeSeries.length; j++) {
//                double[] ts2 = timeSeries[j];
                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[i], reducedTimeSeries[j], segmentLength, range)) {
                    distLessThanCount++;
                    final double[] ts2 = timeSeries[j];
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
                    {
                   	double dd=DistUtil.euclideanDist(ts1, ts2);
                  // 	System.out.println("   i   "+i+"   j  "+j+"   dis   is  "+dd);
                        allPairs.append(i, j);
                    }
                }
            }
        }
    }
   
    public void findAllPairsForIdxArray(int[] idxArray, AutoExpandIntArray pairsArray) {
        log.debug("AllPairReduceBruteFinder.findAllPairsForIdxArray");
        //do brute force search
        for (int i = 0; i < idxArray.length; i++) {
            final int idx1 = idxArray[i];
            final double[] ts1 = timeSeries[idx1];
            for (int j = i + 1; j < idxArray.length; j++) {
                final int idx2 = idxArray[j];
//                double[] ts2 = timeSeries[idx2];
                final double[] ts2 = timeSeries[j];
                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    distLessThanCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(idx1, idx2);
                    }
                }
            }
        }
    }

    public void findAllPairsForIdxArray1(int[] idxArray, AutoExpandIntArray pairsArray) {
        log.debug("AllPairReduceBruteFinder.findAllPairsForIdxArray1");
        double[][] newTimes = new double[idxArray.length][];
        double[][] newReduced = new double[idxArray.length][];
        for (int i = 0; i < newTimes.length; i++) {
            newTimes[i] = timeSeries[idxArray[i]];
            newReduced[i] = reducedTimeSeries[idxArray[i]];
        }
        log.debug("gen array");
        findAllPairsWithPaaAbandon(idxArray, newTimes, newReduced, segmentLength, range, pairsArray);
    }

    public static void findAllPairsWithPaaAbandon(int[] idxArray, double[][] timeSeries, double[][] reducedTimeSeries, int segmentLength, double range, AutoExpandIntArray allPairs) {
        for (int i = 0; i < timeSeries.length; i++) {
            final double[] ts1 = timeSeries[i];
            for (int j = i + 1; j < timeSeries.length; j++) {
//                double[] ts2 = timeSeries[j];
                //use early abandon and reduced dimension
                if (reducedTimeSeries[0].length != timeSeries[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(reducedTimeSeries[i], reducedTimeSeries[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
                final double[] ts2 = timeSeries[j];
                //   System.out.println("   range  is  "+range+"   dist  is "+DistUtil.euclideanDist(ts1, ts2));
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
                    allPairs.append(idxArray[i], idxArray[j]);
            }
        }
    }

    public static void findAllPairsWithPaaAbandon(double[][] leftTss, double[][] rightTss, double[][] leftReducedTss, double[][] rightReducedTss, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        for (int i = 0; i < leftTss.length; i++) {
            double[] ts1 = leftTss[i];
            for (int j = 0; j < rightTss.length; j++) {
                double[] ts2 = rightTss[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
                if (leftTss[0].length != leftReducedTss[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(leftReducedTss[i], rightReducedTss[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
//                if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("  i   "+leftIdxArray[i]+"    j   "+rightIdxArray[j]+"  dis    is  ");
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }
    
    public static void findAllPairsWithPaaAbandonLessThan(double[][] leftTss, double[][] rightTss, double[][] leftReducedTss, double[][] rightReducedTss, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        for (int i = 0; i < leftTss.length; i++) {
            double[] ts1 = leftTss[i];
            for (int j = 0; j < rightTss.length; j++) {
                double[] ts2 = rightTss[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
             
//                if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("  i   "+leftIdxArray[i]+"    j   "+rightIdxArray[j]+"  dis    is  ");
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }
    public static void findAllPairs_triangle(Edge edge, double[][] leftTss, double[][] rightTss, double[][] leftReducedTss, double[][] rightReducedTss, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        for (int i = 0; i < leftTss.length; i++) {
            double[] ts1 = leftTss[i];
            for (int j = 0; j < rightTss.length; j++) {
                double[] ts2 = rightTss[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
                if (leftTss[0].length != leftReducedTss[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(leftReducedTss[i], rightReducedTss[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
//                if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("  i   "+leftIdxArray[i]+"    j   "+rightIdxArray[j]+"  dis    is  ");
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }
    public static void findAllPairsWithPaaAbandon(double[][] timeSeries, double[][] reducedTimeSeries, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        double[][] leftTimes = new double[leftIdxArray.length][];
        double[][] leftReduced = new double[leftIdxArray.length][];
        for (int i = 0; i < leftTimes.length; i++) {
            leftTimes[i] = timeSeries[leftIdxArray[i]];
            leftReduced[i] = reducedTimeSeries[leftIdxArray[i]];
        }

        double[][] rightTimes = new double[rightIdxArray.length][];
        double[][] rightReduced = new double[rightIdxArray.length][];
        for (int i = 0; i < rightTimes.length; i++) {
            rightTimes[i] = timeSeries[rightIdxArray[i]];
            rightReduced[i] = reducedTimeSeries[rightIdxArray[i]];
        }

        for (int i = 0; i < leftTimes.length; i++) {
            double[] ts1 = leftTimes[i];
            for (int j = 0; j < rightTimes.length; j++) {
                double[] ts2 = rightTimes[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
                if (leftTimes[0].length != leftReduced[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(leftReduced[i], rightReduced[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
//              if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("   i    is  "+leftIdxArray[i]+"   j   is  "+rightIdxArray[j]+"   dis  is "+dd);
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }

    public static void findAllPairsWithPaaAbandon_clusterJoin(double[][] leftTimes,double[][] rightTimes, double[][] leftReduced,double[][] rightReduced, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        

        for (int i = 0; i < leftTimes.length; i++) {
            double[] ts1 = leftTimes[i];
            for (int j = 0; j < rightTimes.length; j++) {
                double[] ts2 = rightTimes[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
                if (leftTimes[0].length != leftReduced[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(leftReduced[i], rightReduced[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
//              if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("   i    is  "+leftIdxArray[i]+"   j   is  "+rightIdxArray[j]+"   dis  is "+dd);
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }
    public static void findAllPairsLessthan(double[][] timeSeries, double[][] reducedTimeSeries, int[] leftIdxArray, int[] rightIdxArray, double range, int segmentLength, AutoExpandIntArray pairsArray) {
        double[][] leftTimes = new double[leftIdxArray.length][];
        double[][] leftReduced = new double[leftIdxArray.length][];
        for (int i = 0; i < leftTimes.length; i++) {
            leftTimes[i] = timeSeries[leftIdxArray[i]];
            leftReduced[i] = reducedTimeSeries[leftIdxArray[i]];
        }

        double[][] rightTimes = new double[rightIdxArray.length][];
        double[][] rightReduced = new double[rightIdxArray.length][];
        for (int i = 0; i < rightTimes.length; i++) {
            rightTimes[i] = timeSeries[rightIdxArray[i]];
            rightReduced[i] = reducedTimeSeries[rightIdxArray[i]];
        }

        for (int i = 0; i < leftTimes.length; i++) {
            double[] ts1 = leftTimes[i];
            for (int j = 0; j < rightTimes.length; j++) {
                double[] ts2 = rightTimes[j];
                //use early abandon and reduced dimension
                //optimal paa reduced if the ratio = 1, the reduced length == original length
                if (leftTimes[0].length != leftReduced[0].length) {
                    lowerBoundCount++;
                    if (!AllPairUtils.lowerBoundLessThan(leftReduced[i], rightReduced[j], segmentLength, range)) {
                        lowerBoundPruneCount++;
                        continue;
                    }
                }

                distLessThanCount++;
//              if (DistUtil.euclideanDist(ts1, ts2) <= range) {
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                    //System.out.println("    the  dis   is  "+111);
                //	double dd=DistUtil.euclideanDist(ts1, ts2);
                //	System.out.println("   i    is  "+leftIdxArray[i]+"   j   is  "+rightIdxArray[j]+"   dis  is "+dd);
                    pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                }
            }
        }
    }
    public static double lowerBound(double[] ts1, double[] ts2, int segmentLength) {
        return DistUtil.euclideanDist(ts1, ts2) * segmentLength;
    }

}
