package cn.edu.fudan.cs.dstree.allpair;

import java.util.Date;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairFinder {
    double[][] timeSeries;
    double range;
    double[][] reducedTimeSeries;
    int reducedDimensionCount;
    int[] segments;
    int segmentLength;

    public AllPairFinder(double[][] timeSeries, double range, double reduceRatio) {
        this.timeSeries = timeSeries;
        this.range = range;

        int originalLength = timeSeries[0].length;
        reducedDimensionCount = (int) (originalLength * reduceRatio);

        if (originalLength % reducedDimensionCount != 0)
            throw new RuntimeException("reduceDimensionCount can not be divided!");
        segmentLength = originalLength / reducedDimensionCount;

        reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];

        segments = AllPairUtils.calcPoints(originalLength, reducedDimensionCount);
        for (int i = 0; i < timeSeries.length; i++) {
            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i], segments);
        }
    }

    public DistTreeNode buildTree() {
        DistTreeNode ret = new DistTreeNode(null, 0, 0, timeSeries, range, reducedTimeSeries, segmentLength);
        for (int i = 1; i < timeSeries.length; i++) {
            ret.appendTimeSeries(i);
//            if (i % 1000 == 0)
//                System.out.println(new Date() + " i = " + i);
        }

        return ret;
    }
}
