package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by wangyang on 2014/5/20.
 */
public class DistTreeNode3 implements Comparable<DistTreeNode3> {
    private static final Log log = LogFactory.getLog(DistTreeNode3.class);
    private static final int copyLevel = 3;
    private final int threshold; //150
    DistTreeNode3 parent;
    AutoExpandIntArray bufferArray; // at most threshold
    int level = 1;
    int idx = -1;  //ref idx
    int distanceTimes; //parent distance bounds
    double range;
    public static long staticId=0;
    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long id=staticId++;
    AutoExpandIntArray pairIdxArray = new AutoExpandIntArray(100);
    List<DistTreeNode3> children = new ArrayList<DistTreeNode3>(10);
    int count = 0;

    public int getParentRefMinTimes()
    {
        return distanceTimes;
    }

    public int getParentRefMaxTimes()
    {
        return distanceTimes + 1;
    }

    public int getParentRefIdx()
    {
        return parent.idx;
    }

    int[][] allRefBounds;

    public int[][] getAllRefBounds()
    {
        if (allRefBounds == null)
        {
            allRefBounds = new int[level-1][2];
            DistTreeNode3 p = parent;
            int times = distanceTimes;
            for (int i = 0; i < allRefBounds.length; i++) {
                int[] allRefBound = allRefBounds[i];
                allRefBound[0] = p.idx;  //ref idx
                allRefBound[1] = times; //ref idx bound
                times = p.distanceTimes;
                p = p.parent;
            }
        }
        return allRefBounds;
    }

    public boolean canPruned(int[][] allRefBounds1, int[][] allRefBounds2)
    {
        for (int i = 0; i < allRefBounds1.length; i++) {
            int[] bound1 = allRefBounds1[i];
            int idx1 = bound1[0];
            int time1 = bound1[1];
//            for (int j = 0; j < allRefBounds2.length; j++) {
            for (int j = 0; j < 1; j++) {
                int[] bound2 = allRefBounds2[j];
                int idx2 = bound2[0];
                int time2 = bound2[1];
                double distance = cacheDistance(idx1,idx2);
                double times = distance / range;
                if ((times > (time1 + time2 + 3)) || (times <= (Math.abs(time1 - time2) - 2))) {
//            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)))
//                    System.out.print("i = " + i);
//                    System.out.println("j = " + j);
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isLeaf() {
        return children.size() == 0;
    }

    double[][] timeSeries;
    public double[][] getTimeSeries() {
		return timeSeries;
	}

	public void setTimeSeries(double[][] timeSeries) {
		this.timeSeries = timeSeries;
	}

	public double[][] getReducedTimeSeries() {
		return reducedTimeSeries;
	}

	public void setReducedTimeSeries(double[][] reducedTimeSeries) {
		this.reducedTimeSeries = reducedTimeSeries;
	}

	double[][] reducedTimeSeries;
    int segmentLength;

    public DistTreeNode3(DistTreeNode3 parent, int distanceTimes, double[][] timeSeries, double range, double[][] reducedTimeSeries, int segmentLength, int threshold) {
        this.parent = parent;
//        this.idx = idx;
        this.distanceTimes = distanceTimes;
        this.timeSeries = timeSeries;
        this.range = range;
        this.reducedTimeSeries = reducedTimeSeries;
        this.segmentLength = segmentLength;
        this.threshold = threshold;
        this.bufferArray = new AutoExpandIntArray(threshold);
        if (parent != null)
            level = parent.level + 1;
    }

    public void addPairIdx(int pairIdx) {
        pairIdxArray.append(pairIdx);
    }

    public void appendTimeSeries(int appendIdx) {
//        log.debug("appendIdx = " + appendIdx);
        count++;

        if ((bufferArray.size() < threshold) && (idx < 0))  //not overflow
        {
            bufferArray.append(appendIdx);

            if (bufferArray.size() >= threshold) //just overflow
            {
                int[] buffer = bufferArray.getArray();
                int refIdx = buffer[0];
                idx = refIdx;  //set idx
                for (int i = 1; i < buffer.length; i++) {
                    int idx2 = buffer[i];
                    double distance = distance(refIdx, idx2);

                    if (distance <= range) {
                        addPairIdx(idx2);
                        //add to 2 * range
                        DistTreeNode3 childNode = getChildNode(1);

                            if (childNode == null) {
                                childNode = new DistTreeNode3(this, 1, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
                                if (childNode.level <= this.copyLevel){
                                    childNode.appendTimeSeries(idx2);
                                    children.add(childNode);
                                    Collections.sort(children);
                                }

                            } else {
                                if (childNode.level <= this.copyLevel){
                                    childNode.appendTimeSeries(idx2);
                                }

                            }



                    } else {
                        int times = (int) (distance / range);
                        if (times * range >= distance) // =3 ==> 2
                            times--;
                        DistTreeNode3 childNode = getChildNode(times);
                        if (childNode == null) {
                            childNode = new DistTreeNode3(this, times, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
                            childNode.appendTimeSeries(idx2);
                            children.add(childNode);
                            Collections.sort(children);
                        } else {
                            childNode.appendTimeSeries(idx2);
                        }

                        //add to times + 1
                        childNode = getChildNode(times + 1);
                        if (childNode == null) {
                            childNode = new DistTreeNode3(this, times + 1, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
                            childNode.appendTimeSeries(idx2);
                            children.add(childNode);
                            Collections.sort(children);
                        } else {
                            childNode.appendTimeSeries(idx2);
                        }
                    }
                }
                bufferArray.clear();
            }
            return;
        }

        //is overflowed
//        double[] thisTs = timeSeries[idx];
//        double[] appendTs = timeSeries[appendIdx];
        double distance = distance(idx, appendIdx);
//        distCount ++;
//        int times = (int) Math.ceil(distance / range);
        if (distance <= range) {
            addPairIdx(appendIdx);
        } else {
            int times = (int) (distance / range);
            if (times * range >= distance)
                times--;
            DistTreeNode3 childNode = getChildNode(times);
            if (childNode == null) {
                childNode = new DistTreeNode3(this, times, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
                childNode.appendTimeSeries(appendIdx);
                children.add(childNode);
                Collections.sort(children);
            } else {
                childNode.appendTimeSeries(appendIdx);
            }

            //add to times + 1
            childNode = getChildNode(times + 1);
            if (childNode == null) {

                childNode = new DistTreeNode3(this, times + 1, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
                if ( childNode.level  <= this.copyLevel){
                    childNode.appendTimeSeries(appendIdx);
                    children.add(childNode);
                    Collections.sort(children);
                }

            } else {
                if ( childNode.level <= this.copyLevel){
                    childNode.appendTimeSeries(appendIdx);
                }

            }
        }
    }

    public DistTreeNode3 getChildNode(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) { //todo: performance
            DistTreeNode3 distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return distTreeNode;
        }
        return null;
    }

    public int getChildNodeIdx(int distanceTimes) {
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode3 distTreeNode = children.get(i);
            if (distanceTimes == distTreeNode.distanceTimes)
                return i;
        }
        return -1;
    }


    @Override
    public int compareTo(DistTreeNode3 o) {
        return this.distanceTimes - o.distanceTimes;
    }

    public void findAllParis(AutoExpandIntArray allPairs) {
        //deal with self
//        log.debug("pairIdxArray = " + pairIdxArray.size());
//        log.debug("children = " + children.size());
//        log.debug("this = " + this); todo:
        int[] array = null;
        if (idx < 0) //==-1 without children
        {
            bufferArray.shrink();
            array = bufferArray.getArray();
//            log.debug("findAllPairsForIdxArray begin " + array.length);
            findAllPairsForIdxArray(array, allPairs);
//            log.debug("findAllPairsForIdxArray end");
        } else  //>=0  have children
        {
            pairIdxArray.shrink();
            //deal with idx and distanceTimes 0
            array = pairIdxArray.getArray();
            for (int i = 0; i < array.length; i++) {
                allPairs.append(idx, array[i]);
            }
            //deal with distanceTimes 0
//            log.debug("findAllPairsForIdxArray begin " + array.length);
            findAllPairsForIdxArray(array, allPairs);
//            log.debug("findAllPairsForIdxArray end");

            //deal with distanceTimes 0 and times 1, move down  //for this level
            DistTreeNode3 childNode = getChildNode(1);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown begin " + this.toString() + " " + childNode.toString());
            findAllPairsBetweenIdxArrayAndNodeDown(this, idx, array, childNode, allPairs);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown end ");
        }

        //compare with other node //move up
        List<DistTreeNode3> parentNodes = getParentSearchNodes();
        for (int i = 0; i < parentNodes.size(); i++) {
            DistTreeNode3 distTreeNode = parentNodes.get(i);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown begin " + this.toString() + " " + distTreeNode.toString());
            findAllPairsBetweenIdxArrayAndNodeDown(this, idx, array, distTreeNode, allPairs);
//            log.debug("findAllPairsBetweenIdxArrayAndNodeDown end " + this.toString() + " " + distTreeNode.toString());
        }


        //deal with children
        for (int i = 0; i < children.size(); i++) {
            DistTreeNode3 distTreeNode = children.get(i);
            distTreeNode.findAllParis(allPairs);
        }

//        log.debug("countForDown = " + countForDown);
    }

    private boolean canPruned(DistTreeNode3 node1, DistTreeNode3 node2)
    {
        boolean ret = false;
        if (node1.idx >= 0 && node2.idx >=0)
        {
            double distance = cacheDistance(node1.idx, node2.idx);
            double times = distance / range;
            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)) || (times <= (Math.abs(node1.distanceTimes - node2.distanceTimes) - 2)))
//            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)))
                ret = true;
        }
        return ret;
    }

    private List<DistTreeNode3> getParentSearchNodes() {
        List<DistTreeNode3> ret = new ArrayList<DistTreeNode3>();

        DistTreeNode3 p = parent;
        int distTimes = distanceTimes;

        while (p != null) {
            DistTreeNode3 childNode = p.getChildNode(distTimes + 1);
            if (childNode != null)
                ret.add(childNode);
            distTimes = p.distanceTimes;
            p = p.parent;
        }

        return ret;
    }

    public static int countForDown = 0;
    public static int countForDownWorked = 0;

    public static int prunedByParentBounds = 0;

    private void findAllPairsBetweenIdxArrayAndNodeDown(DistTreeNode3 refNode, int refIdx, int[] refArray, DistTreeNode3 node, AutoExpandIntArray allPairs) {
        int allPairsOldSize = allPairs.size();
        if (node == null)
            return;
        //

        if (refIdx < 0)
        if (canPruned(refNode.getAllRefBounds(),node.getAllRefBounds()))
        {
//            System.out.println(refNode.idx + " skip, prune by parent bounds! " + node.idx);
            prunedByParentBounds ++;
            return;
        }

        countForDown++;
        int idx1 = node.idx;

        if (refIdx < 0) {
            if (idx1 < 0) {
                node.bufferArray.shrink();
                findAllPairsBetweenIdxArrays(refArray, node.bufferArray.getArray(), allPairs);

                //for node children
                //deal with children//size should be 0
//                for (int i = 0; i < node.children.size(); i++) {
//                    DistTreeNode2 distTreeNode = node.children.get(i);
//                    findAllPairsBetweenIdxArrayAndNodeDown(refIdx, refArray, distTreeNode, allPairs);
//                }
            } else //idx1 >=0
            {
                node.pairIdxArray.shrink();
                findAllPairsBetweenIdxArrays(refArray, node.pairIdxArray.getArray(), allPairs);
                findAllPairsBetweenIdxArrays(refArray, new int[]{idx1}, allPairs);

                //for node children
                //deal with children
                if (refNode != null) {
                    DistTreeNode3 refParentNode = refNode.parent;
                    int refParentIdx = refParentNode.idx;
                    double distance = cacheDistance(refParentIdx, idx1);
//                    double distance = distance(refParentIdx, idx1);
                    double times = distance / range;

                    for (int i = 0; i < node.children.size(); i++) {
                        DistTreeNode3 distTreeNode = node.children.get(i);
                        if ((times <= distTreeNode.distanceTimes + refNode.distanceTimes + 3) && (times > Math.abs(distTreeNode.distanceTimes - refNode.distanceTimes) - 2))
//                        if ((times <= distTreeNode.distanceTimes + refNode.distanceTimes + 3))
                            findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                } else {
                    for (int i = 0; i < node.children.size(); i++) {  //todo:
                        DistTreeNode3 distTreeNode = node.children.get(i);
                        findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                }
            }
        } else {
            if (idx1 < 0) {
                node.bufferArray.shrink();
                findAllPairsBetweenIdxArrays(refArray, node.bufferArray.getArray(), allPairs);
                findAllPairsBetweenIdxArrays(new int[]{refIdx}, node.bufferArray.getArray(), allPairs);

                //for node children
                //deal with children//size should be 0
//                for (int i = 0; i < node.children.size(); i++) {
//                    DistTreeNode2 distTreeNode = node.children.get(i);
//                    findAllPairsBetweenIdxArrayAndNodeDown(refIdx, refArray, distTreeNode, allPairs);
//                }
            } else //idx1 >=0
            {
                double distance = cacheDistance(refIdx, idx1);
//                double distance = distance(refIdx, idx1);
                if (distance <= range) {
                    allPairs.append(refIdx, node.idx);
                }

                double times = distance / range;
//        if (distance <= 3 * range) {
                if (times <= 3) {
                    AutoExpandIntArray pairIdxArray1 = node.pairIdxArray;
                    pairIdxArray1.shrink();
                    int[] array = pairIdxArray1.getArray();

                    findAllPairsBetweenIdxArrays(refArray, array, allPairs);
                    //miss node.idx time series? so check it
                    findAllPairsBetweenIdxArrays(refArray, new int[]{node.idx}, allPairs);

                    findAllPairsBetweenIdxArrays(new int[]{refIdx}, array, allPairs);
                }

                //deal with children of target node
                for (int i = 0; i < node.children.size(); i++) {
                    DistTreeNode3 distTreeNode = node.children.get(i);
//            if (times <= distTreeNode.distanceTimes + 3)
                    if ((times <= distTreeNode.distanceTimes + 3) && (times > distTreeNode.distanceTimes - 2)) {
                        //do with refNode's parent node
/*
                        DistTreeNode2 p = refNode.parent;
                        int cTimes = refNode.distanceTimes;
                        boolean parentPruned = false;
                        while (p != null)
                        {
//                            if (canPruned(p.idx, cTimes,distTreeNode.parent.idx, distTreeNode.distanceTimes))
//                            if (canPruned(p, distTreeNode))
                            {
                                parentPruned = true;
//                                System.out.println(refNode + "is pruned by parent = " + p + " for node " + distTreeNode);
                            }
                            cTimes = p.distanceTimes;
                            p = p.parent;
                        }
                        if (parentPruned)
                            continue;
*/

                        findAllPairsBetweenIdxArrayAndNodeDown(refNode, refIdx, refArray, distTreeNode, allPairs);
                    }
                }
            }
        }

        if (allPairs.size() > allPairsOldSize) {
            countForDownWorked++;
        }
    }

    private boolean canPruned(int idx1, int times1, int idx2, int times2) {
        boolean ret = false;
        if (idx1 >= 0 && idx2 >=0)
        {
            double distance = cacheDistance(idx1, idx2);
            double times = distance / range;
//            if ((times > (node1.distanceTimes + node2.distanceTimes + 3)) || (times < (Math.abs(node1.distanceTimes - node2.distanceTimes) - 2)))
            if ((times > (times1 + times2 + 3)) || (times < (Math.abs(times1 - times2) - 2)))
                ret = true;
        }
        return ret;
    }

    public static int distCount = 0;

    public static HashMap<Long, Double> distMap = new HashMap<Long, Double>();

    public double distance(int idx1, int idx2) {
        distCount++;
        return DistUtil.euclideanDist(timeSeries[idx1], timeSeries[idx2]);
    }

    public double cacheDistance(int idx1, int idx2) {
        long key = idx1 * 100000L + idx2;
        if (!distMap.containsKey(key)) {
            double distance = distance(idx1, idx2);
            distMap.put(key, distance);
            return distance;
        }
        return distMap.get(key);
    }

    public static long lowerBoundCount = 0;
    public static long distLessThanCount = 0;

    public void findAllPairsForIdxArray(int[] idxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        double[][] newTimes = new double[idxArray.length][];
        double[][] newReduced = new double[idxArray.length][];
        for (int i = 0; i < newTimes.length; i++) {
            newTimes[i] = timeSeries[idxArray[i]];
            newReduced[i] = reducedTimeSeries[idxArray[i]];
        }
        AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, newTimes, newReduced, segmentLength, range, pairsArray);
        /*for (int i = 0; i < idxArray.length; i++) {
            final int idx1 = idxArray[i];
            final double[] ts1 = timeSeries[idx1];
            for (int j = i + 1; j < idxArray.length; j++) {
                final int idx2 = idxArray[j];
//                final double[] ts2 = timeSeries[idx2];

                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    distLessThanCount++;
                    final double[] ts2 = timeSeries[idx2];
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(idx1, idx2);
                    }
                }
            }
        }*/
    }

    public void findAllPairsBetweenIdxArrays(int[] leftIdxArray, int[] rightIdxArray, AutoExpandIntArray pairsArray) {
        //do brute force search and resort the array in new order
        double[][] leftTimes = new double[leftIdxArray.length][];
        double[][] leftReduced = new double[leftIdxArray.length][];
        for (int i = 0; i < leftTimes.length; i++) {
            leftTimes[i] = timeSeries[leftIdxArray[i]];
            leftReduced[i] = reducedTimeSeries[leftIdxArray[i]];
        }

        double[][] rightTimes = new double[rightIdxArray.length][];
        double[][] rightReduced = new double[rightIdxArray.length][];
        for (int i = 0; i < rightTimes.length; i++) {
            rightTimes[i] = timeSeries[rightIdxArray[i]];
            rightReduced[i] = reducedTimeSeries[rightIdxArray[i]];
        }

        for (int i = 0; i < leftTimes.length; i++) {
            double[] ts1 = leftTimes[i];
            for (int j = 0; j < rightTimes.length; j++) {
                double[] ts2 = rightTimes[j];
                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(leftReduced[i], rightReduced[j], segmentLength, range)) {
                    distLessThanCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(leftIdxArray[i], rightIdxArray[j]);
                    }
                }
            }
        }
    }

/*
    public void findAllPairsBetweenIdxArrays(int[] leftIdxArray, int[] rightIdxArray, AutoExpandIntArray pairsArray) {
        //do brute force search
        for (int i = 0; i < leftIdxArray.length; i++) {
            int idx1 = leftIdxArray[i];
            double[] ts1 = timeSeries[idx1];
            for (int j = 0; j < rightIdxArray.length; j++) {
                int idx2 = rightIdxArray[j];
                double[] ts2 = timeSeries[idx2];

                //use early abandon and reduced dimension
                lowerBoundCount++;
                if (AllPairUtils.lowerBoundLessThan(reducedTimeSeries[idx1], reducedTimeSeries[idx2], segmentLength, range)) {
                    distLessThanCount++;
                    if (DistUtil.euclideanDistLessThan(ts1, ts2, range)) {
                        pairsArray.append(idx1, idx2);
                    }
                }

                //use early abandon
//                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
//                    pairsArray.append(idx1, idx2);

//                double distance = DistUtil.euclideanDist(ts1, ts2);
//                if (distance <= range) {
//                    pairsArray.append(idx1, idx2);
//                }
            }
        }
    }
*/

    public double[][] getNodeTimeSeries() {
        double[][] ret = new double[pairIdxArray.size() + 1][timeSeries[0].length];
        //add those ts in pair
        for (int i = 0; i < ret.length; i++) {
            ret[i] = timeSeries[pairIdxArray.get(i)];
        }
        ret[ret.length - 1] = timeSeries[idx]; //append node idx

        return ret;
    }

    @Override
    public String toString() {
        return "DistTreeNode{" +
                "parent.idx=" + (parent == null ? "null" : parent.idx) +
                ", idx=" + idx +
                ", count=" + count +
                ", distanceTimes=" + distanceTimes +
                ", pairIdxArray=" + pairIdxArray.size() +
                ", children=" + children.size() +
                '}';
    }

    public String toXml() {

//        System.out.println("idx = " + idx);
//        if (parent != null)
//            System.out.println("parent = " + parent.idx);

        pairIdxArray.shrink();
        int[] array = pairIdxArray.getArray();
        bufferArray.shrink();
        int[] buffer = bufferArray.getArray();
        StringBuilder sb = new StringBuilder();
        String tagStart = MessageFormat.format("<node3 idx=\"{0}\" count=\"{1}\" pdTimes=\"{2}\" array=\"{3}\" parent=\"{4}\" buffer=\"{5}\" level=\"{6}\">", idx + "", count + "", distanceTimes, joinArray(array), parent == null ? null : parent.idx + "", joinArray(buffer), level + "");
//        String tagStart = MessageFormat.format("<node2 idx=\"{0}\" count=\"{1}\" pdTimes=\"{2}\" array=\"{3}\" parent=\"{4}\" buffer=\"{5}\">", "0", "1", "2", "3", "4","5");
        sb.append(tagStart).append("\n");

        for (int i = 0; i < children.size(); i++) {
            DistTreeNode3 distTreeNode = children.get(i);
            sb.append(distTreeNode.toXml());
        }

        sb.append("</node3>").append("\n");
        return sb.toString();
    }

    public String joinArray(int[] array) {
        StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < Math.min(array.length, 4); i++) {
        for (int i = 0; i < array.length; i++) {
            int i1 = array[i];
            sb.append(i1);
            sb.append(",");
        }
        return sb.toString();
    }
}
