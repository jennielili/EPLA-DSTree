package cn.edu.fudan.cs.dstree.allpair;

import java.io.Serializable;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AutoExpandIntArray implements Serializable {
    private int[] array;

    public int[] getArray() {
        return array;
    }

    public AutoExpandIntArray(int initSize) {
        array = new int[initSize];
    }

    public AutoExpandIntArray(int[] array) {
        this.array = array;
    }

    private int offset = -1;
    private double expandFactory = 1.5;

    public double getExpandFactory() {
        return expandFactory;
    }

    public void setExpandFactory(double expandFactory) {
        this.expandFactory = expandFactory;
    }

    public void append(int value) {
        offset++;
        if (offset == array.length) {
            //do expand
            int[] newArray = new int[(int) (array.length * expandFactory)];
            System.arraycopy(array, 0, newArray, 0, array.length);
            array = newArray;
        }

        array[offset] = value;
    }

    public void append(int value1, int value2)
    {
        append(value1);
        append(value2);
    }

    public int getCapacity()
    {
        return array.length;
    }

    public int get(int i) {
        return array[i];
    }

    public int size()
    {
        return offset + 1;
    }

    public void shrink()
    {
        int length = offset + 1;
        if (array.length > length) {
            int[] newArray = new int[length];
            System.arraycopy(array, 0, newArray, 0, newArray.length);
            array = newArray;
        }
    }

    public void clear() {
        offset = -1;
    }
}
