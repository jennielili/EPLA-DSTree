package cn.edu.fudan.cs.dstree.allpair;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class LPA_normal_count {
/**
	 * @param args
	 */
	static HashMap mm=new HashMap();
	public static Integer number=100; 
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 
		 int[] counts=new int[100];
		 int[] counts_vertexes=new int[100];
		 int [][]cross=new int[100][100];
		 BufferedReader bb=new BufferedReader(new FileReader("D:\\cygwin_install\\home\\lqh\\hash19.txt"));
		 FileWriter fw = new FileWriter(
			"D:\\cygwin_install\\home\\lqh\\count_out2.txt");// ����FileWriter��������д���ַ���
		 BufferedWriter bw = new BufferedWriter(fw); // ��������ļ������
		 long time5 = System.currentTimeMillis();
		  int ii=0;
		    String newLine="";
		    String[] values=new String[2];
		    while(bb.ready())
			{
				newLine=bb.readLine();
				//System.out.println("new  line   is  "+newLine);
				if(newLine!=null && !newLine.trim().equals(""))
				{
					//System.out.println("the size  is  "+);
			    	values=newLine.split("\t");
			    	if(values.length>1)
			    	{
			    	//	System.out.println("key   is  "+values[0]  +"  value  is "+values[1]);
			    	    mm.put(values[0].trim(), values[1].trim());
			    	    Integer xx=Integer.parseInt(values[1].trim());
			    	    ii++;
			    	}
			    	
				}
				
			}
		   bb.close();
		   System.out.println("   mm   size    is  "+mm.size());
		   BufferedReader aab =new BufferedReader(new FileReader("D:\\cygwin_install\\home\\lqh\\hadoop_bak\\input_livejournal\\livejournal_all.txt"));
		//    BufferedReader aab =new BufferedReader(new FileReader("/home/hadoop/input.txt"));
			int jj=0;
			String newLine2="";
			String u="";
			HashMap map1 = new HashMap();
			int kk=0;
			int gg=0;
			int  error_number=0;
			while(aab.ready())
			{
				kk++;
				newLine2=aab.readLine();
		      //  System.out.println("   newLine    is   "+newLine2);
				String[] values2=newLine2.split("\t");
				int key=Integer.parseInt(values2[0].trim());
				String classString=(String)mm.get(values2[0].trim());
				Random ran=new Random();
				Integer keyclass=-1;
				if(classString==null)
					keyclass=ran.nextInt(number);
				else
					keyclass=Integer.parseInt((String)mm.get(values2[0].trim()));
				counts_vertexes[keyclass]++;
				String[] record = values2[1].toString().split(" ");
				if (record.length < 1)
				{
					gg++;
				//	System.out.println("   bad  new  line    is   "+newLine2);
					continue;
				}
              //  System.out.println("   the   length  of record     is   "+record.length);
				// from map get community ID , and give a maxmal one
				int count = record.length;
				int[] nei = new int[count];
				List aa = new ArrayList();
			//	Random ran=new Random();
				// ��һ���б���ʾ�ھ������ڵ�����id����
				for (int i = 0; i < count; i++) {
					 u = (String) mm.get(record[i].trim());
					 if(u==null)
					 {
						// System.out.println("  newLine2   is   "+record[i].trim());
						 error_number++;
						 continue;
					 }
					 Integer tt=Integer.parseInt(u.trim());
					 if(keyclass==tt)
						 counts[keyclass]++;
					 else
						 cross[keyclass][tt]++;
				}	
				
				if(kk%100000==0)
					System.out.println("             kk       is      "+kk);
				bw.newLine();
				
			}
			int sum=0;
			for(int mm=0;mm<number;mm++)
			{
				System.out.println("    for   "+mm+"  part     inner  edge   is  "+ counts[mm]
						);
				sum=sum+counts[mm];
			}
			
			
			for(int mm=0;mm<number;mm++)
			{
				System.out.println("    for   "+mm+"  part     inner  vertexes   is  "+ counts_vertexes[mm]
						);
				
			}
			System.out.println(" inner  edge     "+sum);
			int sum_cross=0;
			for(int mm=0;mm<number;mm++)
				for(int uu=0;uu<number;uu++)
				{
					if(mm!=uu)
						sum_cross+=cross[mm][uu];
						
				}
			System.out.println("intra  edge     "+sum_cross);
			System.out.println("error  number  is  "+error_number);
			bw.close();
			aab.close();
			long time4 = System.currentTimeMillis();
			long inter3 = time5 - time4;
			System.out
					.println("****************the  time   of  iteration     is  "
							+ inter3 / (1000 * 60) +"  mins");
			System.out
			.println("****************the  time   of  iteration    is  "
					+ inter3 / (1000 ) +"  seconds");
			System.out.println("       mm          size     is   "+mm.size());

	}

}
