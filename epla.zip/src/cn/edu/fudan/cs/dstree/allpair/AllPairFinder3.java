package cn.edu.fudan.cs.dstree.allpair;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairFinder3 {
    double[][] timeSeries;
    double range;
    double[][] reducedTimeSeries;
    int reducedDimensionCount;
    int[] segments;
    int segmentLength;
    int threshold;

    public AllPairFinder3(double[][] timeSeries, double range, double reduceRatio, int threshold) {
        this.timeSeries = timeSeries;
        this.range = range;
        this.threshold = threshold;

        int originalLength = timeSeries[0].length;
        reducedDimensionCount = (int) (originalLength * reduceRatio);

        if (originalLength % reducedDimensionCount != 0)
            throw new RuntimeException("reduceDimensionCount can not be divided!");
        segmentLength = originalLength / reducedDimensionCount;

        reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];

        segments = AllPairUtils.calcPoints(originalLength, reducedDimensionCount);
        for (int i = 0; i < timeSeries.length; i++) {
            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i], segments);
        }
    }

    public DistTreeNode3 buildTree() {
        DistTreeNode3 ret = new DistTreeNode3(null, 0, timeSeries, range, reducedTimeSeries, segmentLength, threshold);
        for (int i = 0; i < timeSeries.length; i++) {
            ret.appendTimeSeries(i);
//            if (i % 1000 == 0)
//                System.out.println(new Date() + " i = " + i);
        }

        return ret;
    }
}
