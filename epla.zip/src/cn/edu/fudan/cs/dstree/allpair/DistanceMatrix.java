package cn.edu.fudan.cs.dstree.allpair;

import java.io.IOException;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

public class DistanceMatrix {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 String fileName="d:\\Series_1000_100000.z.bin";
		 int tsLength=1000;
		 
		 double[][] timeSeries1 = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
		 System.out.println("timeSeries1=" + timeSeries1.length);
		 double[][] timeSeries = new double[10000][];
		 System.arraycopy(timeSeries1, 0, timeSeries, 0, timeSeries.length);
		 double[][][] matrix = new double[timeSeries.length][timeSeries.length][2];
		 int size=timeSeries.length;
		 System.out.println("size=" + size);
		 long t1 = System.currentTimeMillis();
		 for(int ii=0;ii<size;ii++)
		 {
			 System.out.println("ii=" + ii);
			 for(int jj=ii+1;jj<size;jj++)
			 {
				  matrix[ii][jj][0]=DistUtil.euclideanDist(timeSeries[ii], timeSeries[jj]);
				  matrix[ii][jj][1] = matrix[ii][jj][0];
			 }
		 }
		 long t2 = System.currentTimeMillis();
		 System.out.println(" " + (t2 - t1)/1000);
	}

}
