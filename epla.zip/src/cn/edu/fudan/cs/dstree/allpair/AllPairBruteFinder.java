package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.util.DistUtil;

/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairBruteFinder {
    double[][] timeSeries;
    double range;

    public AllPairBruteFinder(double[][] timeSeries, double range) {
        this.timeSeries = timeSeries;
        this.range = range;
    }

    public AutoExpandIntArray findAllPairs()
    {
        AutoExpandIntArray ret = new AutoExpandIntArray(1000);

        for (int i = 0; i < timeSeries.length; i++) {
            double[] ts1 = timeSeries[i];
            for (int j = i + 1; j < timeSeries.length; j++) {
                double[] ts2 = timeSeries[j];
                //use early abandon
                if (DistUtil.euclideanDistLessThan(ts1, ts2, range))
                    ret.append(i, j);

//                double dist = DistUtil.euclideanDist(ts1, ts2);
//                if (dist <= range)
//                {
//                    ret.append(i);
//                    ret.append(j);
//                }
            }
        }

        return ret;
    }
}
