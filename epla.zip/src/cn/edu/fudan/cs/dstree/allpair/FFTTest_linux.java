package cn.edu.fudan.cs.dstree.allpair;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.edu.fudan.cs.dstree.dynamicsplit.FileBufferManager;
import cn.edu.fudan.cs.dstree.dynamicsplit.INodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanNodeSegmentSplitPolicy;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevNodeSegmentSketchUpdater;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevRange;
import cn.edu.fudan.cs.dstree.dynamicsplit.MeanStdevSeriesSegmentSketcher;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtils;
import cn.edu.fudan.cs.dstree.util.system.SystemInfoUtilsImpl;

public class FFTTest_linux {
	private static final Log log = LogFactory
			.getLog(DSTreeAllPairFinderTest.class);
  //  public static String fileName = "c:\\data\\tao_normalize20";
    public static String fileName = "/home/hadoop/lqhdata/tao_normalize20";
	public static int threshold = 50;
	public static int segmentSize = 10;
	public static int reducedDimensionCount;
	public static int dft_m;
	public static double t;
	public static int tsSize=268796;
	public static int tsLength = 512;
	public double[][] timeSeries;

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		// testBuildTree();
		dft_m=Integer.parseInt(args[0]);
		t=Double.parseDouble(args[1]);
		reducedDimensionCount=8;
		tsSize=Integer.parseInt(args[2]);
		tsLength=Integer.parseInt(args[3]);
		//tsSize=Integer.parseInt(args[4]);
		testFindPairs();
	}

	

	public static void testFindPairs() throws IOException,
			ClassNotFoundException {

		int n = tsLength;
	//	double[][] timeSeries = TimeSeriesFileUtil
		//		.readSeriesFromBinaryFileAtOnce(fileName, tsLength, tsSize,1024);
		double[][] timeSeries = TimeSeriesFileUtil
			.readSeriesFromBinaryFileAtOnce(fileName, tsLength, tsSize,tsLength);
		double[][] norm_series = new double[timeSeries.length][n];
		for(int ii=0;ii<timeSeries.length;ii++)
		{
			for(int jj=0;jj<n;jj++)
				norm_series[ii][jj]=timeSeries[ii][jj];
		}
		complex[] value = new complex[n];
		MyFFT dft = new MyFFT();
		double[][] reducedTimeSeries;
		int[] segments;
		reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];
		/*segments = AllPairUtils.calcPoints(tsLength, reducedDimensionCount);
		for (int i = 0; i < timeSeries.length; i++) {
			reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i],
					segments);
		}*/
	  int ll = timeSeries.length;
		
	 //  int ll=50000;
	   int segmentLength = tsLength / reducedDimensionCount;
	   System.out.println("  tsLength  is    "+tsLength+"   reduedDimensionCount is  "+reducedDimensionCount);
		complex[][] norm_values = new complex[ll][n];
		int count2 = 0;
		// double t=1674595. t = 5.0;
		double ori_t = t;
		System.out.println("   amount  is   " + ll);
		// for(int ii=0;ii<100;ii++)
		// ll=100;
		StopWatch stopWatch2 = new StopWatch();
	    StopWatch stopWatch1 = new StopWatch();
		StopWatch stopWatch = new  StopWatch();
		stopWatch1.start();
		stopWatch2.start();
		for (int ii = 0; ii < ll; ii++) {
			for (int jj = 0; jj < n; jj++)
				norm_values[ii][jj] = new complex(norm_series[ii][jj], 0);
		    dft.changedLow(norm_values[ii], n);
		    dft.fft_2(norm_values[ii], n, 1);

		}
	
		stopWatch2.stop();
		System.out.println("***********dft   *********"+stopWatch2.getTime());
		long allpair = 0;
		long skip = 0;
		long skip2 = 0;
		int skip3=0;
		int compare = 0;
		int ori_count = 0;
		int ori_count2 = 0;
		
		// System.out.println("   ori   count   is  "+ori_count2+"   time   is  "+stopWatch.getTime());
		stopWatch.start();
		for (int ii = 0; ii < ll; ii++) {
			if (ii % 5000 == 0) {
				stopWatch.stop();
				System.out.println("   ii   is   " + ii + "   count2 is  "
						+ count2 + "  skip  is  " + skip + "  skip2   is  "
						+ skip2 + "  time  is  " + stopWatch.getTime());
				stopWatch.reset();
				stopWatch.start();
			}
			
			
			for (int jj = ii + 1; jj < ll; jj++) {
				allpair++;
			//	double ori_dis2=DistUtil.euclideanDist(norm_series[ii], norm_series[jj]);
			  //  double ori_dis=dft.DFT_Edistance( norm_values[ii],norm_values[jj],dft_m,1024);
			   // double orig= DistUtil.euclideanDist(timeSeries[ii], timeSeries[jj]);
			 //   System.out.println("    normalize    is   "+ori_dis2
				// +" dft  is "+ori_dis+"   old is  "+orig); 
				boolean temp2 = dft.DFT_LessThan(norm_values[ii],
						norm_values[jj], dft_m, (t ) * (t ));
				if (!temp2) {
					skip++;
					continue;

				}
				
				if(temp2)
				{
					 compare++;
					 if (DistUtil.euclideanDistLessThan(timeSeries[ii], timeSeries[jj], t))
	                  {
						   
						    
	                    	count2++;
	                   }
					//count2++;
				}
			 /* if (!AllPairUtils.lowerBoundLessThan(reducedTimeSeries[ii], reducedTimeSeries[jj], segmentLength, t))
			  {
						 skip2++;
		                   
		       }
			   else
			   {
						 
						  if (DistUtil.euclideanDistLessThan(timeSeries[ii], timeSeries[jj], t))
		                  {
							  
		                    	count2++;
		                   }
				}*/
			

			}//for
		}//for

		stopWatch.stop();
		stopWatch1.stop();
		double rate=(double)skip/allpair;
		System.out.println("stopWatch1.getTime() = " + stopWatch1.getTime()
				+ "  pairs  is  " + count2 + "   allpair is " + allpair
				+ "   skip  " + skip + "skip2    is  "+skip2+" rate   is  " + rate
				+ "  compare  is  " + compare);

		
	}

	
}
