package cn.edu.fudan.cs.dstree.allpair;

/**
 * Created by wangyang on 2014/5/21.
 */
public class Pair implements Comparable<Pair>{
    int idx1;
    int idx2;

    public Pair(int idx1, int idx2) {
        this.idx1 = idx1;
        this.idx2 = idx2;
    }

    public int getIdx1() {
        return idx1;
    }

    public void setIdx1(int idx1) {
        this.idx1 = idx1;
    }

    public int getIdx2() {
        return idx2;
    }

    public void setIdx2(int idx2) {
        this.idx2 = idx2;
    }

    public void sort()
    {
        if (idx1 > idx2)
        {
            int tmp = idx1;
            idx1 = idx2;
            idx2 = tmp;
        }
    }

    @Override
    public int compareTo(Pair o) {
        if (this.idx1 != o.idx1)
        {
            return Integer.compare(idx1, o.idx1);
        }
        else
        {
            return Integer.compare(idx2, o.idx2);
        }
    }

    @Override
    public String toString() {
        return "Pair{" +
                "idx1=" + idx1 +
                ", idx2=" + idx2 +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Pair pair = (Pair) o;

        if (idx1 != pair.idx1) return false;
        if (idx2 != pair.idx2) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idx1;
        result = 31 * result + idx2;
        return result;
    }
}
