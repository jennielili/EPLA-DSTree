package cn.edu.fudan.cs.dstree.allpair;
import java.util.List;
/**
 * Created by wangyang on 2014/5/20.
 */
public class AllPairFinder2_2016 {
    double[][] timeSeries;
    double range;
    double[][] reducedTimeSeries;
    int reducedDimensionCount;
    int[] segments;
    int segmentLength;
    int threshold;
    List<double[]> refList;

    public AllPairFinder2_2016(double[][] timeSeries, double range, double reduceRatio, int threshold,List<double[]> refList) {
        this.timeSeries = timeSeries;
        this.range = range;
        this.threshold = threshold;
        this.refList=refList;

        int originalLength = timeSeries[0].length;
        reducedDimensionCount = (int) (originalLength * reduceRatio);

        if (originalLength % reducedDimensionCount != 0)
            throw new RuntimeException("reduceDimensionCount can not be divided!");
        segmentLength = originalLength / reducedDimensionCount;

        reducedTimeSeries = new double[timeSeries.length][reducedDimensionCount];

        segments = AllPairUtils.calcPoints(originalLength, reducedDimensionCount);
        for (int i = 0; i < timeSeries.length; i++) {
            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i], segments);
        }
    }

    public DistTreeNode2_2016 buildTree() {
        DistTreeNode2_2016 ret = new DistTreeNode2_2016(null, 0, timeSeries, range, reducedTimeSeries, segmentLength, threshold,refList);
        for (int i = 0; i < timeSeries.length; i++) {
            ret.appendTimeSeries(i);
          // if (i % 200000 == 0)
            //  System.out.println( " i = " + i);
        }

        return ret;
    }
}
