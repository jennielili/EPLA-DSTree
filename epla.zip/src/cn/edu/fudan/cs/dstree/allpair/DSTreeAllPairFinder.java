package cn.edu.fudan.cs.dstree.allpair;

import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeSegmentSketch;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.*;

/**
 * Created by wangyang on 2014/7/6.
 */
public class DSTreeAllPairFinder {
    private static final Log log = LogFactory.getLog(DSTreeAllPairFinder.class);

    double paaReduceRatio = 0.01;
    private int segmentLength;

    public double getPaaReduceRatio() {
        return paaReduceRatio;
    }

    public void setPaaReduceRatio(double paaReduceRatio) {
        this.paaReduceRatio = paaReduceRatio;
    }

    List<Node> nodeList = new ArrayList<Node>();
    Map<Node, Integer> nodeMap = new HashMap<Node, Integer>();

    List<int[]> idxArrayList = new ArrayList<int[]>();

    double[][] timeSeries;
    double[][] reducedTimeSeries;
    int tsLength;

    public double[][] getTimeSeries() {
        return timeSeries;
    }

    public int getTsLength() {
        return tsLength;
    }

    public void setTsLength(int tsLength) {
        this.tsLength = tsLength;
    }

    Node root;

    public void loadIndexAndData(String index) throws IOException, ClassNotFoundException {
        root = Node.loadFromFile(index);
        log.debug("root = " + root);

        //fina all terminal node
        loadTerminalNodes(root);

        //prepare the nodeMap
        for (int i = 0; i < nodeList.size(); i++) {
            Node node = nodeList.get(i);
            nodeMap.put(node, i);
        }
        log.debug("nodeList.size() = " + nodeList.size());
        log.debug("nodeList total pairs = " + nodeList.size() * nodeList.size() / 2);

        int size = root.getSize();
        timeSeries = new double[size][tsLength];
        reducedDimensionCount = (int) (tsLength * paaReduceRatio);

        if (tsLength % reducedDimensionCount != 0)
            throw new RuntimeException("reduceDimensionCount can not be divided!");
        segmentLength = tsLength / reducedDimensionCount;

        reducedTimeSeries = new double[size][reducedDimensionCount];
        loadData();
        log.debug("idxArrayList.size() = " + idxArrayList.size());
    }

    int reducedDimensionCount;
    int[] segments;


    private void loadData() throws IOException {
        int idx = 0;
        for (int i = 0; i < nodeList.size(); i++) {
            Node node = nodeList.get(i);
            String fileName = node.getFileName();
            double[][] tss = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, tsLength);
            int[] idxArray = new int[node.getSize()];
            for (int j = 0; j < tss.length; j++) {
                double[] ts = tss[j];
                idxArray[j] = idx;
                timeSeries[idx] = ts;
                idx++;
            }

            idxArrayList.add(idxArray);
        }

        //deal with reducedTimeSeries
        segments = AllPairUtils.calcPoints(tsLength, reducedDimensionCount);
        for (int i = 0; i < timeSeries.length; i++) {
            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeSeries[i], segments);
        }
    }

    public void loadTerminalNodes(Node node) {
        if (node == null)
            return;

        if (node.isTerminal()) {
            nodeList.add(node);
        } else {
            Node left = node.getLeft();
            loadTerminalNodes(left);

            Node right = node.getRight();
            loadTerminalNodes(right);
        }
    }


    public void findAllPairs(AutoExpandIntArray allPairs, double range) {
        //find pairs in node
        for (int i = 0; i < idxArrayList.size(); i++) {
            int[] idxArray = idxArrayList.get(i);
            double[][] tss = new double[idxArray.length][];
            double[][] reducedTss = new double[idxArray.length][];

            for (int j = 0; j < idxArray.length; j++) {
                tss[j] = timeSeries[idxArray[j]];
                reducedTss[j] = reducedTimeSeries[idxArray[j]];
            }

            AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(idxArray, tss, reducedTss, segmentLength, range, allPairs);
        }

        //search the nodeList and get possible node pairs
//        List<int[]> nodeIdxPairList = findNodePairs(range);
        List<int[]> nodeIdxPairList = findNodePairsNew(range);
        log.debug("nodeIdxPairList.size() = " + nodeIdxPairList.size());
        int totalNodePairs = nodeList.size() * (nodeList.size() - 1) / 2;
        log.debug("nodeIdxPairList ratio = " + nodeIdxPairList.size() * 1.0 / totalNodePairs);

        //verify the time series between node pair
        for (int i = 0; i < nodeIdxPairList.size(); i++) {
            int[] nodeIdxPair = nodeIdxPairList.get(i);
            int nodeIdx0 = nodeIdxPair[0];
            int nodeIdx1 = nodeIdxPair[1];

            int[] leftIdxArray = idxArrayList.get(nodeIdx0);
            int[] rightIdxArray = idxArrayList.get(nodeIdx1);

            AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeSeries, reducedTimeSeries, leftIdxArray, rightIdxArray, range, segmentLength, allPairs);
        }
    }

    private List<int[]> findNodePairs(double range) {
        log.debug("DSTreeAllPairFinder.findNodePairs begin");
        List<int[]> ret = new ArrayList<int[]>();

        for (int i = 0; i < nodeList.size(); i++) {
            Node node1 = nodeList.get(i);
            for (int j = i + 1; j < nodeList.size(); j++) {
                Node node2 = nodeList.get(j);

                if (lowerBound(node1, node2) <= range) {
                    ret.add(new int[]{i, j});
                }
            }
        }

        log.debug("DSTreeAllPairFinder.findNodePairs end");

        return ret;
    }

    private List<int[]> findNodePairsNew(double range) {
        log.debug("DSTreeAllPairFinder.findNodePairsNew begin");

        List<int[]> ret = new ArrayList<int[]>();

        //deep search
        Stack<Node> firstTraverseStack = new Stack<Node>();
        Stack<Node> secondTraverseStack = new Stack<Node>();
        firstTraverseStack.push(root);

        while (!firstTraverseStack.isEmpty()) {
            Node firstVisitNode = firstTraverseStack.pop();
            if (firstVisitNode.isTerminal()) {
                int i = nodeMap.get(firstVisitNode);

                //find pair node after the current node
                secondTraverseStack.clear();

                secondTraverseStack.addAll(firstTraverseStack);

                while (!secondTraverseStack.isEmpty()) {
                    Node secondVisitNode = secondTraverseStack.pop();
                    if (secondVisitNode.isTerminal()) {
                        //calc lowerBound
                        if (lowerBound(firstVisitNode, secondVisitNode) <= range) {
                            int j = nodeMap.get(secondVisitNode);
                            ret.add(new int[]{i, j});
                        }
                    } else {
                        if (lowerBound(firstVisitNode, secondVisitNode) <= range) {
                            Node left = secondVisitNode.getLeft();
                            if (left != null)
                                secondTraverseStack.push(left);

                            Node right = secondVisitNode.getRight();
                            if (right != null)
                                secondTraverseStack.push(right);
                        }
                    }
                }
            } else {
                Node left = firstVisitNode.getLeft();
                if (left != null)
                    firstTraverseStack.push(left);

                Node right = firstVisitNode.getRight();
                if (right != null)
                    firstTraverseStack.push(right);
            }
        }

//        for (int i = 0; i < nodeList.size(); i++) {
//            Node node1 = nodeList.get(i);
//            for (int j = i + 1; j < nodeList.size(); j++) {
//                Node node2 = nodeList.get(j);
//
//                if (lowerBound(node1, node2) <= range) {
//                    ret.add(new int[]{i, j});
//                }
//            }
//        }
        log.debug("DSTreeAllPairFinder.findNodePairsNew end");

        return ret;
    }

    private double lowerBound(Node node1, Node node2) {
        double sum = 0;
        //assume the node1 and node2 have the same segmentation
        NodeSegmentSketch[] nodeSegmentSketches = node1.getNodeSegmentSketches();
        for (int i = 0; i < nodeSegmentSketches.length; i++) {
//            nodeSegmentSketch.indicators[0] = Float.MAX_VALUE * -1; //for max mean
//            nodeSegmentSketch.indicators[1] = Float.MAX_VALUE; //for min mean
//            nodeSegmentSketch.indicators[2] = Float.MAX_VALUE * -1; //for max stdev
//            nodeSegmentSketch.indicators[3] = Float.MAX_VALUE; //for min stdev

            double node1MaxAvg = node1.getNodeSegmentSketches()[i].indicators[0];
            double node1MinAvg = node1.getNodeSegmentSketches()[i].indicators[1];
            double node1MaxStd = node1.getNodeSegmentSketches()[i].indicators[2];
            double node1MinStd = node1.getNodeSegmentSketches()[i].indicators[3];

            double node2MaxAvg = node2.getNodeSegmentSketches()[i].indicators[0];
            double node2MinAvg = node2.getNodeSegmentSketches()[i].indicators[1];
            double node2MaxStd = node2.getNodeSegmentSketches()[i].indicators[2];
            double node2MinStd = node2.getNodeSegmentSketches()[i].indicators[3];

            int segmentLength1 = node1.getSegmentLength(i);

            Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
            Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

            double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
            if (avgDistance != 0) {
                sum += avgDistance * avgDistance * segmentLength1;
            }

            Range node1StdRange = new Range(node1MinStd, node1MaxStd);
            Range node2StdRange = new Range(node2MinStd, node2MaxStd);

            double stdDistance = Range.distance(node1StdRange, node2StdRange);
            if (stdDistance != 0) {
                sum += stdDistance * stdDistance * segmentLength1;
            }
        }
        sum = Math.sqrt(sum);
        return sum;
    }
}

