package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.lang.time.StopWatch;

import java.util.*;

/**
 * Created by wrq on 12/9/14.
 * quick find the longest high sequence quickly
 */
public class QuickPlusLHSMiner3 extends LHSMiner {

    ArrayList<DetailSegment> keySegList = new ArrayList<DetailSegment>();

    @Override
    public void process() {
        double smallestCumulativeGain = Double.MAX_VALUE;
        double cumulativeGain = 0;
        int from = -1;

        for (int i = 0; i < timeSeries.length; i++) {
            double value = timeSeries[i];
            cumulativeGain += (value - threshold);

            if (cumulativeGain < smallestCumulativeGain) //new detail segment or update detail segment
            {
                if (from < 0) //not init
                {
                    from = i;
                }

                smallestCumulativeGain = cumulativeGain;
            } else // >= smallestCumulativeGain
            {
                if (from >= 0) { //init
                    DetailSegment detailSegment = new DetailSegment();
                    detailSegment.setFrom(from);
                    detailSegment.setTo(i); //attention not include i
                    detailSegment.setCumulativeGain(smallestCumulativeGain); //not include i
//                    if (keySegList.size() == 0)  //these below two line only for debug
//                        detailSegment.setGain(smallestCumulativeGain);
//                    else
//                        detailSegment.setGain(smallestCumulativeGain - keySegList.get(keySegList.size() - 1).getCumulativeGain());

                    keySegList.add(detailSegment);

                    from = -1;
                }
            }

            //do search
            DetailSegment candidateSegment = null;
            for (int j = keySegList.size() - 1; j >= 0; j--) {
                if (cumulativeGain > keySegList.get(j).cumulativeGain) {
                    candidateSegment = keySegList.get(j);
                } else {
                    break;
                }
            }

            if (candidateSegment != null) {
                //get the most left candidate
                if (i + 1 - candidateSegment.getFrom() > maxLength) {  //length upper bound
                    double currentGain = cumulativeGain - candidateSegment.cumulativeGain;
//                    for (int k = candidateSegment.getTo() - 1; k >= candidateSegment.getFrom(); k--) {
                    for (int k = candidateSegment.getTo(); k >= candidateSegment.getFrom(); k--) {
//                        currentGain += (timeSeries[k] - threshold);
                        if (currentGain >= 0) {
                            if (i + 1 - k > maxLength) {
                                left = k;
                                right = i + 1;
                                maxLength = right - left;
//                                System.out.println("this = " + this + "  " + avg(timeSeries, left, right));
                            }
                            // System.out.println("maxLength = " + maxLength);
                        } else
                            break;

                        if (k - 1 >= 0)
                            currentGain += (timeSeries[k - 1] - threshold);
                        else
                            break;
                    }
                }
            } else  //deal with the first segment or whole segment
            {
                if (cumulativeGain > 0) {
                    left = 0;
                    right = i + 1;
                    maxLength = right - left;
                }
            }
        }


        System.out.println("keySegList = " + keySegList.size());
//        for (int i = 0; i < keySegList.size(); i++) {
//            DetailSegment detailSegment = keySegList.get(i);
//            System.out.println("detailSegment = " + detailSegment);
//        }
    }

    public QuickPlusLHSMiner3(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }

    public static void main(String[] args) {
        double[] ts = CpuUsageGenerator.gen(1000);
//        double[] ts = CpuUsageGenerator.gen1m();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        LHSMiner miner = new QuickPlusLHSMiner3(ts, 55.8);
        miner.process();
        stopWatch.stop();
        System.out.println("miner = " + miner);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

        double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
        System.out.println("avg = " + avg);

        double avg1 = LHSMiner.avg(ts, 0, ts.length);
        System.out.println("avg1 = " + avg1);
    }
}
