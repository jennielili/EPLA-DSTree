package cn.edu.fudan.cs.dstree.lhsm;

/**
 * Created by wangyang on 2014/9/12.
 */
public class Segment implements Comparable<Segment> {
    int from;
    int to;//不包含
    double avg;

    public int getLength() {
        return to - from;
    }

    public Segment() {
    }

    public Segment(int from, int to) {
        this.from = from;
        this.to = to;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public double getAvg() {
        return avg;
    }

    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public int getTo() {
        return to;
    }

    public void setTo(int to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "Segment{" +
                "from=" + from +
                ", to=" + to +
                ", avg=" + avg +
                ", len=" + (to - from) +
                '}';
    }

    @Override
    public int compareTo(Segment o) {
        return Integer.compare(this.getLength(), o.getLength());
    }
}
