package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.lang.time.StopWatch;

import java.util.ArrayList;

/**

 */
public class QuickPlusLHSApproxMiner extends LHSMiner {

    ArrayList<KeyItem> keyItemList = new ArrayList<KeyItem>();
    //    LinkedList<KeyItem> keyItemList = new LinkedList<KeyItem>();

    @Override
    public void process() {
        KeyItem lastKeyItem = new KeyItem(Double.MAX_VALUE, -1);
        double cumulativeGain = 0;
        for (int i = 0; i < timeSeries.length; i++) {
            double value = timeSeries[i];
            cumulativeGain += (value - threshold);

            if (cumulativeGain >= 0) {  // from the start
                left = 0;
                right = i + 1;
                maxLength = right - left;
                maxLengthUpperBound = maxLength;
            } else {
                for (int j = keyItemList.size() - 1; j >= 0; j--) {
                    KeyItem candidateKeyItem = keyItemList.get(j);
                    if (cumulativeGain > candidateKeyItem.toCumulativeGain) {
                        if (cumulativeGain > candidateKeyItem.fromCumulativeGain) {
                            if (i - candidateKeyItem.from > maxLength) {
                                left = candidateKeyItem.from + 1;
                                right = i + 1;
                                maxLength = right - left;
                                maxLengthUpperBound = maxLength;
                            }
                        } else if (i - candidateKeyItem.to > maxLength) {
                            left = candidateKeyItem.to + 1;
                            right = i + 1;
                            maxLength = right - left;
                            maxLengthUpperBound = i + 1 - candidateKeyItem.from - 1 - 1;
//                        System.out.println("maxLength = " + maxLength);
                        } else if (i - candidateKeyItem.from > maxLength) {
                            //it's complicated, just for below cases
                            //when threshold = 57.6 and size of time series is 10000
                            //when i == 2822 get a exact result and maxLength = lengthUpp = 2470
                            //but when i = 2824 the maxLength lower bound is 2469 but the upper bound is 2471, so the upper  bound should updated
                            if (i + 1 - candidateKeyItem.from - 1 - 1 > maxLength)
                                maxLengthUpperBound = i + 1 - candidateKeyItem.from - 1 - 1;
                        }
                    } else
                        break;
                }
            }


            //add to keyItemList
            if (cumulativeGain < lastKeyItem.toCumulativeGain) {
                lastKeyItem = new KeyItem(cumulativeGain, i);
                keyItemList.add(lastKeyItem);
            }

            //update keyItemList according to  errorBound and i


            if ((i + 1) % checkPoint == 0) { //do merge
//                System.out.println("do merge!");
                int j = keyItemList.size() - 1;
                while (j > 0) {
                    KeyItem keyItem = keyItemList.get(j);
                    int currentLength = i - keyItem.to + 1;
                    double mergeToLeft = i + 1 - currentLength * (1 + errorBound) - 1; //extra minus one to merge 2 single keyItems
                    if (mergeToLeft < 1)
                        mergeToLeft = 1;
                    for (int k = j - 1; k >= 0; k--) {
                        KeyItem mergeKeyItem = keyItemList.get(k);
                        if (mergeKeyItem.from >= mergeToLeft) {
                            keyItem.from = mergeKeyItem.from;
                            keyItem.fromCumulativeGain = mergeKeyItem.fromCumulativeGain;
                            mergeKeyItem.merged = true;
                        } else {
                            j = k;
                            break;
                        }
                    }
                }

//                System.out.println("before merge keyItemList.size() = " + keyItemList.size());
                ArrayList<KeyItem> tempList = new ArrayList<KeyItem>();
                for (int l = 0; l < keyItemList.size(); l++) {
                    KeyItem keyItem = keyItemList.get(l);
                    if (!keyItem.merged) {
                        tempList.add(keyItem);
                    }
                }
                keyItemList = tempList;
//                System.out.println("after merge keyItemList.size() = " + keyItemList.size());
            }
        }

        System.out.println("keyItemList = " + keyItemList.size());
//        for (int i = 0; i < keyItemList.size(); i++) {
//            KeyItem keyItem = keyItemList.get(i);
//            System.out.println("keyItem = " + keyItem);
//        }
    }

    public QuickPlusLHSApproxMiner(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }

    class KeyItem implements Comparable<KeyItem> {
        double fromCumulativeGain;
        double toCumulativeGain;
        int from;
        int to;
        boolean merged = false;

        KeyItem(double cumulativeGain, int index) {
            this.fromCumulativeGain = cumulativeGain;
            this.toCumulativeGain = cumulativeGain;
            this.from = index;
            this.to = index;
        }

        @Override
        public int compareTo(KeyItem o) {
            return Double.compare(this.toCumulativeGain, o.toCumulativeGain);
        }

        @Override
        public String toString() {
            return "KeyItem{" +
                    ", from=" + from +
                    ", to=" + to +
                    ", fromCumulativeGain=" + fromCumulativeGain +
                    ", toCumulativeGain=" + toCumulativeGain +
                    ", merged=" + merged +
                    '}';
        }
    }

    public static void main(String[] args) {
        //full test please see QuickPlusLHSMinerTest.java
        double[] ts = CpuUsageGenerator.gen(1000 * 10);
//        double[] ts = CpuUsageGenerator.gen1m();
//        double[] errorBounds = {0.001, 0.005, 0.01, 0.02, 0.05};
        double[] errorBounds = {0.001};
//        double[] thresholds = {55, 60, 65, 70, 75, 80};
        double[] thresholds = {57.6};
        for (int i = 0; i < errorBounds.length; i++) {
            for (int j = 0; j < thresholds.length; j++) {
                double threshold = thresholds[j];
                double errorBound = errorBounds[i];
                StopWatch stopWatch = new StopWatch();

                LHSMiner miner = new QuickPlusLHSApproxMiner(ts, threshold);
                miner.setErrorBound(errorBound);
                System.out.println("miner.getErrorBound() = " + miner.getErrorBound());
                System.out.println("threshold = " + threshold);
                stopWatch.start();
                miner.process();
                stopWatch.stop();
                System.out.println("miner = " + miner);
                double actualErrorBound = (1.0 * miner.maxLengthUpperBound - miner.maxLength) / miner.maxLength;
                System.out.println("actualErrorBound = " + actualErrorBound);
                System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

                double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
                System.out.println("avg = " + avg);
            }
        }
    }
}
