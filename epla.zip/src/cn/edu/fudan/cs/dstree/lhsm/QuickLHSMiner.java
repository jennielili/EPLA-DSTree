package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.lang.time.StopWatch;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wrq on 12/9/14.
 * quick find the longest high sequence quickly
 *
 */
public class QuickLHSMiner extends LHSMiner {
    List<Segment> aboveList = new ArrayList<Segment>();
    List<Segment> belowList = new ArrayList<Segment>();

    @Override
    public void process() {

        //get the avg segments
        buildList();
//        System.out.println("totalSum = " + totalSum);


//        System.out.println("aboveList = " + aboveList.size());
//        System.out.println("belowList = " + belowList.size());

        for (int i = 0; i < aboveList.size(); i++) {
            Segment segment = aboveList.get(i);
            if (segment.getLength() > maxLength) {
                updateMaxInfo(segment.getFrom(), segment.getTo(), segment.getAvg() * segment.getLength());
            }
        }

        if (totalSum >= timeSeries.length * threshold) {
            //return
            updateMaxInfo(0, timeSeries.length, totalSum);
            return;
        }

        double segStartSum = totalSum;
        int span = -1;
        if (aboveList.get(0).getFrom() == 0) //start from above list
        {
            span = 0;
            Segment firstAboveSegment = aboveList.get(0);
            segStartSum = totalSum - firstAboveSegment.getLength() * firstAboveSegment.getAvg();
        }


        //search start from belowList
        for (int i = 0; i < belowList.size(); i++) {
            Segment belowSegment = belowList.get(i);


            double startSum = segStartSum;
            //the start point
            for (int j = belowSegment.getFrom(); j <= belowSegment.getTo(); j++) {
                //check from j to the end
////                boolean bFind = false;
//                if (j == 157445)
//                {
//                    System.out.println("j = " + j);
//                }

                int leftLength = timeSeries.length - j;

                if (leftLength <= maxLength)
                    break;

                if ((leftLength > maxLength) && (startSum > leftLength * threshold)) {
                    updateMaxInfo(j, timeSeries.length, startSum);
                }

                double currentSum = startSum;
                //skip the last above segment if it's the last segment of time series fixed the bug
                if (timeSeries[timeSeries.length-1] > threshold)
                {
                    Segment lastAboveSegment = aboveList.get(aboveList.size() - 1);
                    currentSum -= lastAboveSegment.getAvg() * lastAboveSegment.getLength();
                }

                //skip the below and above list from right to left until the start segment
                for (int k = belowList.size() - 1; k > i; k--) {

                    Segment belowSkipSegment = belowList.get(k);

                    int currentLength = belowSkipSegment.getFrom() - j;
                    if (currentLength + belowSkipSegment.getLength() <= maxLength)
                        break;

                    currentSum = currentSum - belowSkipSegment.getAvg() * belowSkipSegment.getLength();
                    double currentSumThreshold = threshold * currentLength;
                    if (currentSum >= currentSumThreshold) {
                        //stop and find the longest for start = j
                        for (int l = belowSkipSegment.getFrom(); l < timeSeries.length; l++) {
                            currentSum += timeSeries[l];
                            currentSumThreshold += threshold;
                            if (currentSum < currentSumThreshold) {
                                //got the longest for start = j
                                currentLength = l - j;

                                //update the best so far
                                if (currentLength > maxLength) {
                                    updateMaxInfo(j, l, currentSum - timeSeries[l]);
                                }

                                break;
                            }
                        }

                        break;
                    }

                    //skip the above list
                    Segment aboveSkipSegment = aboveList.get(k + span);
                    currentSum -= aboveSkipSegment.getAvg() * aboveSkipSegment.getLength();
                }

                startSum -= timeSeries[j];
            }

            int aboveLeftSkipIndex = i + span + 1;
            if (aboveLeftSkipIndex < aboveList.size()) {
                Segment aboveSkipSegment = aboveList.get(aboveLeftSkipIndex);
                segStartSum -= aboveSkipSegment.getAvg() * aboveSkipSegment.getLength();
            }
            segStartSum -= belowSegment.getAvg() * belowSegment.getLength();

        }
    }

    private void updateMaxInfo(int from, int to, double sum) {
        this.left = from;
        this.right = to;
        this.maxLength = (to - from);
        this.value = sum / this.maxLength;
//        System.out.println("maxLength = " + maxLength);

//        Segment segment = new Segment(from, to);
//        System.out.println("segment = " + segment);
//        double avg = avg(timeSeries, from, to);
//        System.out.println("avg = " + avg);
    }

    double totalSum = 0;

    private void buildList() {
        boolean above = (timeSeries[0] >= threshold); //trigger change
        double sum = timeSeries[0];
        totalSum = sum;
        int from = 0;
        for (int i = 1; i < timeSeries.length; i++) { //start from 1
            totalSum += timeSeries[i];
            if (timeSeries[i] < threshold) {
                if (!above)  //below
                {
                    sum += timeSeries[i];
                } else {
                    //add a segment
                    Segment segment = new Segment(from, i);
                    segment.setAvg(sum / (i - from));
                    aboveList.add(segment);
                    above = false;
                    from = i;
                    sum = timeSeries[i]; //reset
                }
            } else  // >=
            {
                if (above) {
                    sum += timeSeries[i];
                } else {
                    //add a segment
                    Segment segment = new Segment(from, i);
                    segment.setAvg(sum / (i - from));
                    belowList.add(segment);
                    above = true;
                    from = i;
                    sum = timeSeries[i]; //reset
                }
            }
        }

        Segment segment = new Segment(from, timeSeries.length);
        segment.setAvg(sum / (timeSeries.length - from));

        if (above)
            aboveList.add(segment);
        else
            belowList.add(segment);
    }


    public QuickLHSMiner(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }

    public static void main(String[] args) {
        double[] ts = CpuUsageGenerator.gen(1000 * 200);
//        double[] ts = CpuUsageGenerator.gen1m();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        LHSMiner miner = new QuickLHSMiner(ts, 80);
        miner.process();
        stopWatch.stop();
        System.out.println("miner = " + miner);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

        double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
        System.out.println("avg = " + avg);
    }
}
