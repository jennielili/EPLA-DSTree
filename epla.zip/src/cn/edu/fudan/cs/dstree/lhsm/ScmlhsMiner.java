/**
 * @Title: ScmlhsMiner.java
 * @Description: TODO
 * @author: Calvinyang
 * @date: Sep 12, 2014 9:36:04 PM
 * Copyright: Copyright (c) 2013
 * @version: 1.0
 */
package cn.edu.fudan.cs.dstree.lhsm;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.time.StopWatch;

import cn.edu.fudan.cs.dstree.lhsm.DetailSegment.SegmentType;

/**
 * @author: Calvinyang
 * @Description: Segment Classification Merge Longest High Sequence Miner
 * @date: Sep 12, 2014 9:36:04 PM
 */
public class ScmlhsMiner extends LHSMiner {
	double lhsSum;
	private StopWatch watch;

	private List<DetailSegment> segList;

	/**
	 * @param timeSeries
	 * @param threshold
	 */
	protected ScmlhsMiner(double[] timeSeries, double threshold) {
		super(timeSeries, threshold);
		segList = new ArrayList<DetailSegment>();
		watch = new StopWatch();
	}

	@Override
	public void process() {
		watch.start();
		// initial
		int from = 0;
		double sum = timeSeries[0];// xi + ... + xj
		SegmentType lastType = timeSeries[0] < threshold ? SegmentType.LT_SEGMENT : SegmentType.GE_SEGMENT;
		SegmentType currentType = SegmentType.NONE;
		// traverse to classification
		for (int i = 1; i < timeSeries.length; i++) {
			currentType = timeSeries[i] < threshold ? SegmentType.LT_SEGMENT : SegmentType.GE_SEGMENT;
			if (currentType != lastType) { // split a segment of another type
				// end a segment and add to list
				DetailSegment segment = new DetailSegment();
				segment.setFrom(from);
				segment.setTo(i);
				segment.setAvg(sum / segment.getLength());
				segment.setSum(sum);
				segment.setType(currentType == SegmentType.LT_SEGMENT ? SegmentType.GE_SEGMENT : SegmentType.LT_SEGMENT);
				segment.setGain((segment.getAvg() - threshold) * segment.getLength());
				segList.add(segment);
				// begin a new segment
				from = i;
				sum = 0;
			}
			sum += timeSeries[i];
			lastType = currentType;
		}
		// tail process
		DetailSegment segment = new DetailSegment();
		segment.setFrom(from);
		segment.setTo(timeSeries.length);
		segment.setAvg(sum / segment.getLength());
		segment.setType(currentType);
		segment.setGain((segment.getAvg() - threshold) * segment.getLength());
		segList.add(segment);
		watch.stop();
		System.out.println("split time => " + watch.getTime());
		System.out.println("seg count => " + segList.size());
		
		// reduce seglist count
		watch.reset();
		watch.start();
		// head process  => test if seglist start with lt_seg and whether the first two can combine
		if (segList.get(0).getType() == SegmentType.LT_SEGMENT && segList.size() > 1) {
			sum = segList.get(0).getSum() + segList.get(1).getSum();
			if (sum > threshold * (segList.get(0).getLength()) + segList.get(1).getLength()) {
				// combine the first two
				DetailSegment combinedSegment = segList.get(1); 
				combinedSegment.setSum(sum);
				combinedSegment.setFrom(segList.get(0).getFrom());
				combinedSegment.setAvg(sum / combinedSegment.getLength());
				combinedSegment.setGain((combinedSegment.getAvg() - threshold) * combinedSegment.getLength());
				// remove the first seg
				segList.remove(0);
			}
		}
		// loop process => starts from segList[2]
		for(int i = 2 ; i < segList.size() ; i += 2) {
			double last3Sum = segList.get(i).getSum() + segList.get(i - 1).getSum() + segList.get(i - 2).getSum();
			double last3Gain = last3Sum - threshold * (segList.get(i).getLength() + segList.get(i - 1).getLength() + segList.get(i - 2).getLength());
			if (last3Gain > segList.get(i - 2).getGain() && last3Gain > segList.get(i).getGain()) {
				// combine the three
				DetailSegment combinedSegment = segList.get(i);
				combinedSegment.setSum(last3Sum);
				combinedSegment.setFrom(segList.get(i - 2).getFrom());
				combinedSegment.setAvg(last3Sum / combinedSegment.getLength());
				combinedSegment.setGain((combinedSegment.getAvg() - threshold) * combinedSegment.getLength());
				// remove two before current
				segList.remove(i - 1);
				segList.remove(i - 2);
				i -= 2;
			}
		}
		// tail process => test if seglist end with lt_seg and whether the las two can combine
		int size = segList.size();
		if (segList.get(size - 1).getType() == SegmentType.LT_SEGMENT && size > 1) {
			sum = segList.get(size - 1).getSum() + segList.get(size - 2).getSum();
			if (sum > threshold * (segList.get(size - 1).getLength()) + segList.get(size - 2).getLength()) {
				// combine the last two
				DetailSegment combinedSegment = segList.get(size - 2);
				combinedSegment.setSum(sum);
				combinedSegment.setTo(segList.get(size - 1).getTo());
				combinedSegment.setAvg(sum / combinedSegment.getLength());
				combinedSegment.setGain((combinedSegment.getAvg() - threshold) * combinedSegment.getLength());
				// remove the last seg
				segList.remove(size - 1);
			}
		}
		
		watch.stop();
		System.out.println("reduce seg time => " + watch.getTime());
		System.out.println("reduced seg count => " + segList.size());
		
		watch.reset();
		watch.start();
		// bruteforce
		sum = 0;
		double sumThres = 0;
		int len = 0;
		for (int i = 0; i < segList.size(); i++) {
			sum = segList.get(i).getSum();
			len = segList.get(i).getLength();
			sumThres = len * threshold;
			// test only one segment
			if (sum > sumThres) {
				int leftNeighor = i == 0 ? segList.get(i).getFrom() : segList.get(i - 1).getFrom();// left neighor begin position
				int rightNeighor = i < segList.size() - 1 ? segList.get(i + 1).getTo() - 1 : segList.get(i).getTo();// next neighor position
				if (len > maxLength) {// it's always a better answer
					maxLength = len;
					left = segList.get(i).getFrom();
					right = segList.get(i).getTo();
					lhsSum = sum;
					value = sum / len;
					extendLonger(leftNeighor, rightNeighor);// to make the answer even better
				} else {
					if (rightNeighor - leftNeighor > maxLength) {// it may contain a better answer
						tryExtendLonger(leftNeighor, rightNeighor, len, sum, segList.get(i).getFrom(), segList.get(i).getTo());
					}
				}
			}
			// test more segments
			for (int j = i + 1; j < segList.size(); j ++) {
				sum += segList.get(j).getSum();
				sumThres += segList.get(j).getLength() * threshold;
				len += segList.get(j).getLength();
				if (sum > sumThres) {
					int leftNeighor = i == 0 ? segList.get(i).getFrom() : segList.get(i - 1).getFrom();
					int rightNeighor = j < segList.size() - 1 ? segList.get(j + 1).getTo() - 1 : segList.get(j).getTo();
					if (len > maxLength) {
						maxLength = len;
						left = segList.get(i).getFrom();
						right = segList.get(j).getTo();
						lhsSum = sum;
						value = sum / len;
						extendLonger(leftNeighor, rightNeighor);
					}
					else {
						if (rightNeighor - leftNeighor > maxLength) {
							tryExtendLonger(leftNeighor, rightNeighor, len, sum, segList.get(i).getFrom(), segList.get(j).getTo());
						}
					}
				}
			}
		}
		watch.stop();
		System.out.println("merge time => " + watch.getTime());
	}

	/**
	 * @Title: tryExtendLonger
	 * @Description: try to exend longer
	 * @param leftNeighor
	 * @param rightNeighor
	 * @param sum
	 * @param len
	 * @param to
	 * @param from
	 */
	private void tryExtendLonger(int leftNeighor, int rightNeighor, int len0, double sum0, int from, int to) {
		double sumThres = len0 * threshold;
		int leftMost = from - 1;
		double sum = sum0;
		// traverse left
		while (leftMost > leftNeighor) {
			sum += timeSeries[leftMost];
			leftMost--;
			sumThres += threshold;
			if (sum < sumThres) {
				leftMost++;
				break;
			}
		}
		if (leftMost == leftNeighor || leftMost < 0) {
			leftMost++;
		}
		// traverse right
		sum = sum0;
		sumThres = len0 * threshold;
		int rightMost = to;
		while (rightMost < rightNeighor) {
			sum += timeSeries[rightMost];
			rightMost++;
			sumThres += threshold;
			if (sum < sumThres) {
				rightMost--;
				break;
			}
		}
		// find longest between leftMost and rightMost
		// bruteforce
		
		int len;
		sum = 0;
		sumThres = 0;
		for(int i = leftMost ; i <= from ; i ++) {
			sum = timeSeries[i];
			sumThres = threshold;
			len = 1;
			for(int j = i + 1 ; j < to ; j ++) {
				sum += timeSeries[j];
			}
			sumThres += threshold * (to - i - 1);
			len += to - i - 1;
			for(int j = to ; j < rightMost ; j ++) {
				sum += timeSeries[j];
				sumThres += threshold;
				len ++;
				if (len > maxLength && sum >= sumThres) {
					maxLength = len;
					left = i;
					right = j + 1;
					value = sum / len;
				}
			}
		}
	}

	/**
	 * @Title: extendLonger
	 * @Description: extend longer
	 * @param start
	 * @param end
	 */
	private void extendLonger(int start, int end) {
		tryExtendLonger(start, end, maxLength, lhsSum, left, right);
	}

	/**
	 * @Title: main
	 * @Description: TODO
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		double[] ts = DataUtil.read(1000000);
		int thres = 80;
		// for(int i = 0 ; i < ts.length ; i ++) {
		// System.out.print(ts[i] + " ");
		// }
		// System.out.println();
		
		StopWatch stopWatch = new StopWatch();
		double avg;
//		stopWatch.start();
//		BruteForceLHSMiner miner2 = new BruteForceLHSMiner(ts, thres);
//		miner2.process();
//		stopWatch.stop();
//		System.out.println("miner2 = " + miner2);
//		System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
//
//		avg = LHSMiner.avg(ts, miner2.getLeft(), miner2.right);
//		System.out.println("avg = " + avg);
		
		System.out.println();
		stopWatch.reset();
		ScmlhsMiner miner = new ScmlhsMiner(ts, thres);
		stopWatch.start();
		miner.process();
		stopWatch.stop();

		if (miner.getMaxLength() > 0) {
			System.out.println("miner = " + miner);
			System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
			avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
			System.out.println("avg = " + avg);
		} else {
			System.out.println("no result ...");
		}

	}

}
