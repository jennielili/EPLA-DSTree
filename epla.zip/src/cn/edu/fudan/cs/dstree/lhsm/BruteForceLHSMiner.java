package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.lang.time.StopWatch;

/**
 * Created by wangyang on 2014/9/12.
 */
public class BruteForceLHSMiner extends LHSMiner {
    public BruteForceLHSMiner(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }

    public void process() {
        double sum = 0;
        double sumThreshold = 0;
        int len = 0;
        maxLength = 1;
        for (int i = 0; i < timeSeries.length; i++) {
            sum = timeSeries[i];
            sumThreshold = threshold;
            len = 1;

//            for (int j = i + maxLength; j < timeSeries.length; j++) {
            for (int j = i + 1; j < timeSeries.length; j++) {
                sum += timeSeries[j];
                sumThreshold += threshold;
                len++;
                if (len > maxLength && sum >= sumThreshold) {
                    maxLength = len;
                    left = i;
                    right = j + 1;
                    value = sum / len;
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
//        double[] ts = CpuUsageGenerator.gen(1000);
//        System.out.println("ts.length = " + ts.length);
//        double[] ts = CpuUsageGenerator.gen1m();
        double[] ts = DataUtil.read(1000);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        BruteForceLHSMiner miner = new BruteForceLHSMiner(ts, 80);
        miner.process();
        stopWatch.stop();
        System.out.println("miner = " + miner);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

        double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
        System.out.println("avg = " + avg);
    }
}
