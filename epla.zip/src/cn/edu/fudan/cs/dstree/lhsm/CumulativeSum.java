/**
* @Title: CumulativeSum.java
* @Description: TODO
* @author: Calvinyang
* @date: Sep 25, 2014 9:33:53 PM
* Copyright: Copyright (c) 2013
* @version: 1.0
*/
package cn.edu.fudan.cs.dstree.lhsm;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * @author: Calvinyang
 * @Description: TODO
 * @date: Sep 25, 2014 9:33:53 PM
 */
public class CumulativeSum {

	public void run(double[] ts) throws Exception {
		double sum = 0;
		BufferedWriter bw = new BufferedWriter(new FileWriter("cumulativeSum.dat"));
		for(int i = 0 ; i < ts.length ; i ++) {
			sum += ts[i];
			bw.write(sum + "");
			bw.newLine();
		}
		bw.close();
	}
	
	/**
	 * @Title: main
	 * @Description: TODO
	 * @param args
	 */
	public static void main(String[] args) {
		double[] ts = CpuUsageGenerator.gen(1000 * 100);
		try {
			new CumulativeSum().run(ts);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
