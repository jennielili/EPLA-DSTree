package cn.edu.fudan.cs.dstree.lhsm;

import cn.edu.fudan.cs.dstree.data.SeriesGenerator;

import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 11-6-21
 * Time: 下午7:36
 * To change this template use File | Settings | File Templates.
 */
public class CpuUsageGenerator implements SeriesGenerator {
    int length;

    double minStart;
    double maxStart;

    double minStep;
    double maxStep;

    double min;
    double max;

    long seed;

    Random random;

    public CpuUsageGenerator(int length, double minStart, double maxStart, double minStep, double maxStep, double min, double max) {
        this(length, minStart, maxStart, minStep, maxStep, min, max, new Random().nextLong());
    }

    public CpuUsageGenerator(int length, double minStart, double maxStart, double minStep, double maxStep, double min, double max, long seed) {
        this.length = length;
        this.minStart = minStart;
        this.maxStart = maxStart;
        this.minStep = minStep;
        this.maxStep = maxStep;
        this.min = min;
        this.max = max;
        this.seed = seed;
        random = new Random(seed);
    }

    private double random(double min, double max) {
        return min + random.nextDouble() * (max - min);
    }

    public double[] generate() {
        double[] timeSeries = new double[length];
        timeSeries[0] = random(minStart, maxStart);

        for (int i = 1; i < timeSeries.length; i++) {
            double sign = random.nextDouble() < 0.5 ? -1 : 1;
            double step = random.nextDouble() * random(minStep, maxStep);
            timeSeries[i] = timeSeries[i - 1] + sign * step;
            if (timeSeries[i] > max)
                timeSeries[i] = max;
            if (timeSeries[i] < min)
                timeSeries[i] = min;
        }
        return timeSeries;
    }

    public static void main(String[] args) {
        CpuUsageGenerator cpuUsageGenerator = new CpuUsageGenerator(1000, 0, 50, 1, 20, 0, 100, 0);
        for (int j = 0; j < 1; ++j) {
            double[] tempTs = cpuUsageGenerator.generate();
            for (int i = 0; i < tempTs.length; i++) {
                double tempT = tempTs[i];
                System.out.print(tempT + " ");
            }
            System.out.println();
        }
    }

    public static double[] gen1m() {
        CpuUsageGenerator cpuUsageGenerator = new CpuUsageGenerator(1000 * 1000, 0, 50, 1, 20, 0, 100, 0);

        double[] generate = cpuUsageGenerator.generate();
        return generate;
    }

    public static double[] gen(int length) {
        CpuUsageGenerator cpuUsageGenerator = new CpuUsageGenerator(length, 0, 50, 1, 20, 0, 100, 0);

        double[] generate = cpuUsageGenerator.generate();
        return generate;
    }

}
