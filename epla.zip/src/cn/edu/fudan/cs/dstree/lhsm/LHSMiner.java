package cn.edu.fudan.cs.dstree.lhsm;

/**
 * Created by wangyang on 2014/9/12.
 * Longest High Sequence Miner
 */
public abstract class LHSMiner {
    double[] timeSeries;
    double threshold;
    int maxLength;
    int maxLengthUpperBound;
    int left;
    int right;
    double value;
    double errorBound = 0;
    int checkPoint = 10000;

    public int getCheckPoint() {
        return checkPoint;
    }

    public void setCheckPoint(int checkPoint) {
        this.checkPoint = checkPoint;
    }

    public double getErrorBound() {
        return errorBound;
    }

    public void setErrorBound(double errorBound) {
        this.errorBound = errorBound;
    }

    public abstract void process();

    /**
     *
     * @param timeSeries
     * @param from
     * @param to exclusive
     * @return
     */
    public static double avg(double[] timeSeries, int from, int to)
    {
        double sum = 0;
        for (int i = from; i < to; i++) {
            sum += timeSeries[i];
        }

        return sum / (to - from);
    }

    public double avg(int from, int to)
    {
        return sum(from,to) / (to - from);
    }

    public double sum(int from, int to)
    {
        double ret = 0;
        for (int i = from; i < to; i++) {
            ret += timeSeries[i];
        }
        return ret;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "{" +
                "maxLength=" + maxLength +
                ", maxLengthUpperBound=" + maxLengthUpperBound +
                ", left=" + left +
                ", right=" + right +
                ", value=" + value +
                '}';
    }

    public double getValue() {
        return value;
    }

    public int getMaxLength() {
        return maxLength;
    }

    public int getLeft() {
        return left;
    }

    public int getRight() {
        return right;
    }

    protected LHSMiner(double[] timeSeries, double threshold) {
        this.timeSeries = timeSeries;
        this.threshold = threshold;
    }

    public static double gain(double[]  timeSeries, int from, int to, double threshold)
    {
        double ret = 0;
        for (int i = from; i < to; i++) {
            ret += (timeSeries[i] - threshold);
        }
        return ret;
    }

    public static double cumulativeGain(double[]  timeSeries, int to, double threshold)
    {
        double ret = 0;
        for (int i = 0; i < to; i++) {
            ret += (timeSeries[i] - threshold);
        }
        return ret;
    }

    public static double cumulativeSum(double[]  timeSeries, int to)
    {
        double ret = 0;
        for (int i = 0; i < to; i++) {
            ret += timeSeries[i];
        }
        return ret;
    }
}
