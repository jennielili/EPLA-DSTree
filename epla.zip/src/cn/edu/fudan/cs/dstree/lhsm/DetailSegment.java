/**
 * @Title: DetailSegment.java
 * @Description: TODO
 * @author: Calvinyang
 * @date: Sep 12, 2014 9:55:49 PM
 * Copyright: Copyright (c) 2013
 * @version: 1.0
 */
package cn.edu.fudan.cs.dstree.lhsm;

import java.util.Comparator;
/**
 * @author: Calvinyang
 * @Description: TODO
 * @date: Sep 12, 2014 9:55:49 PM
 */
public class DetailSegment extends Segment {
	public enum SegmentType {
		NONE, LT_SEGMENT, GE_SEGMENT, COMBINE_SEGMENT
	}

    public boolean tag = false;

    public boolean isGeSegment()
    {
        return getType() == SegmentType.GE_SEGMENT;
    }

	SegmentType type;
	double sum;
	double gain;
	double cumulativeGain;
	double std;
    double cumulativeSum;

    public double getCumulativeGain() {
        return cumulativeGain;
    }

    public void setCumulativeGain(double cumulativeGain) {
        this.cumulativeGain = cumulativeGain;
    }

    int leftBound;
    int rightBound;
    public int getLengthUpperBound()
    {
        return rightBound - leftBound;
    }

	/**
	 * @return the gain
	 */
	public double getGain() {
		return gain;
	}
	
	/**
	 * @param gain the gain to set
	 */
	public void setGain(double gain) {
		this.gain = gain;
	}

    public int getLeftBound() {
        return leftBound;
    }

    public void setLeftBound(int leftBound) {
        this.leftBound = leftBound;
    }

    public int getRightBound() {
        return rightBound;
    }

    public void setRightBound(int rightBound) {
        this.rightBound = rightBound;
    }

    public double getCumulativeSum() {
        return cumulativeSum;
    }

    public void setCumulativeSum(double cumulativeSum) {
        this.cumulativeSum = cumulativeSum;
    }

    @Override
    public String toString() {
        return "DetailSegment{" +
                "type=" + type +
                ", from=" + from +
                ", to=" + to +
                ", leftBound=" + leftBound +
                ", rightBound=" + rightBound +
                ", lengthUpperBound=" + getLengthUpperBound() +
                ", len=" + getLength() +
                ", avg=" + avg +
                ", std=" + std +
                ", sum=" + sum +
                ", gain=" + gain +
                ", fromCumulativeGain=" + cumulativeGain +
                ", cumulativeSum=" + cumulativeSum +
                '}';
    }

    /**
	 * @return the type
	 */
	public SegmentType getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(SegmentType type) {
		this.type = type;
	}

	/**
	 * @return the sum
	 */
	public double getSum() {
		return sum;
	}

	/**
	 * @param sum
	 *            the sum to set
	 */
	public void setSum(double sum) {
		this.sum = sum;
	}

	/**
	 * @return the std
	 */
	public double getStd() {
		return std;
	}

	/**
	 * @param std
	 *            the std to set
	 */
	public void setStd(double std) {
		this.std = std;
	}

    public static class CumulativeSumComparator implements Comparator<DetailSegment>
    {
        @Override
        public int compare(DetailSegment o1, DetailSegment o2) {
            return Double.compare(o1.cumulativeSum, o2.cumulativeSum);
        }
    }
}
