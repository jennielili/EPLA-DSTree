package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.lang.time.StopWatch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 2014/9/12.
 * segment merge Longest high sequence miner
 */
public class SMLHSMiner extends LHSMiner{
    //left, right, avg
    @Override
    public void process() {
        findAllSegmentsFront2Back();
        System.out.println("fbList.size() = " + fbList.size());
        for (int i = 0; i < fbList.size(); i++) {
            Segment segment = fbList.get(i);
        //    System.out.println("segment = " + segment);
        }

        findAllSegmentsBack2Front();
        System.out.println("bfList.size() = " + bfList.size());
        for (int i = 0; i < bfList.size(); i++) {
            Segment segment = bfList.get(i);
        //    System.out.println("segment = " + segment);
        }

        Collections.sort(fbList);
        System.out.println("fbList.get(0) = " + fbList.get(0));
        System.out.println("fbList.get(fbList.Size()-1) = " + fbList.get(fbList.size()-1));

        Collections.sort(bfList);
        System.out.println("bfList.get(0) = " + bfList.get(0));
        System.out.println("bfList.get(bfList.Size()-1) = " + bfList.get(bfList.size()-1));

        //do merge
    }

    List<Segment> fbList = new ArrayList<Segment>();
    List<Segment> bfList = new ArrayList<Segment>();

    public void findAllSegmentsFront2Back()
    {
        for (int i = 0; i < timeSeries.length; i++) {
            if (timeSeries[i] >= threshold) //trigger
            {
                double sum = timeSeries[i];
                double sumThreshold = threshold;
                maxLength = 0;

                int from = i;
                int to = i + 1;
                for (int j = i + 1; j < timeSeries.length; j++) {
                    sum += timeSeries[j];
                    sumThreshold += threshold;

                    if (sum < sumThreshold) //less and output
                    {
                        to = j;
                        break;
                    }
                }
                if (to > from) {
                    Segment segment = new Segment(from, to);
                    fbList.add(segment);
                }
                i = to;
            }
        }
    }

    public void findAllSegmentsBack2Front()
    {
        for (int i = timeSeries.length - 1; i >= 0; i--) {
            if (timeSeries[i] >= threshold) //trigger
            {
                double sum = timeSeries[i];
                double sumThreshold = threshold;
                maxLength = 0;

                int from = i;
                int to = i - 1;
                for (int j = i - 1; j >= 0; j--) {
                    sum += timeSeries[j];
                    sumThreshold += threshold;

                    if (sum < sumThreshold) //less and output
                    {
                        to = j;
                        break;
                    }
                }
                if (from > to) {
                    Segment segment = new Segment(from, to);
                    bfList.add(segment);
                }
                i = to;
            }
        }
    }

    public SMLHSMiner(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }


    public static void main(String[] args) {
        double[] ts = CpuUsageGenerator.gen(1000 * 1000);
//        double[] ts = CpuUsageGenerator.gen1m();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        SMLHSMiner miner = new SMLHSMiner(ts, 80);
        miner.process();
        stopWatch.stop();
        System.out.println("miner = " + miner);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

        double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
        System.out.println("avg = " + avg);
    }
}
