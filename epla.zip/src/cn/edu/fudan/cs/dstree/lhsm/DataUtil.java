/**
* @Title: DataReader.java
* @Description: TODO
* @author: Calvinyang
* @date: Sep 12, 2014 9:37:58 PM
* Copyright: Copyright (c) 2013
* @version: 1.0
*/
package cn.edu.fudan.cs.dstree.lhsm;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @author: Calvinyang
 * @Description: Byte time series data reader
 * @date: Sep 12, 2014 9:37:58 PM
 */
public class DataUtil {
	static final String defaultFile = "data/input/cpu_usage_data_1m";
	
	/**
	 * 
	* @Title: write
	* @Description: generate cpu usage ts (length = 1m) and save as byte file
	* @param length
	* @throws Exception
	 */
	public static void write(int length) throws Exception {
		write(defaultFile, 1000 * 1000);
	}
 	
	/**
	 * 
	* @Title: write
	* @Description: generate cpu usage ts and save as byte file
	* @param fileName
	* @param count
	 */
	public static void write(String fileName, int length) throws Exception {
		double[] ts = CpuUsageGenerator.gen(length);
		DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileName));
		for(int i = 0 ; i < length ; i ++) {
			dos.writeDouble(ts[i]);
		}
		dos.close();
	}
	
	/**
	 * 
	* @Title: read
	* @Description: read ts data from file
	* @param length
	* @return
	* @throws Exception
	 */
	public static double[] read(int length) throws Exception {
		return read(defaultFile, length);
	}
	
	/**
	 * 
	* @Title: read
	* @Description: read ts data from file
	* @param fileName
	* @param length
	* @return
	* @throws Exception
	 */
	public static double[] read(String fileName, int length) throws Exception {
		DataInputStream dis = new DataInputStream(new FileInputStream(fileName));
		double[] ts = new double[length];
		for(int i = 0 ; i < length ; i ++) {
			ts[i] = dis.readDouble();
		}
		dis.close();
		return ts;
	}
	
}
