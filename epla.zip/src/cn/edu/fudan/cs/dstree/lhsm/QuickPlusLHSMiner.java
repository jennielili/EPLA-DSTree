package cn.edu.fudan.cs.dstree.lhsm;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.StopWatch;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

/**
 * Created by wrq on 12/9/14.
 * quick find the longest high sequence quickly
 */
public class QuickPlusLHSMiner extends LHSMiner {
    List<DetailSegment> segmentList = new ArrayList<DetailSegment>();
    List<DetailSegment> aboveList = new LinkedList<DetailSegment>();

    @Override
    public void process() {
        //get the avg segments
        StopWatch buildListWatch = new StopWatch();
        buildListWatch.start();
        buildList();
        buildListWatch.stop();
        System.out.println("buildListWatch.getTime() = " + buildListWatch.getTime());
        System.out.println("segmentList = " + segmentList.size());

        Collections.sort(aboveList, new Comparator<DetailSegment>() {
            @Override
            public int compare(DetailSegment o1, DetailSegment o2) {
                return Double.compare(o1.cumulativeGain, o2.cumulativeGain) * -1;
            }
        });
        System.out.println("aboveList[first] = " + aboveList.get(0));
        System.out.println("aboveList[last] = " + aboveList.get(aboveList.size() - 1));

        System.out.println("aboveList.size() = " + aboveList.size());

        List<DetailSegment> candidateList = new ArrayList<DetailSegment>(aboveList);
        //do merge
        for (int i = 0; i < segmentList.size(); i++) {
            DetailSegment currentSegment = segmentList.get(i);

            //merge the above segments only
            if (currentSegment.isGeSegment()) {
//                if (currentSegment.getFrom() >= 54192)
//                {
//                    System.out.println("currentSegment = " + currentSegment);
//                }
                //find the sum > length * threshold and the right most
                //the above list is sort by cumulative gain descending-ly
                aboveList.remove(currentSegment);

//                if (currentSegment.getFrom() > 420556) {
////                    System.out.println("currentSegment = " + currentSegment);
//                }

                //using the cumulative gain to speed up the merge process
                double v = -currentSegment.getCumulativeGain() + (currentSegment.getSum() - currentSegment.getLength() * threshold);
                for (int j = 0; j < aboveList.size(); j++) {
                    DetailSegment mergeSegment = aboveList.get(j);
                    double mergeGain = mergeSegment.getCumulativeGain() + v;
                    if (mergeGain >= 0) {
                        //a validate merge
                        if (mergeSegment.getRightBound() - currentSegment.getLeftBound() <= maxLength) {
                            continue;
                        }
                        //a validate merge
                        DetailSegment candidateSegment = new DetailSegment();  //new segment is cost very much
                        candidateSegment.setFrom(currentSegment.getFrom());
                        candidateSegment.setTo(mergeSegment.getTo());
                        candidateSegment.setSum(mergeGain + threshold * candidateSegment.getLength());
                        candidateSegment.setLeftBound(currentSegment.getLeftBound());
                        candidateSegment.setRightBound(mergeSegment.getRightBound());
                        candidateList.add(candidateSegment);

                        //update the current maxLength
                        if (candidateSegment.getLength() > maxLength) {
                            left = candidateSegment.getFrom();
                            right = candidateSegment.getTo();
                            maxLength = candidateSegment.getLength();
                        }
                    } else {
//                        System.out.println("mergeSegment = " + mergeSegment);
                        break;
                    }
                }

            }
        }

        System.out.println("candidateList.size() = " + candidateList.size());

        ArrayList<DetailSegment> tempList = new ArrayList<DetailSegment>();
        for (int i = candidateList.size() - 1; i >= 0; i--) {
            DetailSegment candidateSegment = candidateList.get(i);
            if (candidateSegment.getLengthUpperBound() > maxLength) {
                tempList.add(candidateSegment);
            }
        }
        candidateList = tempList;
        //sorted by lengthUpperBound
        Collections.sort(candidateList, new Comparator<DetailSegment>() {
            @Override
            public int compare(DetailSegment o1, DetailSegment o2) {
                return -1 * Integer.compare(o1.getLengthUpperBound(), o2.getLengthUpperBound());
            }
        });

//        //init maxLength and remove unnecessary candidate segments
//        DetailSegment maxUpperLengthSegment = candidateList.get(0);
//        left = maxUpperLengthSegment.getFrom();
//        right = maxUpperLengthSegment.getTo();
//        maxLength = right - left;


//        for (int i = 0; i < candidateList.size(); i++) {
//            DetailSegment candidateSegment = candidateList.get(i);
//            if (candidateSegment.getLength() > maxLength)
//            {
//                left = candidateSegment.getFrom();
//                right = candidateSegment.getTo();
//                maxLength = right - left;
//            }
//        }

//        for (int i = candidateList.size() -1; i >=0; i--) {
//            DetailSegment candidateSegment = candidateList.get(i);
//            if (candidateSegment.getLengthUpperBound() <= maxLength)
//            {
//                candidateList.remove(i);
//            }
//        }
//        System.out.println("after pruning, candidateList.size() = " + candidateList.size());

//        StringBuffer sb = new StringBuffer();
//        for (int i = 0; i < candidateList.size(); i++) {
//            DetailSegment detailSegment = candidateList.get(i);
//            sb.append(detailSegment.toString()).append("\n");
//        }
//        try {
//            IOUtils.write(sb.toString(), new FileOutputStream("2.txt"));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//        System.out.println("candidateList.get(0) = " + candidateList.get(0));
        //
        int segmentTryCount = 0;
        for (int i = 0; i < candidateList.size(); i++) {
            DetailSegment candidateSegment = candidateList.get(i);

            //early stop
            if (candidateSegment.getLengthUpperBound() <= maxLength)
                break;

            segmentTryCount++;

            //find the maxLength for candidateSegment
            int searchLeft = candidateSegment.getFrom();
            double leftGain = candidateSegment.getSum() - threshold * candidateSegment.getLength();
            int searchLeftStart = candidateSegment.getFrom() > 0 ? candidateSegment.getFrom() - 1 : candidateSegment.getFrom();  //deal with the first ge segment
            for (int l = searchLeftStart; l > candidateSegment.getLeftBound(); l--) {
                leftGain += (timeSeries[l] - threshold);
                if (leftGain < 0) //break;
                {
                    searchLeft = l + 1;
                    leftGain -= (timeSeries[l] - threshold); //add back for use later
                    break;
                }
            }
//            System.out.println("leftGain = " + leftGain);
//            System.out.println("searchLeft = " + searchLeft);

            for (int l = searchLeft; l <= candidateSegment.getFrom(); l++) {
                double rightGain = leftGain;
//                System.out.println("l = " + l);
//                System.out.println("leftGain = " + leftGain);
//                System.out.println("rightGain = " + rightGain);
//
//                System.out.println("(timeSeries[l] - threshold = " + (timeSeries[l] - threshold));
//                if (l == 420556)
//                {
//                    System.out.println("================= l = " + l);
//                    System.out.println("leftGain = " + leftGain);
//                }

                for (int r = candidateSegment.getTo(); r < candidateSegment.getRightBound(); r++) {
                    rightGain += (timeSeries[r] - threshold);
                    if (rightGain < 0) {
                        if ((r - l) > maxLength) {
                            left = l;
                            right = r;
                            maxLength = r - l;
                        }
                        break;
                    }
                }
                leftGain -= (timeSeries[l] - threshold); //add back for use later
            }
        }
        System.out.println("segmentTryCount = " + segmentTryCount);

        //print the segment cover information
//        System.out.println("print the maxLength cover segment include the head and tail LeSegment");
//        for (int i = 0; i < segmentList.size(); i++) {
//            DetailSegment detailSegment = segmentList.get(i);
//            if (detailSegment.getTo() >= this.left  && detailSegment.getFrom() <= this.right)
//            {
//                System.out.println("detailSegment = " + detailSegment);
//            }
//        }
    }

    double cumulativeSum = 0;

    private void buildList() {
        DetailSegment.SegmentType lastType = timeSeries[0] < threshold ? DetailSegment.SegmentType.LT_SEGMENT : DetailSegment.SegmentType.GE_SEGMENT;
        DetailSegment.SegmentType currentType = DetailSegment.SegmentType.NONE;
        int from = 0;
        double sum = timeSeries[0];// xi + ... + xj
        cumulativeSum = timeSeries[0];

        // traverse to classification
        for (int i = 1; i < timeSeries.length; i++) {
            currentType = timeSeries[i] < threshold ? DetailSegment.SegmentType.LT_SEGMENT : DetailSegment.SegmentType.GE_SEGMENT;
            if (currentType != lastType) { // split a segment of another type
                // end a segment and add to list
                DetailSegment segment = new DetailSegment();
                segment.setFrom(from);
                segment.setTo(i);
//                segment.setAvg(sum / segment.getLength());
                segment.setSum(sum);
                segment.setCumulativeSum(cumulativeSum);
                segment.setGain(sum - threshold * segment.getLength());
                segment.setCumulativeGain(cumulativeSum - threshold * i);
//                segment.setStd(Math.sqrt(sum2 / segment.getLength() - segment.getAvg() * segment.getAvg()));
                segment.setType(lastType);
                segmentList.add(segment);

                //do merge
                if (segment.isGeSegment()) {
                    while (segmentList.size() >= 3) //loop until can't merge
                    {
                        DetailSegment lastGeSegment = segmentList.get(segmentList.size() - 1);
                        DetailSegment lastLeSegment = segmentList.get(segmentList.size() - 2);
                        DetailSegment last2GeSegment = segmentList.get(segmentList.size() - 3);
                        if ((lastGeSegment.getGain() + lastLeSegment.getGain() > 0) && (lastLeSegment.getGain() + last2GeSegment.getGain() > 0)) {
                            //remove last 2 segments
                            segmentList.remove(segmentList.size() - 1);
                            segmentList.remove(segmentList.size() - 1);
                            //do merge, update the last se segment
                            last2GeSegment.setTo(lastGeSegment.getTo());
                            last2GeSegment.setSum(lastGeSegment.getSum() + lastLeSegment.getSum() + last2GeSegment.getSum());
                            last2GeSegment.setCumulativeSum(lastGeSegment.getCumulativeSum());
                            last2GeSegment.setGain(lastGeSegment.getGain() + lastLeSegment.getGain() + last2GeSegment.getGain());
                            last2GeSegment.setCumulativeGain(lastGeSegment.getCumulativeGain());
                        } else {
                            break;
                        }
                    }
                }

//                //search more merge
//                DetailSegment lastGeSegment = segmentList.get(segmentList.size() - 1);
//                if (lastGeSegment.isGeSegment())
//                {
//                    if (segmentList.size() > 2)
//                    {
//                        DetailSegment lastLeSegment = segmentList.get(segmentList.size() - 2);
//                        if (lastGeSegment.getGain() + lastLeSegment.getGain() > 0)
//                        {
//                            //search more
//                            for (int j = 0; j < segmentList.size() -3; j++) {
//                                DetailSegment firstGeSegment = segmentList.get(j);
//                                DetailSegment firstLeSegment = segmentList.get(j+1);
//                                if (firstGeSegment.isGeSegment() && (firstGeSegment.getGain() + firstLeSegment.getGain() >0))
//                                {
//                                    //get the middle segmnet gain
//                                    double middleGain = lastLeSegment.getCumulativeGain() - lastLeSegment.getGain() - firstLeSegment.getCumulativeGain();
//                                    if ((middleGain + firstLeSegment.getGain() >0) && (middleGain + lastLeSegment.getGain() >0))
//                                    {
//                                        //do merge
//                                        System.out.println("middleGain = " + middleGain);
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }


                // begin a new segment
                from = i;
                sum = 0;
//                sum2 = 0;
            }
            sum += timeSeries[i];
            cumulativeSum += timeSeries[i];
//            sum2 += timeSeries[i] * timeSeries[i];
            lastType = currentType;
        }
        // tail process
        DetailSegment segment = new DetailSegment();
        segment.setFrom(from);
        segment.setTo(timeSeries.length);
//        segment.setAvg(sum / segment.getLength());
        segment.setSum(sum);
        segment.setCumulativeSum(cumulativeSum);
        segment.setCumulativeGain(cumulativeSum - threshold * timeSeries.length); //
//        segment.setStd(Math.sqrt(sum2 / segment.getLength() - segment.getAvg() * segment.getAvg()));
        segment.setType(currentType);
        segmentList.add(segment);
//        if (segment.getType() == DetailSegment.SegmentType.GE_SEGMENT)
//            aboveList.add(segment);


//        //deal with a1 b1 a2 b2 a3  merge if a1>b1 & a3 > b2
//        for (int i = 0; i < segmentList.size() - 5; i++) {
//            DetailSegment a1Segment = segmentList.get(i);
//            if (a1Segment.isGeSegment())
//            {
//                DetailSegment b1Segment = segmentList.get(i+1);
//                DetailSegment a2Segment = segmentList.get(i+2);
//                DetailSegment b2Segment = segmentList.get(i+3);
//                DetailSegment a3Segment = segmentList.get(i+4);
//
//                double middleGain = b1Segment.getGain() + a2Segment.getGain() + b2Segment.getGain();
//
//                if (a1Segment.getGain() > -1 * middleGain && a3Segment.getGain() > -1 * middleGain )
//                {
//                    System.out.println("middleGain = " + middleGain);
//                }
//            }
//        }

        //deal with leftBound and rightBound and add to aboveList
        for (int i = 0; i < segmentList.size(); i++) {
            DetailSegment detailSegment = segmentList.get(i);
            if (detailSegment.isGeSegment()) {
                aboveList.add(detailSegment);
                detailSegment.setLeftBound(i > 0 ? segmentList.get(i - 1).getFrom() : 0);
                detailSegment.setRightBound(i < segmentList.size() - 1 ? segmentList.get(i + 1).getTo() : timeSeries.length);
            }
        }
    }

    public QuickPlusLHSMiner(double[] timeSeries, double threshold) {
        super(timeSeries, threshold);
    }

    public static void main(String[] args) {
        double[] ts = CpuUsageGenerator.gen(1000 * 1000);
//        double[] ts = CpuUsageGenerator.gen1m();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        LHSMiner miner = new QuickPlusLHSMiner(ts, 80);
        miner.process();
        stopWatch.stop();
        System.out.println("miner = " + miner);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());

        double avg = LHSMiner.avg(ts, miner.getLeft(), miner.right);
        System.out.println("avg = " + avg);
    }
}
