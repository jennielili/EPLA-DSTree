package cn.edu.fudan.cs.dstree.dynamicsplit;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 11-7-7
 * Time: 下午7:40
 * To change this template use File | Settings | File Templates.
 */
public class Pla3NodeSegmentSketchUpdater implements INodeSegmentSketchUpdater {
    ISeriesSegmentSketcher seriesSegmentSketcher;

    public NodeSegmentSketch updateSketch(NodeSegmentSketch nodeSegmentSketch, double[] series, int fromIdx, int toIdx) {
        SeriesSegmentSketch seriesSegmentSketch = seriesSegmentSketcher.doSketch(series, fromIdx, toIdx);

        if (nodeSegmentSketch.indicators == null) //not initial
        {
            nodeSegmentSketch.indicators = new float[6];                //float
            //for left
            nodeSegmentSketch.indicators[0] = Float.MAX_VALUE * -1; //for max intercept       max left
            nodeSegmentSketch.indicators[1] = Float.MAX_VALUE; //for min intercept            min left
            //for right top and right bottom
            nodeSegmentSketch.indicators[2] = Float.MAX_VALUE * -1; //for right top          max right
            nodeSegmentSketch.indicators[3] = Float.MAX_VALUE; //for right bottom            min right
            //for sse
            nodeSegmentSketch.indicators[4] = Float.MAX_VALUE * -1; //for max sse
            nodeSegmentSketch.indicators[5] = Float.MAX_VALUE; //for min sse
        }

        nodeSegmentSketch.indicators[0] = Math.max(nodeSegmentSketch.indicators[0], seriesSegmentSketch.indicators[1]);
        nodeSegmentSketch.indicators[1] = Math.min(nodeSegmentSketch.indicators[1], seriesSegmentSketch.indicators[1]);
        //for right top and right bottom
        int len = toIdx - fromIdx;
        nodeSegmentSketch.indicators[2] = Math.max(nodeSegmentSketch.indicators[2], seriesSegmentSketch.indicators[0] * (len - 1) + seriesSegmentSketch.indicators[1]); //a * (len-1) + b
        nodeSegmentSketch.indicators[3] = Math.min(nodeSegmentSketch.indicators[3], seriesSegmentSketch.indicators[0] * (len - 1) + seriesSegmentSketch.indicators[1]);
        nodeSegmentSketch.indicators[4] = Math.max(nodeSegmentSketch.indicators[4], seriesSegmentSketch.indicators[2]);
        nodeSegmentSketch.indicators[5] = Math.min(nodeSegmentSketch.indicators[5], seriesSegmentSketch.indicators[2]);
        return nodeSegmentSketch;
    }

    public Pla3NodeSegmentSketchUpdater(ISeriesSegmentSketcher seriesSegmentSketcher) {
        this.seriesSegmentSketcher = seriesSegmentSketcher;
    }
}
