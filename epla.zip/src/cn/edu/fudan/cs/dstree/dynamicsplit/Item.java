package cn.edu.fudan.cs.dstree.dynamicsplit;
import java.util.*;
public class Item implements Comparable<Item>{

	/**
	 * @param args
	 */
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	double value;
	public int compareTo(Item item2)
	{
		if(this.value>item2.value)
		   return 1;
		else
			return -1;
	}
	public Item(int id,double value)
	{
		this.id=id;
		this.value=value;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Item> aa=new ArrayList();
		Item bb=new Item(1,0.2);
		Item cc=new Item(2,0.1);
		aa.add(bb);
		aa.add(cc);
		Collections.sort(aa);
		System.out.println(aa.get(0).getId());

	}

}
