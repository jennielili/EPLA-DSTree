package cn.edu.fudan.cs.dstree.dynamicsplit;

/**
 * Created by IntelliJ IDEA.
 * User: ZhuShengqi
 * Date: 11-7-19
 * Time: 下午6:29
 * To change this template use File | Settings | File Templates.
 */
public class PqItem {
    Node node;
    double dist;
}
