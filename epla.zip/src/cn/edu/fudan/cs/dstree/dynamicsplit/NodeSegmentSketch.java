package cn.edu.fudan.cs.dstree.dynamicsplit;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 11-7-7
 * Time: 下午7:36
 * To change this template use File | Settings | File Templates.
 */
public class NodeSegmentSketch extends Sketch {
}
