package cn.edu.fudan.cs.dstree.dynamicsplit;

import cn.edu.fudan.cs.dstree.util.CalcUtil;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 11-7-7
 * Time: 下午7:28
 * To change this template use File | Settings | File Templates.
 */
public class MeanSeriesSegmentSketcher implements ISeriesSegmentSketcher {
    public SeriesSegmentSketch doSketch(double[] series, int fromIdx, int toIdx) {
        SeriesSegmentSketch seriesSegmentSketch = null;
//        seriesSegmentSketch = SketchBufferManager.getInstance().getSeriesSegmentSketch(series, fromIdx, toIdx);

        if (seriesSegmentSketch == null) {
            seriesSegmentSketch = new SeriesSegmentSketch();
            seriesSegmentSketch.indicators = new float[1];            //todo
            seriesSegmentSketch.indicators[0] = (float) CalcUtil.avg(series, fromIdx, toIdx);
          /*  try{
            	seriesSegmentSketch.indicators[0] = (float) CalcUtil.avg(series, fromIdx, toIdx);
            }
            catch(Exception e)
            {
            	System.out.println("*****************   series    is   "+series[25]+"    fromIdx   is  "+fromIdx+"   toIdx    is   "+toIdx);
            
            } 
            */
        }//if
        return seriesSegmentSketch;
    }
}
