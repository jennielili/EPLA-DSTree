package cn.edu.fudan.cs.dstree.dynamicsplit;

import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.QuickSelect;
import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 14-2-16.
 */
public class KDSTreeNode implements Serializable {
 //   private static final Log log = LogFactory.getLog(KDSTreeNode.class);

    KDSTreeNode left;
    public static int staticId=0;
    public int id=staticId++;
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
    public int level = 0;
    public KDSTreeNode getParent() {
		return parent;
	}

	public void setParent(KDSTreeNode parent) {
		this.parent = parent;
	}

	KDSTreeNode right;
    KDSTreeNode parent;

    transient double[][] dataSet;
    public int[] indexes;
    public double[][] getDataSet() {
		return dataSet;
	}

	public void setDataSet(double[][] dataSet) {
		this.dataSet = dataSet;
	}

	int[] parentDims;
    int[] availableDims; //for current node list all availableDims
    int[] currentDims;  //dims after split, may have new segment
    int dimCount;
    int indicesPerDim;
    int threshold;
    public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	int start;
    int end;

    int splitDim = -1; //not init
    public int getSplitDim() {
		return splitDim;
	}

	public void setSplitDim(int splitDim) {
		this.splitDim = splitDim;
	}

	public double getSplitValue() {
		return splitValue;
	}

	public void setSplitValue(double splitValue) {
		this.splitValue = splitValue;
	}

	int splitIdx = -1; //not init
    double splitValue;

    public double getDimWeight(int dim) {
        double ret = 1;
        while (dim > 0) {
            ret /= 2;
            dim = (dim - 1) / 2;
        }

        return ret;
    }
    public boolean isTerminal() {
    	//System.out.println("  in    is Terminal           "+this.getSplitDim()+" start "+this.getStart());
        return (left == null && right == null);
    }
    public KDSTreeNode approximateSearch(double[] queryTs) {
//      System.out.println("this.getFileName() = " + this.getFileName());
      if (isTerminal())
          return this;
      else //internal node
      {
    	  //we need compute the synopsis according to the spliting dim and value
          if (queryTs[this.splitDim]<=this.splitValue)
          {
        	//  System.out.println("  left  query  "+queryTs[this.splitDim]+"  "+" splitvalue   "+this.splitValue+"   split dim  "+this.splitDim);
              return left.approximateSearch(queryTs);
          }
          else
          {
        	//  System.out.println("  right  query  "+queryTs[this.splitDim]+"  "+" splitvalue   "+this.splitValue+"   split dim  "+this.splitDim);
              return right.approximateSearch(queryTs);
          }
      }
  }
    public KDSTreeNode(double[][] dataSet, int dimCount, int indicesPerDim, int threshold, int start, int end) {
        this(dataSet, dimCount, indicesPerDim, threshold, new int[]{0}, start, end);
    }


    public KDSTreeNode(double[][] dataSet, int dimCount, int indicesPerDim, int threshold,int[] indexes) {
        this(dataSet, dimCount, indicesPerDim, threshold, new int[]{0}, 0, dataSet.length,indexes);
    }
    public KDSTreeNode(double[][] dataSet, int dimCount, int indicesPerDim, int threshold) {
        this(dataSet, dimCount, indicesPerDim, threshold, new int[]{0}, 0, dataSet.length);
    }

    public KDSTreeNode(double[][] dataSet, int dimCount, int indicesPerDim, int threshold, int[] parentDims, int start, int end) {
        this.dataSet = dataSet;
        this.dimCount = dimCount;
        this.indicesPerDim = indicesPerDim;
        this.threshold = threshold;
        this.parentDims = parentDims;
        this.start = start;
        this.end = end;
        this.parent = null;
        this.availableDims = calcAvailableDims(parentDims);
        for (int parentDim : parentDims) {
//            log.info("parentDims=" + parentDims);
        	System.out.println("parentDims=" + parentDims+"      node   id   "+this.id);
        }

       for (int availableDim : availableDims) {
//            log.info("availableDim=" + availableDim);
    	   System.out.println("availableDim=" + availableDim);
       }

        //check
        if (dataSet[0].length != (dimCount * indicesPerDim))
        {
        	//System.out.println("  length   is   "+dataSet[0].length+"   dimCount   is   "+dimCount+"   indicesPerDim  is   "+indicesPerDim);
            throw new RuntimeException("dim count error!");
        }
    }
    public KDSTreeNode(double[][] dataSet, int dimCount, int indicesPerDim, int threshold, int[] parentDims, int start, int end,int[] indexes) {
        this.dataSet = dataSet;
        this.dimCount = dimCount;
        this.indicesPerDim = indicesPerDim;
        this.threshold = threshold;
        this.parentDims = parentDims;
        this.start = start;
        this.end = end;
        this.parent = null;
        this.availableDims = calcAvailableDims(parentDims);
        this.indexes=indexes;
        for (int parentDim : parentDims) {
//            log.info("parentDims=" + parentDims);
        //	System.out.println("parentDims=" + parentDims);
        }

       for (int availableDim : availableDims) {
//            log.info("availableDim=" + availableDim);
    //	   System.out.println("availableDim=" + availableDim);
       }

        //check
        if (dataSet[0].length != (dimCount * indicesPerDim))
        {
        	//System.out.println("  length   is   "+dataSet[0].length+"   dimCount   is   "+dimCount+"   indicesPerDim  is   "+indicesPerDim);
            throw new RuntimeException("dim count error!");
        }
    }

    private int[] calcAvailableDims(int[] parentDims) {
        List<Integer> list = new ArrayList<Integer>();
        for (int parentDim : parentDims) {
            list.add(parentDim);
        }

        for (int parentDim : parentDims) {
            int[] dims = calcChildDims(parentDim);
            for (int childDim : dims) {
                if (childDim < dimCount)
                    list.add(childDim);
            }
        }

        int[] ret = new int[list.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = list.get(i);
        }

        return ret;
    }

    public void buildTree() {
        //stop when threshold not reached
        if ((end - start) <= threshold)
            return;

        //choose the best split idx by deviation
        chooseBestSplitIdx();
        this.level+=1;
        //find the median and partition the dataset for splitidx
        //  System.out.println("  start   is   "+start+"   end    is    "+end);
        //sort according to splitIdx
        splitValue = QuickSelect.quickSelectMedian(dataSet, start, end - 1, splitIdx,indexes);
     //   System.out.println("splitDim = " + splitDim);
       // System.out.println("splitIdx = " + splitIdx);
       // System.out.println("splitValue = " + splitValue);
        //get the true median index for 2 child
        int medianIdx = (start + end) / 2;
        for (int i = medianIdx; i < end; i++) {
            if (dataSet[i][splitIdx] <= splitValue) {
                medianIdx = i;
            } else
                break;
        }
      //  System.out.println("                 medianIdx             is       "+medianIdx);
        //check currentDims
      //  System.out.println("  parentDims   "+parentDims.length);
//        for(int ii=0;ii<parentDims.length;ii++)
//        {
//        	System.out.println("  the dimension  for parent  "+ii+"   is   "+parentDims);
//        }
        if (Arrays.binarySearch(parentDims,splitDim) >=0)  //no horizontal split
        {
            currentDims = parentDims;
        }
        else  //new horizontal split
        {
            currentDims = new int[parentDims.length + 1];
            int pos = 0;
            for (int i = 0; i < parentDims.length; i++) {
                int parentDim = parentDims[i];
                if (!isParentDim(parentDim,splitDim))
                {
                    currentDims[pos++] = parentDim;
                }
                else
                {
                    int[] dims = calcChildDims(parentDim);
                    currentDims[pos++] = dims[0];
                    currentDims[pos++] = dims[1];
                    //ADD BY LQH 
                    break;
                }
            }
        }

        left = new KDSTreeNode(dataSet, dimCount, indicesPerDim, threshold, currentDims, start, medianIdx,indexes);
        left.parent = this;
        left.buildTree();

        right = new KDSTreeNode(dataSet, dimCount, indicesPerDim, threshold, currentDims, medianIdx, end,indexes);
        right.parent = this;
        right.buildTree();
    }

    public void chooseBestSplitIdx() {
        //get child dimensions
        //eg:0 [1 2] [3 4 5 6] [7 8 9 10 11 12 13 14]
        //input 0 return 1 2
        //input 1 return 3 4
        //input 2 return 5 6

        //for 2 indices per dim
        // 0    1   2   3   4  5    6
        //[01] [23 45] [67 89 1011 1213]

        int[] idxes = new int[availableDims.length * indicesPerDim];
        for (int i = 0; i < availableDims.length; i++) {
            for (int j = 0; j < indicesPerDim; j++) {
                idxes[i * indicesPerDim + j] = availableDims[i] * indicesPerDim + j;
            }
        }

        double[] devs = CalcUtil.deviation(dataSet, idxes, start, end);
     //   System.out.println("**********");
       // System.out.println("start = " + start);
       // System.out.println("end = " + end);
       // System.out.println("getSize() = " + getSize());
        for (int i = 0; i < devs.length; i++) {
            double dev = devs[i];
            //log.info("dev = " + dev + " idx:" + idxes[i] + " dim:" + calcDimFromIdx(idxes[i]));
        }

        //add trade off to newDevs
        double[] newDevs = new double[devs.length];
        System.arraycopy(devs, 0, newDevs, 0, newDevs.length);
        for (int i = 0; i < newDevs.length; i++) {
            newDevs[i] *= getDimWeight(calcDimFromIdx(idxes[i]));  //adjust weight
        }
        int idx = CalcUtil.indexOfMax(newDevs);
     //  System.out.println("  the  length  of idxes   is  "+idxes.length+"  idx   is  "+idx);
        splitIdx = idxes[idx];
        splitDim = calcDimFromIdx(splitIdx);
    }

    public int calcDimFromIdx(int idx) {
        return idx / indicesPerDim;
    }

    public int[] calcChildDims(int dim) {
        return new int[]{dim * 2 + 1, dim * 2 + 2};
    }

    public boolean isParentDim(int pDim, int cDim)
    {
        return (cDim -1)/2 == pDim;
    }

    public int getSize() {
        return (end - start);
    }

    public void printTree(StringBuilder stringBuilder) {
        stringBuilder.append("\n").append("start = " + start);
        stringBuilder.append("\n").append("end = " + end);
        stringBuilder.append("\n").append("getSize() = " + getSize());
        stringBuilder.append("\n").append("splitDim = " + splitDim);
        stringBuilder.append("\n").append("splitIdx = " + splitIdx);
        stringBuilder.append("\n").append("splitValue = " + splitValue);
        stringBuilder.append("\n").append("---------------------------");
        if (left != null) {
            stringBuilder.append("\n").append("left");
            left.printTree(stringBuilder);
            stringBuilder.append("\n").append("right");
            right.printTree(stringBuilder);
        }
        
    }

    public static KDSTreeNode loadFromFile(String fileName) throws IOException, ClassNotFoundException {
//        FileInputStream fis = new FileInputStream(fileName);
//        ObjectInputStream ios = new ObjectInputStream(fis);
//        return  (Node) ios.readObject();
        FSTObjectInput in = new FSTObjectInput(new FileInputStream(fileName));
        KDSTreeNode node;
        try {
            node = (KDSTreeNode) in.readObject(KDSTreeNode.class);
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        }
        in.close();
        return node;
    }

    public void saveToFile(String fileName) throws IOException {
        FSTObjectOutput out = new FSTObjectOutput(new FileOutputStream(fileName));
        out.writeObject(this);
        out.close(); // required !
    }

    public void saveToStream(OutputStream os) throws IOException {
        FSTObjectOutput out = new FSTObjectOutput(os);
        out.writeObject(this);
        out.close(); // required !
    }
}
