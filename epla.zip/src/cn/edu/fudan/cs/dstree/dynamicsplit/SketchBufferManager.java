package cn.edu.fudan.cs.dstree.dynamicsplit;

import java.util.*;

/**
 * Created by wangyang on 13-12-29.
 */
public class SketchBufferManager {
    HashMap<double[], SeriesSketch> buffer = new HashMap<double[], SeriesSketch>();

    double[] seriesLastVisited = null;
    SeriesSketch seriesSketchLastVisited = null;

    SeriesSketch getSeriesSketchEx(double[] series) {
        if (series != seriesLastVisited) {
            seriesLastVisited = series;
            seriesSketchLastVisited = buffer.get(series);
        }
        return seriesSketchLastVisited;
//        return buffer.get(series);
    }

    public SeriesSegmentSketch getSeriesSegmentSketch(double[] series, int fromIdx, int toIdx) {
        SeriesSketch seriesSketch = getSeriesSketchEx(series);
        if (seriesSketch != null)
            return seriesSketch.getSeriesSegmentSketch(fromIdx, toIdx);
        else
            return null;
    }

    static SketchBufferManager manager;

    public static SketchBufferManager getInstance() {
        if (manager == null) {
            manager = new SketchBufferManager();
            System.out.println("manager = " + manager);
        }
        return manager;
    }

    public void addSeriesSegmentSketch(double[] series, int fromIdx, int toIdx, SeriesSegmentSketch sketch) {
        SeriesSketch seriesSketch = getSeriesSketchEx(series);
        if (seriesSketch == null) {
            seriesSketch = new SeriesSketch();
            seriesSketchLastVisited = seriesSketch;
            buffer.put(series, seriesSketch);
        }

        seriesSketch.addSeriesSegmentSketch(fromIdx, toIdx, sketch);
    }

    public void removeSketches(double[] series) {
        //call when the series is remove from memory
        buffer.remove(series);
    }
}

class SeriesSketch {
    final int INIT_CAPACITY = 10;
    //    List<Integer> fromIds = new ArrayList<Integer>(INIT_CAPACITY);
//    List<Integer> toIds = new ArrayList<Integer>(INIT_CAPACITY);
//    List<SeriesSegmentSketch> sketches = new ArrayList<SeriesSegmentSketch>(INIT_CAPACITY);
//    HashMap<Integer,SeriesSegmentSketch> map = new HashMap<Integer, SeriesSegmentSketch>();
    List<SeriesSketchItem> list = new ArrayList<SeriesSketchItem>(INIT_CAPACITY);

    public SeriesSegmentSketch getSeriesSegmentSketch(int fromIdx, int toIdx) {
        SeriesSegmentSketch ret = null;
        int pos = indexOf(fromIdx, toIdx);
        if (pos >= 0) {
            ret = list.get(pos).sketch;
        }

//        for (int i = 0; i < fromIds.size(); i++) {
//            int fromId = fromIds.get(i);
//            int toId = toIds.get(i);
//            if ((fromId == fromIdx) && (toId == toIdx)) {
//                return sketches.get(i);
//            }
//        }
//        map.get(fromIdx * 1000 + toIdx);
        //binary search
        return ret;
    }

    public void addSeriesSegmentSketch(int fromIdx, int toIdx, SeriesSegmentSketch sketch) {
//        fromIds.add(fromIdx);
//        toIds.add(toIdx);
//        sketches.add(sketch);
//        map.put(fromIdx * 1000 + toIdx,sketch);
        SeriesSketchItem seriesSketchItem = new SeriesSketchItem(fromIdx, toIdx, sketch);
        //find the position
        int pos = -1 * indexOf(fromIdx, toIdx) - 1;
        if (pos + 1 < list.size()) {
            if (list.get(pos).fromIdx == fromIdx && list.get(pos + 1).fromIdx == fromIdx) {
                //don't insert and delete
                list.set(pos + 1, list.get(pos));
                list.set(pos, seriesSketchItem);
                return;
            }
        }

        list.add(pos, seriesSketchItem);
    }

    public int indexOf(int fromIdx, int toIdx) {
        //using binary search
        int low = 0;
        int high = list.size() - 1;

        while (low <= high) {
            int mid = (low + high) >>> 1;

            SeriesSketchItem midVal = list.get(mid);
            int cmp = compare(midVal.fromIdx, midVal.toIdx, fromIdx, toIdx);

            if (cmp < 0)
                low = mid + 1;
            else if (cmp > 0)
                high = mid - 1;
            else
                return mid; // key found
        }
        return -(low + 1);  // key not found
    }

    int compare(int fromIdx1, int toIdx1, int fromIdx2, int toIdx2) {
        if (fromIdx1 != fromIdx2)
            return fromIdx1 - fromIdx2;
        else
            return toIdx1 - toIdx2;
    }
}

class SeriesSketchItem {
    int fromIdx;
    int toIdx;
    SeriesSegmentSketch sketch;

    SeriesSketchItem(int fromIdx, int toIdx, SeriesSegmentSketch sketch) {
        this.fromIdx = fromIdx;
        this.toIdx = toIdx;
        this.sketch = sketch;
    }

    @Override
    public String toString() {
        return fromIdx + "," + toIdx;
    }
}
