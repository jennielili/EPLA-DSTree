package cn.edu.fudan.cs.dstree.dynamicsplit;

import cn.edu.fudan.cs.dstree.util.CalcUtil;
import org.apache.commons.lang.math.IntRange;
import org.apache.hadoop.io.IntWritable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 14-2-6.
 */
public class NodeUtil {
    public static List<Node> getLeafNodesByFirstOrder(Node root) {
        List<Node> ret = new ArrayList<Node>();
        List<Node> list = new ArrayList<Node>();
        list.add(root);

        //stack
        while (list.size() > 0) {
            //pop
            Node node = list.remove(list.size() - 1);

            if (node.isTerminal()) {
                //for terminal node
                ret.add(node);
            } else {
                //for internal node
                //push their children if it is internal node
                list.add(node.right);
                list.add(node.left);
            }
        }
        return ret;
    }
    public static List<KDSTreeNode> getLeafKDSNodesByFirstOrder(KDSTreeNode root) {
        List<KDSTreeNode> ret = new ArrayList<KDSTreeNode>();
        List<KDSTreeNode> list = new ArrayList<KDSTreeNode>();
        list.add(root);

        //stack
        while (list.size() > 0) {
            //pop
        	KDSTreeNode node = list.remove(list.size() - 1);

            if (node.left==null && node.right==null) {
                //for terminal node
                ret.add(node);
            } else {
                //for internal node
                //push their children if it is internal node
                list.add(node.right);
                list.add(node.left);
            }
        }
        return ret;
    }
    public static List<Node> getNodesByFirstOrder(Node root) {
        List<Node> ret = new ArrayList<Node>();
        List<Node> list = new ArrayList<Node>();
        list.add(root);

        //stack
        while (list.size() > 0) {
            //pop
            Node node = list.remove(list.size() - 1);
            ret.add(node);  //add root first
            if (!node.isTerminal()) {
                //for internal node
                //push their children if it is internal node
                list.add(node.right);
                list.add(node.left);
            }
        }
        return ret;
    }

    public static void clearAllStatistics(Node root) {
        INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = root.nodeSegmentSplitPolicies;
        IRange range = root.range;
        INodeSegmentSketchUpdater nodeSegmentSketchUpdater = root.nodeSegmentSketchUpdater;
        ISeriesSegmentSketcher seriesSegmentSketcher = root.seriesSegmentSketcher;

        List<Node> list = new ArrayList<Node>();
        list.add(root);

        //stack
        while (list.size() > 0) {
            //pop
            Node node = list.remove(list.size() - 1);
            //clear info
            //set size to 0
            node.setSize(0);
            //clear indicators
            //init hsPoints and hsNodeSegmentSketches
            node.initSegments(node.nodePoints);

            //set other info
            node.nodeSegmentSplitPolicies = nodeSegmentSplitPolicies;
            node.range = range;
            node.nodeSegmentSketchUpdater = nodeSegmentSketchUpdater;
            node.seriesSegmentSketcher = seriesSegmentSketcher;

            if (!node.isTerminal()) {
                //for internal node
                //push their children if it is internal node
                list.add(node.right);
                list.add(node.left);
            }
        }
    }

    //a kdstree with: tslength,
    public static void initDSTreeWithKDSTree(KDSTreeNode kdsTreeNode, Node dsTreeNode)
    {
        //it's assume the same tsLength
        if (kdsTreeNode != null)
        {
            int splitDim = kdsTreeNode.splitDim;
            if (splitDim <0) //no more split
                return;
            int splitIdx = kdsTreeNode.splitIdx;
            int indicesPerDim = kdsTreeNode.indicesPerDim;
            dsTreeNode.setOtherId(kdsTreeNode.getId());
            INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = dsTreeNode.getNodeSegmentSplitPolicies();
            int splitPolicyIdx = splitIdx % indicesPerDim;

            //init dsTreeNode's splitPolicy
            SplitPolicy splitPolicy = new SplitPolicy();
            splitPolicy.setSeriesSegmentSketcher(dsTreeNode.getSeriesSegmentSketcher());

            INodeSegmentSplitPolicy nodeSegmentSplitPolicy = nodeSegmentSplitPolicies[splitPolicyIdx];
            splitPolicy.setNodeSegmentSplitPolicy(nodeSegmentSplitPolicy);
            int tsLength = dsTreeNode.nodePoints[dsTreeNode.nodePoints.length -1];
            int level = dim2Level(kdsTreeNode.dimCount);
            List<IntRange> intRanges = CalcUtil.generateSplitRanges(tsLength, level);

            splitPolicy.splitFrom = (short) intRanges.get(splitDim).getMinimumInteger();
            splitPolicy.splitTo = (short) intRanges.get(splitDim).getMaximumInteger();
            splitPolicy.indicatorIdx = nodeSegmentSplitPolicy.getIndicatorSplitIdx();
            splitPolicy.indicatorSplitValue = kdsTreeNode.splitValue;

            dsTreeNode.splitPolicy = splitPolicy;
            //deal with child
            Node left = new Node(dsTreeNode);
            //get currentDims
            int[] currentDims = kdsTreeNode.currentDims;
            short[] childNodePoint = new short[currentDims.length];
            for (int i = 0; i < childNodePoint.length; i++) {
                childNodePoint[i] = (short) intRanges.get(currentDims[i]).getMaximumInteger();
            }
            left.initSegments(childNodePoint);
            left.isLeft = true;
            left.setOtherId(kdsTreeNode.left.getId());
            dsTreeNode.left = left;
            initDSTreeWithKDSTree(kdsTreeNode.left,left);

            Node right = new Node(dsTreeNode);
            right.initSegments(childNodePoint);
            right.setOtherId(kdsTreeNode.right.getId());
            right.isLeft = false;
            dsTreeNode.right = right;
            initDSTreeWithKDSTree(kdsTreeNode.right, right);
        }
    }

    public static int dim2Level(int dimCount)
    {
        int ret = 0;
        while (dimCount >= 1)
        {
            dimCount = dimCount / 2;
            ret ++;
        }
        return ret;
    }

    public static void main(String[] args) {
        int i = dim2Level(16);
        System.out.println("i = " + i);
    }
}
