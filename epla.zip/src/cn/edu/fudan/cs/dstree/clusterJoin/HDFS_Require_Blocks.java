package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.hadoop.hdfs.server.namenode.FSDirectory;
public class HDFS_Require_Blocks {

	/**
	 * @param args
	 */
	public FSDirectory dir;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
