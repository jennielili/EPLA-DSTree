package cn.edu.fudan.cs.dstree.clusterJoin;
import java.io.*;
//import com.hadoop.compression.*;
//
//import com.hadoop.compression.lzo.*;
//import com.hadoop.mapreduce.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.hadoop.SeriesInputFormat;


/**
 * 
 * 
 * @author Qli
 * 
 */
public class LSHJoin_Preprocess_Driver extends Configured implements Tool {
	
    public static void main(String[] args) throws Exception {
	int res = 0;
	res = ToolRunner.run(new Configuration(), new LSHJoin_Preprocess_Driver(),
		    args);
		
    }

    @Override
    public int run(String[] arg0) throws Exception {
	Configuration conf = getConf();
	
	Job job = new Job(conf, "LSH-Join-Process");
	job.setJarByClass(LSHJoin_Preprocess_Driver.class);
	job.setInputFormatClass(SeriesInputFormat.class);
	job.setMapperClass(LSHJoin_Preprocess_Mapper.class);
	job.setReducerClass(LSHJoin_Preprocess_Reducer.class);
    job.setMapOutputKeyClass(IntWritable.class);
	job.setMapOutputValueClass(IntWritable.class);
	job.setOutputKeyClass(IntWritable.class);
	job.setOutputValueClass(IntWritable.class);
    job.setNumReduceTasks(1);
	long time5=System.currentTimeMillis();
	//String workdir = "test/";
	FileInputFormat.addInputPath(job, new Path("cluster2"));
	FileSystem fs = FileSystem.get(conf);
	//fs.cp(new Path("outk"),new Path("outk"+iteraion));
	fs.delete(new Path("outk"), true);
	FileOutputFormat.setOutputPath(job, new Path("outk"));
	int res = job.waitForCompletion(true) ? 0 : 1;
	

	long time4=System.currentTimeMillis();
	long inter3=time5-time4;
    System.out.println("******************  **************  all  time      "+inter3);
		return res;
    }
    

}
