package cn.edu.fudan.cs.dstree.clusterJoin;
import java.util.*;



/**
 * 
 * @author Administrator
 * This is a tool class to provide some methods used frequently
 * The methods in it are static,so you can use them by class Tool
 */
public class Tool {
	public static int dimension=1000;
	
	public static  double getHashValue(double[] a , double b, double w, double[] vv )
   	{
   		double temp=0.0;
   		double temp1=0.0;
   		double temp2=0.0;
   		double hash=0.0;
   		for(int ii=0;ii<a.length;ii++)
   		{
   		//	temp=temp+(a.point.get(ii)*vv.point.get(ii))/(Math.sqrt(piabs))*(Math.sqrt(piabs2));
   			temp=temp+a[ii]*vv[ii];
   		}
    //	System.out.println("  temp   is   "+temp);
   		hash=Math.floor((temp+b)/w);
   	    return hash;	
   	}

}
