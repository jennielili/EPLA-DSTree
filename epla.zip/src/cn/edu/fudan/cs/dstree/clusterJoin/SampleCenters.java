package cn.edu.fudan.cs.dstree.clusterJoin;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
public class SampleCenters {

	/**
	 * @param args
	 */
	private int tsLength=256;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		SampleCenters  sam=new SampleCenters();
	//	sam.sampleCenters("c:\\data\\ucibinary");
		sam.sampleCenters("/");

	}
	public List sampleCenters(String path) throws IOException
	{
		int count=0;
		List<double[]> centers=new ArrayList();
		long fileSize = new File(path).length();
		count = (int) (fileSize / tsLength / 8);
		//count=size;
		System.out.println("  count    is    " + count);
		FileInputStream fis = new FileInputStream(path);
		FileOutputStream fos=new FileOutputStream("c:\\data\\centers");
		BufferedInputStream bis = new BufferedInputStream(fis);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		DataInputStream dis = new DataInputStream(bis);
		DataOutputStream dos = new DataOutputStream(bos);
		
		long count2 = 0;
		// count=10000;
		Random  random=new Random();
		for (int i = 0; i < count; i++) {
			int ran=random.nextInt(2000);
			count2++;
			double[] tss = new double[tsLength];
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();

			}
			if(ran<1)
			{
				centers.add(tss);
				for (int j = 0; j < tsLength; j++) {
					dos.writeDouble(tss[j]);
					//System.out.println("  double   is   "+tss[j]);

				}
			}
			if(count2%10000==0)
		         System.out.println("  count2     is   "+count2);
		}
		System.out.println(" the number of  centers"+ centers.size());
		dis.close();
		bis.close();
		fis.close();
		dos.close();
		bos.close();
		fos.close();
		return centers;
		
	}
	

}
