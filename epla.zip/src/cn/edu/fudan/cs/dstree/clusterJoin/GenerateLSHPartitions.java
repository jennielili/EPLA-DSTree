package cn.edu.fudan.cs.dstree.clusterJoin;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class GenerateLSHPartitions {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader aa=new BufferedReader(new FileReader("c:\\data\\part-r-00000"));
		//	BufferedReader bb=new BufferedReader(new FileReader("d:\\result_1000_new
		int rep=0;
		int count=0;
		int[][] range=new int[1000][3];
		int count2=0;
		int pos=0;
		boolean first=true;
		int sum2=0;
		int threshold=2000;
		
		while(aa.ready())
		{
			String newLine=aa.readLine();
			String[] vas=newLine.split("\t");
			Integer hash=Integer.parseInt(vas[0]);
			Integer number=Integer.parseInt(vas[1]);
			sum2+=number;
			if(first)
			{
				range[pos][0]=hash;
				first=false;
			}
		//	System.out.println("  count2   is   "+count);
			if(count2<threshold &&count2>threshold-number)
			{
				range[pos][1]=hash;
				range[pos][2]=count2+number;
				System.out.println(" **********  pos   "+pos+"  start hash  "+range[pos][0]+"  end hash "+range[pos][1]+"   number   "+range[pos][2]);
		    	count2=0;
				pos++;
				first=true;
				continue;
			//	count2+=number2;
				
			}
			count2+=number;
			System.out.println("     hash   is   "+hash+"  number  is  "+number+"  pos  is "+pos+" count2   "+count2);
		
		}
		int sum=0;
		for(int i=0;i<pos;i++)
		{
			sum+=range[i][2];
			System.out.println("  pos   "+i+"  start hash  "+range[i][0]+"  end hash "+range[i][1]+"   number   "+range[i][2]);
		}
		System.out.println("******************    sum    is    ************************  "+sum+"   sum2        "+sum2);
		int t=8;
		int replications=0;
		for(int i=0;i<pos;i++)
		{
			int cc=0;
			for(int j=i+1;j<pos;j++)
			{
					int diff=Math.abs(range[j][0]-range[i][1]);
					if(diff<=t)
					{
						System.out.println("  i "+i+"    j   "+j+"  diff   "+diff);
						cc++;
					}
				
			}	
			System.out.println("  ***********  "+i+"   replications    "+cc);
		}
       System.out.println("  replications   is     "+replications); 
	}

}
