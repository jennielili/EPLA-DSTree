package cn.edu.fudan.cs.dstree.clusterJoin;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.IntWritable;
public class PointBinary3 implements Writable{

	/**
	 * @param args
	 */
	int id;
	int from;
	int hash1;
	int hash2;
	int hash3;
	int hash4;
	public int dimension=1000;
	double[] pointValues=new double[dimension];
	public void readFields(DataInput in) throws IOException {
		id=in.readInt();
		from=in.readInt();
		hash1=in.readInt();
		hash2=in.readInt();
		hash3=in.readInt();
		hash4=in.readInt();
		for(int ii=0;ii<dimension;ii++)
		{
			pointValues[ii]=in.readDouble();
		}
		
	}
	public void write(DataOutput out) throws IOException {
		out.writeInt(id);
		out.writeInt(from);
		out.writeInt(hash1);
		out.writeInt(hash2);
		out.writeInt(hash3);
		out.writeInt(hash4);
		for(int ii=0;ii<dimension;ii++)
		{
			out.writeDouble(pointValues[ii]);
		}
		
	}
	public void print()
	{
		System.out.println(" the  partition     is  "+from);
		for(int ii=0;ii<dimension;ii++)
		{
			System.out.print("  "+pointValues[ii]);
		}
	//	System.out.println("   weight   is   "+weight);
	}
	public PointBinary3(int id,int from,double[] listd)
	{
		this.id=id;
		this.from=from;
		if(listd!=null)
			for(int ii=0;ii<listd.length;ii++)
			{
				this.pointValues[ii]=listd[ii];
			}
	}
	public PointBinary3()
	{
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
