package cn.edu.fudan.cs.dstree.clusterJoin;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadCenter {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String fileName="c:\\data\\centers";
		int tsLength=1000;
		FileInputStream fis = new FileInputStream(fileName);
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		long fileSize = new File(fileName).length();
		int count = (int) (fileSize / tsLength / 8);
		System.out.println("  count   is   "+count);
		long count2 = 0;
		for (int i = 0; i < count; i++) {
			double[] tss = new double[tsLength];
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();
				System.out.print("   "+tss[j]);

			}
			System.out.println();
	    }
	}
}
