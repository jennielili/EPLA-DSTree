package cn.edu.fudan.cs.dstree.clusterJoin;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.io.*;
public class SampleCenters_search {

	/**
	 * @param args
	 */
	private int tsLength=1000;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		SampleCenters_search  sam=new SampleCenters_search();
		sam.sampleCenters("c:\\data\\ucibinary");

	}
	public List sampleCenters(String path) throws IOException
	{
		int count=0;
		List<double[]> centers=new ArrayList();
		long fileSize = new File(path).length();
		count = (int) (fileSize / tsLength / 8);
		//count=size;
		System.out.println("  count    is    " + count);
		FileInputStream fis = new FileInputStream(path);
		BufferedWriter aa=new BufferedWriter(new FileWriter("c:\\data\\search.txt"));
		BufferedInputStream bis = new BufferedInputStream(fis);

		DataInputStream dis = new DataInputStream(bis);
		
		
		long count2 = 0;
		// count=10000;
		Random  random=new Random();
		for (int i = 0; i < 100000; i++) {
			int ran=random.nextInt(200);
			String value=count2+"\t";
			count2++;
			
			double[] tss = new double[tsLength];
			//int id=dis.readInt();
			//System.out.println("  id   is  "+id);
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble()+0.01;

			}
			if(ran<1)
			{
				centers.add(tss);
				for (int j = 0; j < tsLength-1; j++) {
					value+=tss[j]+" ";
				//	System.out.println("  double   is   "+tss[j]+ " value  is  "+value);

				}
				value+=tss[tsLength-1];
				aa.write(value);
				aa.newLine();
				System.out.println("value  is  "+value);
			}
			if(count2%10000==0)
		         System.out.println("  count2     is   "+count2);
		}
		System.out.println(" the number of  centers"+ centers.size());
		dis.close();
		bis.close();
		fis.close();
		aa.close();
		return centers;
		
	}
	

}
