package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Reducer.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import cn.edu.fudan.cs.dstree.allpair.AllPairUtils;
import cn.edu.fudan.cs.dstree.allpair.AutoExpandIntArray;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import java.io.IOException;
import java.util.*;

/**
 * Reduecer for KDS Search
 * 
 * @author Qli
 */
public class LSHJoin_Preprocess_Reducer extends
	Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
	 Node root;
	 private int tsLength=1000;
     private double threshold=0.5;
     private int allsize=0;
    
	protected void reduce(
			IntWritable key,
	    java.lang.Iterable<IntWritable> vals,  org.apache.hadoop.mapreduce.Reducer<IntWritable, IntWritable, IntWritable, IntWritable>.Context context)
    throws java.io.IOException, InterruptedException {
		int count=0;

		for (IntWritable val : vals) {
			count+=val.get();
          
        }
		
    	 context.write(key, new IntWritable(count));
	}
}
