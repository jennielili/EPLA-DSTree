package cn.edu.fudan.cs.dstree.clusterJoin;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class Read_AddId_windows {

	/**
	 * @param args
	 */
	private int tsLength = 1000;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Read_AddId_windows sam = new Read_AddId_windows();
		sam.addId("c:\\data\\ucibinary_id");
		

	}

	public void addId(String path) throws IOException {
		int count = 0;
		List<double[]> centers = new ArrayList();
		long fileSize = new File(path).length();
		int ttt=8*tsLength+8;
		count = (int) (fileSize / (8*tsLength+8));
		System.out.println(" ******************   "+ttt+"   filesize  "+fileSize);
		// count=size;
		System.out.println("  count    is    " + count);
		FileInputStream fis = new FileInputStream(path);
		
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		DataInputStream dis = new DataInputStream(bis);
	

		int count2 = 0;
		Random random = new Random();
		for (int i = 0; i < count; i++) {
			count2++;
			int size=dis.readInt();
			//int size=tsLength;
			double[] tss = new double[size];
			for (int j = 0; j < size; j++) {
				tss[j] = dis.readDouble();

			}
		    int from=dis.readInt();
			int id=dis.readInt();
           
		//	if (count2 % 10000 == 0)
			//	System.out.println("  from     is   " + from+"   id   is  "+id+" ");
		}
		dis.close();
		bis.close();
		fis.close();
	
		

	}

}
