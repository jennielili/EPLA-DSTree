package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.commons.lang.math.IntRange;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Mapper.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable2;
import java.util.*;
import java.io.IOException;
import java.math.*;

/**
 * Mapper for ClusterJoin
 * 
 * @author  Qli
 * 
 */
public class Cluster_Mapper extends Mapper<LongWritable, DoublesWritable, IntWritable, DoublesWritable> {

	 Node root;
	 private int tsLength=1000;
     private int threshold;
     private int centerNumber=1320;
     private double t=5.0;
     private List<double[]> centers=new ArrayList();
     HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	@Override
    protected void setup(Context context) throws IOException, InterruptedException {
     //  super.setup(context);
        //read centers
        Configuration conf = context.getConfiguration();
        FileSystem fs = FileSystem.get(conf);
    //   Path path = new Path("hdfs://218.193.132.34:9000/user/hadoop/center/centers");
       Path path = new Path("hdfs://10.141.211.156:9000/user/hadoop/center/centers");
        tsLength=1000;
        centerNumber=302;
        t=0.5;
        if (!fs.exists(path)) {
            throw new IOException("route file not exists!");
        }
        FSDataInputStream fsDataInputStream = fs.open(path);
        FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
        
        for(int ii=0;ii<centerNumber;ii++)
        {
        	double[] center=new double[tsLength];
        	for(int jj=0;jj<tsLength;jj++)
        		center[jj]=in.readDouble();
        	centers.add(center);
        }
        in.close();
    }
	
	@Override
    protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
        double[] point=value.getDoubles();
       // point=CalcUtil.z_Normalize(point);
        double min=Double.MAX_VALUE;
        double[] dis=new double[centerNumber];
        int index=-1;
      
        for(int ii=0;ii<centerNumber;ii++)
        {
        	dis[ii]=DistUtil.euclideanDist(point, centers.get(ii));
        	//System.out.println("  double   is   "+dis[ii]);
        	if(dis[ii]<min)
        	{
        		min=dis[ii];
        		index=ii;
        	}
        }
       
        context.write(new IntWritable(index), value);
      //  System.out.println("    index    is   "+index+"   min     is    "+min);
     
     //   System.out.println("   id    "+value.getId()+"   copy numbers  "+k);
    }

   
}
