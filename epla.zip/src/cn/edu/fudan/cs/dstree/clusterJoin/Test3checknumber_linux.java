package cn.edu.fudan.cs.dstree.clusterJoin;
import java.io.*;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import java.util.HashMap;
import java.util.*;
public class Test3checknumber_linux {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		HashMap<Integer,Double> hm=new HashMap();
		int all=0;
		for(int ii=0;ii<6;ii++)
		{
			BufferedReader aa=new BufferedReader(new FileReader("c:\\data\\outk92\\part-r-0000"+ii));
			//	BufferedReader bb=new BufferedReader(new FileReader("d:\\result_1000_new
			int rep=0;
			int count=0;
			while(aa.ready())
			{
				String newLine=aa.readLine();
				String[] vas=newLine.split("\t");
				Integer id=Integer.parseInt(vas[0]);
				Double value=Double.parseDouble(vas[1]);
				Double old=hm.get(id);
				if(old!=null)
				{
					if(value<=old)
						hm.put(id, value);
				}
				else
					hm.put(id, value);
				//System.out.println("      id   is   "+id+"  value   is   "+value);
			
			}
	   
	  }//for
	  Iterator it=hm.keySet().iterator();
	  while(it.hasNext())
	  {
		  Integer ii=(Integer)it.next();
		  System.out.println("  id   is  "+ii+" ********* value   is  "+hm.get(ii));
	  }
     
  }

}
