package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Reducer.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import cn.edu.fudan.cs.dstree.allpair.AllPairUtils;
import cn.edu.fudan.cs.dstree.allpair.AutoExpandIntArray;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import java.io.IOException;
import java.util.*;

/**
 * Reduecer for KDS Search
 * 
 * @author Qli
 */
public class ClusterJoin_Reducer extends
	Reducer<IntWritable, DoublesWritable, IntWritable, Text> {
	 Node root;
	 private int tsLength=256;
     private double threshold=0.01;
     private int allsize=0;
    
     @Override
     protected void setup(Context context) throws IOException, InterruptedException {
      //  super.setup(context);
    	 threshold=0.01;
    	 tsLength=256;
    	 allsize=0;
     }
    
	protected void reduce(
    		IntWritable key,
	    java.lang.Iterable<DoublesWritable> vals,  org.apache.hadoop.mapreduce.Reducer<IntWritable, DoublesWritable, IntWritable, Text>.Context context)
    throws java.io.IOException, InterruptedException {
		int count=0;
		List<DoublesWritable> values=new ArrayList();
		List<DoublesWritable> values2=new ArrayList();
		AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
		for (DoublesWritable val : vals) {
			count++;
		//	System.out.println("  id   is  "+val.getId()+"   from   is   "+val.getFrom());
           double[] temp=val.getDoubles().clone();
           int id=val.getId();
           DoublesWritable  dd=new DoublesWritable(val.getFrom(),id,temp);
           if(val.getFrom()==0)
        	   values.add(dd);
           else
        	   values2.add(dd);
         //  context.write(new IntWritable(val.getId()), new DoubleWritable(min));
        }
		int[] idxArray_left=new int[values.size()];
		int[] idxArray_right=new int[values2.size()];
	//	System.out.println("  partition  "+key.get()+"   home size   "+values.size()+"  outer size "+values2.size());
		double[][]  timeseries=new double[values.size()][tsLength];
		double[][]  timeseries2=new double[values2.size()][tsLength];
		double[][]  reducedTimeSeries=new double[values.size()][tsLength];
		double[][]  reducedTimeSeries2=new double[values2.size()][tsLength];
		for(int ii=0;ii<values.size();ii++)
		{
			idxArray_left[ii]=values.get(ii).getId();
			timeseries[ii]=values.get(ii).getDoubles();
		//	System.out.println("  id   "+idxArray_left[ii]+"  time series 0"+timeseries[ii][0]);
		}
		for(int ii=0;ii<values2.size();ii++)
		{
			idxArray_right[ii]=values2.get(ii).getId();
			timeseries2[ii]=values2.get(ii).getDoubles();
		}
		int[] segments;
		segments = AllPairUtils.calcPoints(tsLength, 8);
	    for (int i = 0; i < timeseries.length; i++) {
	            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeseries[i], segments);
	    }	
	    for (int i = 0; i < timeseries2.length; i++) {
            reducedTimeSeries2[i] = AllPairUtils.avgBySegments(timeseries2[i], segments);
      }	
		AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeseries, reducedTimeSeries, 8, threshold, allPairs);
	    AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeseries,timeseries2,reducedTimeSeries,reducedTimeSeries2, idxArray_left, idxArray_right, threshold, 8, allPairs);
	  //  System.out.println(" ***** partition  "+key.get()+"     home   "+values.size()+"  other   "+values2.size()+"  allpairs  size "+allPairs.size());
	    String tt=""+allPairs.size()+"\t"+values.size();
	    allsize+=allPairs.size();
	    for(int ii=0;ii<allPairs.size();ii++)
	   {
	      context.write(key, new Text(allPairs.getArray()[0]+"\t"+allPairs.getArray()[1]));
	   }
	   context.write(key, new Text(tt));
	   
	}
}
