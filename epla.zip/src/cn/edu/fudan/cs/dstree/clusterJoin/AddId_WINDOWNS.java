package cn.edu.fudan.cs.dstree.clusterJoin;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class AddId_WINDOWNS {

	/**
	 * @param args
	 */
	private int tsLength = 1000;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		AddId_WINDOWNS sam = new AddId_WINDOWNS();
		sam.addId("c:\\data\\ucibinary");
		

	}

	public void addId(String path) throws IOException {
		int count = 0;
		List<double[]> centers = new ArrayList();
		long fileSize = new File(path).length();
		count = (int) (fileSize / tsLength / 8);
		// count=size;
		System.out.println("  count    is    " + count);
		FileInputStream fis = new FileInputStream(path);
		FileOutputStream fos = new FileOutputStream(
				"c:\\data\\ucibinary_id");
		BufferedInputStream bis = new BufferedInputStream(fis);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		DataInputStream dis = new DataInputStream(bis);
		DataOutputStream dos = new DataOutputStream(bos);

		int count2 = 0;
		Random random = new Random();
		for (int i = 0; i < 1000; i++) {
			count2++;
			double[] tss = new double[tsLength];
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();

			}
            int from=0;
            dos.writeInt(tsLength);
			for (int j = 0; j < tsLength; j++) {
				dos.writeDouble(tss[j]);

			}
			
			dos.writeInt(from);
			dos.writeInt(count2);
			if (count2 % 10000 == 0)
				System.out.println("  count2     is   " + count2);
		}
		dis.close();
		bis.close();
		fis.close();
		dos.close();
		bos.close();
		fos.close();
		

	}

}
