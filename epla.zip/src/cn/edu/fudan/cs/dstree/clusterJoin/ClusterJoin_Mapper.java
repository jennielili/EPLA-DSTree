package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.commons.lang.math.IntRange;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Mapper.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;

import java.util.*;
import java.io.IOException;
import java.math.*;

/**
 * Mapper for ClusterJoin
 * 
 * @author  Qli
 * In the map function, the input is a point and a set of centers,
 * 
 */
public class ClusterJoin_Mapper extends Mapper<LongWritable, DoublesWritable, IntWritable, DoublesWritable> {

	 Node root;
	 private int tsLength=256;
     private int centerNumber=1000;
     private double t=5.0;
     @SuppressWarnings("unchecked")
	private List<double[]> centers=new ArrayList();
     HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	@Override
    protected void setup(Context context) throws IOException, InterruptedException {
        Configuration conf = context.getConfiguration();
        FileSystem fs = FileSystem.get(conf);
        Path path = new Path("hdfs://10.141.208.49:9000/user/hadoop/center/billionSeries_256_1000.z.bin");
        tsLength=256;
        centerNumber=1000;
        t=0.01;
        if (!fs.exists(path)) {
            throw new IOException("route file not exists!");
        }
        FSDataInputStream fsDataInputStream = fs.open(path);
        FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
        
        for(int ii=0;ii<centerNumber;ii++)
        {
        	double[] center=new double[tsLength];
        	for(int jj=0;jj<tsLength;jj++)
        		center[jj]=in.readDouble();
        	centers.add(center);
        }
        in.close();
        fsDataInputStream.close();
    }
	
	@Override
    protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
        double[] point=value.getDoubles();
        double min=Double.MAX_VALUE;
        double[] dis=new double[centerNumber];
        int index=-1;
        for(int ii=0;ii<centerNumber;ii++)
        {
        	dis[ii]=DistUtil.euclideanDist(point, centers.get(ii));
        	if(dis[ii]<min)
        	{
        		min=dis[ii];
        		index=ii;
        	}
        }
        value.setFrom(0);
        // find the nearest center and assign the point to the partition
        context.write(new IntWritable(index), value);
        int k=0;
        for(int j=0;j<centerNumber;j++)
        {
        	if(j>index)
        	{
        		double xc=(DistUtil.euclideanDist(centers.get(index), centers.get(j)))/2;
        		double xq=DistUtil.euclideanDist(point,centers.get(index));
        		double cq=DistUtil.euclideanDist(centers.get(j),point);
        		if(cq*cq<=xq*xq+4*xc*t)
        		{
                        k++;
                        value.setFrom(1);
                        // if the condition is not satisfied, the point should be assigned to the partition presented by center j 
        				context.write(new IntWritable(j), value);
        		}
        		
        	}
        }
        
    }

   
}
