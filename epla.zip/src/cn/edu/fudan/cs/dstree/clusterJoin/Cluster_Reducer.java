package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Reducer.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import cn.edu.fudan.cs.dstree.allpair.AllPairUtils;
import cn.edu.fudan.cs.dstree.allpair.AutoExpandIntArray;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import java.io.IOException;
import java.util.*;

/**
 * Reduecer for KDS Search
 * 
 * @author Qli
 */
public class Cluster_Reducer extends
	Reducer<IntWritable, DoublesWritable, IntWritable, Text> {
	 Node root;
	 private int tsLength=1000;
     private double threshold=0.5;
     private int allsize=0;
    
	protected void reduce(
    		IntWritable key,
	    java.lang.Iterable<DoublesWritable> vals,  org.apache.hadoop.mapreduce.Reducer<IntWritable, DoublesWritable, IntWritable, Text>.Context context)
    throws java.io.IOException, InterruptedException {
		int count=0;
		List<DoublesWritable> values=new ArrayList();
		
		for (DoublesWritable val : vals) {
			count++;
		//	System.out.println("  id   is  "+val.getId()+"   from   is   "+val.getFrom());
           double[] temp=val.getDoubles().clone();
           int id=val.getId();
           DoublesWritable  dd=new DoublesWritable(0,id,temp);
           values.add(dd);
          
        }
		int[] idxArray_left=new int[values.size()];
		double[][]  timeseries=new double[values.size()][tsLength];
		double[] center=new double[tsLength];
    	for(int ii=0;ii<values.size();ii++)
		{
			
			timeseries[ii]=values.get(ii).getDoubles();
			for(int jj=0;jj<tsLength;jj++)
			{
				center[jj]+=timeseries[ii][jj];
			}
			
		//	System.out.println("  id   "+idxArray_left[ii]+"  time series 0"+timeseries[ii][0]);
		}
    	for(int jj=0;jj<tsLength;jj++)
		{
    		center[jj]=center[jj]/values.size();
		}
    	// find the nearest point from center
    	double min=Double.MAX_VALUE;
        double[] dis=new double[values.size()];
        int index=-1;
        int id=-1;
    	for(int ii=0;ii<values.size();ii++)
        {
          	dis[ii]=DistUtil.euclideanDist(center, values.get(ii).getDoubles());
          	//System.out.println("  double   is   "+dis[ii]);
          	if(dis[ii]<min)
          	{
          		min=dis[ii];
          		index=ii;
          		id=values.get(ii).getId();
          	}
          }
  //  index  is the nearest one
    	 String center_string="";
    	 double[] centers=values.get(index).getDoubles();
    	 for(int ii=0;ii<tsLength-1;ii++)
    	 {
    		 center_string+=centers[ii]+" ";
    	 }
    	 center_string+=centers[tsLength-1];
    	 DoublesWritable  dd=new DoublesWritable(0,id,values.get(index).getDoubles());
    	 context.write(key, new Text(center_string));
	}
}
