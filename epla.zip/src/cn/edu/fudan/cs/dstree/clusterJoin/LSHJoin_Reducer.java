package cn.edu.fudan.cs.dstree.clusterJoin;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Reducer.Context;
import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import cn.edu.fudan.cs.dstree.allpair.AllPairUtils;
import cn.edu.fudan.cs.dstree.allpair.AutoExpandIntArray;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import cn.edu.fudan.cs.dstree.allpair.AllPairReduceBruteFinder;
import java.io.IOException;
import java.util.*;

/**
 * Reduecer for KDS Search
 * 
 * @author Qli
 */
public class LSHJoin_Reducer extends
	Reducer<IntWritable, DoublesWritable, IntWritable, Text> {
	 Node root;
	 private int tsLength=1000;
     private double threshold=1.2;
    
     @Override
     protected void setup(Context context) throws IOException, InterruptedException {
      //  super.setup(context);
    	 threshold=1.2;
    	 tsLength=1000;
     }
	protected void reduce(
    		IntWritable key,
	    java.lang.Iterable<DoublesWritable> vals,  org.apache.hadoop.mapreduce.Reducer<IntWritable, DoublesWritable, IntWritable, Text>.Context context)
    throws java.io.IOException, InterruptedException {
		int count=0;
		List<double[]> values=new ArrayList();
		AutoExpandIntArray allPairs = new AutoExpandIntArray(1000);
		for (DoublesWritable val : vals) {
			count++;
           double[] temp=val.getDoubles();
           values.add(temp);
         //  context.write(new IntWritable(val.getId()), new DoubleWritable(min));
        }
		System.out.println("  partition  "+key.get()+"   size   "+values.size());
		double[][]  timeseries=new double[values.size()][tsLength];
		double[][]  reducedTimeSeries=new double[values.size()][tsLength];
		for(int ii=0;ii<values.size();ii++)
		{
			timeseries[ii]=values.get(ii);
		}
		int[] segments;
		segments = AllPairUtils.calcPoints(tsLength, 8);
	    for (int i = 0; i < timeseries.length; i++) {
	            reducedTimeSeries[i] = AllPairUtils.avgBySegments(timeseries[i], segments);
	    }	
		AllPairReduceBruteFinder.findAllPairsWithPaaAbandon(timeseries, reducedTimeSeries, 8, threshold, allPairs);
		System.out.println("  partition  "+key.get()+"     number   is  "+allPairs.size());
	    String tt=""+allPairs.size()+"\t"+values.size();
		context.write(key, new Text(tt));
	}
}
