package cn.edu.fudan.cs.dstree.clusterJoin;

import org.apache.commons.lang.math.IntRange;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Mapper.Context;

import cn.edu.fudan.cs.dstree.hadoop.DoublesWritable;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;

import java.util.*;
import java.io.IOException;
import java.math.*;

/**
 * Mapper for ClusterJoin
 * 
 * @author Qli
 * 
 */
public class LSHJoin_Preprocess_Mapper extends
		Mapper<LongWritable, DoublesWritable, IntWritable, IntWritable> {

	Node root;
	private int tsLength = 1000;
	private int threshold;
	private int centerNumber = 300;
	private double t = 5.0;
	private double[] a1;
	private double[] a2;
	private double[] a3;
	private double[] a4;
	private double b = 0.05;
	private double r = 0.1;
	private List<double[]> centers = new ArrayList();
	HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		// super.setup(context);
		// read centers
		Configuration conf = context.getConfiguration();
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path("center/centers");
		tsLength = 1000;
		centerNumber = 300;
		t = 1.2;
		if (!fs.exists(path)) {
			throw new IOException("route file not exists!");
		}
		FSDataInputStream fsDataInputStream = fs.open(path);
		FSTObjectInput in = new FSTObjectInput(fsDataInputStream);

		for (int ii = 0; ii < centerNumber; ii++) {
			double[] center = new double[tsLength];
			for (int jj = 0; jj < tsLength; jj++)
				center[jj] = in.readDouble();
			centers.add(center);
		}
		in.close();
		a1 = centers.get(3);
		a2 = centers.get(100);
		a3 = centers.get(200);
		a4 = centers.get(250);

	}

	@Override
	protected void map(LongWritable key, DoublesWritable value, Context context)
			throws IOException, InterruptedException {
		double[] point = value.getDoubles();
		// point=CalcUtil.z_Normalize(point);
		double min = Double.MAX_VALUE;
		double[] dis = new double[centerNumber];
		int index = -1;

		int hashValue1 = (int) Tool.getHashValue(a1, b, r, point);
		int hashValue2 = (int) Tool.getHashValue(a2, b, r, point);
		int hashValue3 = (int) Tool.getHashValue(a3, b, r, point);
		int hashValue4 = (int) Tool.getHashValue(a4, b, r, point);

		String a = "a";
		String b = "b";
		String c = "c";
		String d = "d";
        int average=hashValue1+hashValue2+hashValue3+hashValue4;
		context.write(new IntWritable(average), new IntWritable(1));
		/*context.write(new Text(b + hashValue2), new IntWritable(1));
		context.write(new Text(c + hashValue3), new IntWritable(1));
		context.write(new Text(d + hashValue4), new IntWritable(1));*/
		

	}

}
