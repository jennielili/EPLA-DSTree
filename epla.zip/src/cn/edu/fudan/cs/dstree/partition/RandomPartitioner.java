package cn.edu.fudan.cs.dstree.partition;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 2014/10/18.
 *  * partition the vertex by the mode remainder of partition count
 */
public class RandomPartitioner extends Partitioner {
    @Override
    public void partition() {
        double totalLoad = getTotalVertexLoad();
      //  partitionCount = (int) Math.ceil(totalLoad * 1.0 / capacityThreshold);
     //  partitionCount=32;
        System.out.println("totalLoad = " + totalLoad);
        for (int i = 0; i < graph.getVertexList().size(); i++) {
            graph.getVertexList().get(i).setPartitionIdx(i % partitionCount);
        }

        //output the partitionLoad to verify the max Threshold restriction
        for (int i = 0; i < partitionCount; i++) {
            double partitionLoad = getTotalVertexLoadByPartitionIdx(i);
            System.out.println("partitionLoad " + i +" = " + partitionLoad);
        }
    }
    public void swapTwoPartitions(List<Vertex> leftList, List<Vertex> rightList)
    {}
    double capacityThreshold;
    public double getCapacityThreshold() {
		return capacityThreshold;
	}
	public void setCapacityThreshold(double capacityThreshold) {
		this.capacityThreshold = capacityThreshold;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int count;
    
}
