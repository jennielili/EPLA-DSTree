package cn.edu.fudan.cs.dstree.partition;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyang on 2014/10/18.
 */
public abstract class Partitioner {
    public abstract void partition();

    Graph graph;

    public Graph getGraph() {
        return graph;
    }

    public void setGraph(Graph graph) {
        this.graph = graph;
    }
    public abstract void swapTwoPartitions(List<Vertex> leftList, List<Vertex> rightList);
    double capacityThreshold;

    int partitionCount;

    public double getCapacityThreshold() {
        return capacityThreshold;
    }

    public void setCapacityThreshold(double capacityThreshold) {
        this.capacityThreshold = capacityThreshold;
    }

    public int getPartitionCount() {
        return partitionCount;
    }

    public void setPartitionCount(int partitionCount) {
        this.partitionCount = partitionCount;
    }

    public double getTotalVertexLoad() {
        return graph.getTotalLoad();
    }

    public List<Vertex> getVertexListByPartitionIdx(int partitionIdx) {
        List<Vertex> ret = new ArrayList<Vertex>();
        for (int i = 0; i < graph.getVertexList().size(); i++) {
            Vertex vertex = graph.getVertexList().get(i);
            if (vertex.getPartitionIdx() == partitionIdx)
                ret.add(vertex);
        }
        return ret;
    }

    public double getTotalVertexLoadByPartitionIdx(int partitionIdx) {
        double ret = 0;
        for (int i = 0; i < graph.getVertexList().size(); i++) {
            Vertex vertex = graph.getVertexList().get(i);
            if (vertex.getPartitionIdx() == partitionIdx)
                ret += vertex.getLoad();
        }
        return ret;
    }

    public static int getTotalLoad(List<Vertex> vertexes) {
        int ret = 0;
        for (int i = 0; i < vertexes.size(); i++) {
            ret += vertexes.get(i).getLoad();
        }
        return ret;
    }

    public void checkAndAdjustOrphanNode() {
        int orphanNodeCount = 0;
        for (int i = 0; i < partitionCount; i++) {
            List<Vertex> vertexListByPartitionIdx = getVertexListByPartitionIdx(i);

            for (int j = 0; j < vertexListByPartitionIdx.size(); j++) {
                Vertex vertex = vertexListByPartitionIdx.get(j);

                boolean isOrphanNode = true;
                int targetPartitionId = -1;
                List<Edge> edgeList = graph.getEdgeList();
                for (int k = 0; k < edgeList.size(); k++) {
                    Edge edge = edgeList.get(k);
                    if (edge.vertex1 == vertex)
                    {
                        if (edge.vertex2.getPartitionIdx() == i)
                        {
                            isOrphanNode = false;
                            break;
                        }
                        else{
                            if (targetPartitionId < 0)
                            {
                                targetPartitionId = edge.vertex2.getPartitionIdx();
                            }
                        }
                    } else if (edge.vertex2 == vertex)
                    {
                        if (edge.vertex1.getPartitionIdx() == i)
                        {
                            isOrphanNode = false;
                            break;
                        }
                        else{
                            if (targetPartitionId < 0)
                            {
                                targetPartitionId = edge.vertex1.getPartitionIdx();
                            }
                        }
                    }
                }
                if (isOrphanNode)
                {
                    orphanNodeCount ++;
                    if (targetPartitionId > 0) {
                        vertex.setPartitionIdx(targetPartitionId);
                    }
//                    System.out.println("pcaTreeNode = " + pcaTreeNode);
                }
            }
        }
        System.out.println("orphanNodeCount = " + orphanNodeCount);
    }
}
