package cn.edu.fudan.cs.dstree.partition;

import java.util.*;

/**
 * Created by QLi on 2014/10/18.
 * This progam implements FM partitioning 
 */
public class FMPartitioner extends Partitioner {
    HashMap<Vertex, List<Vertex>> vertexPairMap = new HashMap<Vertex, List<Vertex>>();

    @Override
    public void partition() {
        //init hashMap;
        List<Edge> edgeList = graph.getEdgeList();
        for (int i = 0; i < edgeList.size(); i++) {
            Edge edge = edgeList.get(i);
            Vertex vertex1 = edge.getVertex1();
            Vertex vertex2 = edge.getVertex2();

            List<Vertex> vertexes1 = vertexPairMap.get(vertex1);
            if (vertexes1 == null) {
                vertexes1 = new ArrayList<Vertex>();
                vertexPairMap.put(vertex1, vertexes1);
            }
            vertexes1.add(vertex2);

            List<Vertex> vertexes2 = vertexPairMap.get(vertex2);
            if (vertexes2 == null) {
                vertexes2 = new ArrayList<Vertex>();
                vertexPairMap.put(vertex2, vertexes2);
            }
            vertexes2.add(vertex1);
        }


        List<List<Vertex>> lists = splitVertexList(graph.getVertexList(), capacityThreshold);

        int vertexCount = 0;
        int vertexLoadSum = 0;
        for (int i = 0; i < lists.size(); i++) {
            List<Vertex> vertexes = lists.get(i);
            for (int j = 0; j < vertexes.size(); j++) {
                Vertex vertex = vertexes.get(j);
                vertex.setPartitionIdx(i);
                vertexCount ++;
                vertexLoadSum += vertex.getLoad();
            }
        }
      //  System.out.println("vertexCount = " + vertexCount);
      //  System.out.println("vertexLoadSum = " + vertexLoadSum);

        partitionCount = lists.size();

     //   System.out.println("partitionCount = " + partitionCount);
        double totalLoad = 0;
        for (int i = 0; i < partitionCount; i++) {
            double totalVertexLoadByPartitionIdx = getTotalVertexLoadByPartitionIdx(i);
            totalLoad += totalVertexLoadByPartitionIdx;
         //   System.out.println("partition " + i + " load is " + totalVertexLoadByPartitionIdx);
        }
        System.out.println("totalLoad = " + totalLoad);
    }

    Comparator<Vertex> comparator = new GainComparator();

    private List<List<Vertex>> splitVertexList(List<Vertex> inputVertexList, double maxSize) {
        List<List<Vertex>> ret = new ArrayList<List<Vertex>>();

        int currentSize = getTotalLoad(inputVertexList);
        if (currentSize <= maxSize) {
            ret.add(inputVertexList);
        } else {
            //init left and right partition
            int halfCurrentSize = currentSize / 2;

            List<Vertex> leftList = new ArrayList<Vertex>();
            List<Vertex> rightList = new ArrayList<Vertex>();
            int count = 0;
            for (int i = 0; i < inputVertexList.size(); i++) {
                Vertex vertex = inputVertexList.get(i);

                if ((count + vertex.getLoad()) < halfCurrentSize) {
                    //add to left partition
                    count += vertex.getLoad();
                    leftList.add(vertex);
                } else {
                    //the right partition
                    for (int j = i; j < inputVertexList.size(); j++) {
                        Vertex vertex1 = inputVertexList.get(j);
                        rightList.add(vertex1);
                    }
                    break;
                }
            }
//            System.out.println("leftList.size() = " + leftList.size());
//            System.out.println("rightList.size() = " + rightList.size());

            HashSet leftSet = new HashSet(leftList);
            HashSet rightSet = new HashSet(rightList);

            //init weights and moved to false
            for (int i = 0; i < inputVertexList.size(); i++) {
                Vertex vertex = inputVertexList.get(i);
                vertex.innerWeight = 0;
                vertex.outerWeight = 0;
                vertex.setMoved(false);
            }
            initWeights(leftSet, rightSet);

            //move until gain not increase
            double totalGain = getTotalGain(leftList) + getTotalGain(rightList);
            int leftPartitionLoad = getTotalLoad(leftList);
            int rightPartitionLoad = getTotalLoad(rightList);

            int moveCount = 0;
            while (true) {
                //sort leftList and rightList by gain
            /*	if(leftList.size()==0)
            		break;
            	if(rightList.size()==0)
            		break;*/
            	
            	
            	//System.out.println("  the number   of   leftList   "+leftList.size());
            	 if(leftList.size()==0 || rightList.size()==0)
                 	break;
            	Collections.sort(leftList, comparator);
                Collections.sort(rightList, comparator);
               
                Vertex leftTopVertex = leftList.get(0);
                Vertex rightTopVertex = rightList.get(0);
               

                if (leftPartitionLoad > rightPartitionLoad) //move a Vertex from left to right
                {
                    if (leftTopVertex.getGainWeight() < 0) {
                        if (leftTopVertex.isMoved())
                            throw new RuntimeException("duplicated move");
                        leftTopVertex.setMoved(true);
                        moveCount++;
                        leftList.remove(0);
                        rightList.add(leftTopVertex);

                        leftSet.remove(leftTopVertex);
                        rightSet.add(leftTopVertex);
                        //update weights related to leftTopVertex
                        int temp = leftTopVertex.outerWeight;
                        leftTopVertex.outerWeight = leftTopVertex.innerWeight;
                        leftTopVertex.innerWeight = temp;
                        //update others
                        List<Vertex> vertexList = vertexPairMap.get(leftTopVertex);
                        if (vertexList != null) {
                            for (int i = 0; i < vertexList.size(); i++) {
                                Vertex vertex = vertexList.get(i);
                                if (leftSet.contains(vertex)) {
                                    vertex.innerWeight--;
                                    vertex.outerWeight++;
                                }

                                if (rightList.contains(vertex)) {
                                    vertex.outerWeight--;
                                    vertex.innerWeight++;
                                }
                            }
                        }
                        //update count
                        leftPartitionLoad -= leftTopVertex.getLoad();
                        rightPartitionLoad += leftTopVertex.getLoad();
                    } else {
//                        System.out.println("leftTopVertex.getGainWeight() = " + leftTopVertex.getGainWeight());
                        break;
                    }
                } else {
                    if (rightTopVertex.getGainWeight() < 0) {
                        if (rightTopVertex.isMoved())
                            throw new RuntimeException("duplicated move");
                        rightTopVertex.setMoved(true);
                        moveCount++;
                        rightList.remove(0);
                        leftList.add(rightTopVertex);
                        rightSet.remove(rightTopVertex);
                        leftSet.add(rightTopVertex);
                        //update weights related to leftTopVertex
                        int temp = rightTopVertex.outerWeight;
                        rightTopVertex.outerWeight = rightTopVertex.innerWeight;
                        rightTopVertex.innerWeight = temp;
                        //update others
                        List<Vertex> vertexList = vertexPairMap.get(rightTopVertex);
                        if (vertexList != null) {
                            for (int i = 0; i < vertexList.size(); i++) {
                                Vertex vertex = vertexList.get(i);
                                if (leftSet.contains(vertex)) {
                                    vertex.innerWeight++;
                                    vertex.outerWeight--;
                                }

                                if (rightList.contains(vertex)) {
                                    vertex.outerWeight++;
                                    vertex.innerWeight--;
                                }
                            }
                        }
                        //update count
                        leftPartitionLoad += rightTopVertex.getLoad();
                        rightPartitionLoad -= rightTopVertex.getLoad();
                    } else {
//                        System.out.println("rightTopVertex.getGainWeight() = " + rightTopVertex.getGainWeight());
                        break;
                    }
                }

                double newTotalGain = getTotalGain(leftList) + getTotalGain(rightList);
                if (newTotalGain >= totalGain) {
//                    System.out.println("newTotalGain = " + newTotalGain);
//                    System.out.println("totalGain = " + totalGain);
                    totalGain = newTotalGain;
                } else //total gain not increase
                {
                    System.out.println("newTotalGain = " + newTotalGain);
                    System.out.println("totalGain = " + totalGain);
                    break;
                }
            }
           System.out.println("moveCount = " + moveCount+"  leftList   "+leftList.size()+"  right  "+rightList.size()+"  maxSize   "+maxSize);
         //add by lqh 20160127
       //    if(leftList.size()==0 || rightList.size()==0)
         //  	return ret;
            ret.addAll(splitVertexList(leftList, maxSize));
            ret.addAll(splitVertexList(rightList, maxSize));
            
           
        }

        return ret;
    }
    
    public void swapTwoPartitions(List<Vertex> leftList, List<Vertex> rightList) {
    
            HashSet leftSet = new HashSet(leftList);
            HashSet rightSet = new HashSet(rightList);
            int leftId=-1;
            int rightId=-1;
            if(leftList.size()>0)
            {
            	Vertex ver1=leftList.get(0);
            	leftId=ver1.getPartitionIdx();
            }
            if(rightList.size()>0)
            {
            	Vertex ver1=rightList.get(0);
            	rightId=ver1.getPartitionIdx();
            }
            //init weights and moved to false
            for (int i = 0; i < leftList.size(); i++) {
                Vertex vertex = leftList.get(i);
                vertex.innerWeight = 0;
                vertex.outerWeight = 0;
                vertex.setMoved(false);
            }
            for (int i = 0; i < rightList.size(); i++) {
                Vertex vertex = rightList.get(i);
                vertex.innerWeight = 0;
                vertex.outerWeight = 0;
                vertex.setMoved(false);
            }
            initWeights(leftSet, rightSet);

            //move until gain not increase
            double totalGain = getTotalGain(leftList) + getTotalGain(rightList);
            int leftPartitionLoad = getTotalLoad(leftList);
            int rightPartitionLoad = getTotalLoad(rightList);

            int moveCount = 0;
            while (true) {
                //sort leftList and rightList by gain
                Collections.sort(leftList, comparator);
                Collections.sort(rightList, comparator);

                Vertex leftTopVertex = leftList.get(0);
                Vertex rightTopVertex = rightList.get(0);

                if (leftPartitionLoad > rightPartitionLoad) //move a Vertex from left to right
                {
                    if (leftTopVertex.getGainWeight() < 0) {
                        if (leftTopVertex.isMoved())
                            throw new RuntimeException("duplicated move");
                        leftTopVertex.setMoved(true);
                        moveCount++;
                        leftList.remove(0);
                        rightList.add(leftTopVertex);
                        leftTopVertex.setPartitionIdx(rightId);

                        leftSet.remove(leftTopVertex);
                        rightSet.add(leftTopVertex);
                        //update weights related to leftTopVertex
                        int temp = leftTopVertex.outerWeight;
                        leftTopVertex.outerWeight = leftTopVertex.innerWeight;
                        leftTopVertex.innerWeight = temp;
                        //update others
                        List<Vertex> vertexList = vertexPairMap.get(leftTopVertex);
                        if (vertexList != null) {
                            for (int i = 0; i < vertexList.size(); i++) {
                                Vertex vertex = vertexList.get(i);
                                if (leftSet.contains(vertex)) {
                                    vertex.innerWeight--;
                                    vertex.outerWeight++;
                                }

                                if (rightList.contains(vertex)) {
                                    vertex.outerWeight--;
                                    vertex.innerWeight++;
                                }
                            }
                        }
                        //update count
                        leftPartitionLoad -= leftTopVertex.getLoad();
                        rightPartitionLoad += leftTopVertex.getLoad();
                    } else {
//                        System.out.println("leftTopVertex.getGainWeight() = " + leftTopVertex.getGainWeight());
                        break;
                    }
                } else {
                    if (rightTopVertex.getGainWeight() < 0) {
                        if (rightTopVertex.isMoved())
                            throw new RuntimeException("duplicated move");
                        rightTopVertex.setMoved(true);
                        moveCount++;
                        rightList.remove(0);
                        leftList.add(rightTopVertex);
                        rightSet.remove(rightTopVertex);
                        rightTopVertex.setPartitionIdx(leftId);
                        leftSet.add(rightTopVertex);
                        //update weights related to leftTopVertex
                        int temp = rightTopVertex.outerWeight;
                        rightTopVertex.outerWeight = rightTopVertex.innerWeight;
                        rightTopVertex.innerWeight = temp;
                        //update others
                        List<Vertex> vertexList = vertexPairMap.get(rightTopVertex);
                        if (vertexList != null) {
                            for (int i = 0; i < vertexList.size(); i++) {
                                Vertex vertex = vertexList.get(i);
                                if (leftSet.contains(vertex)) {
                                    vertex.innerWeight++;
                                    vertex.outerWeight--;
                                }

                                if (rightList.contains(vertex)) {
                                    vertex.outerWeight++;
                                    vertex.innerWeight--;
                                }
                            }
                        }
                        //update count
                        leftPartitionLoad += rightTopVertex.getLoad();
                        rightPartitionLoad -= rightTopVertex.getLoad();
                    } else {
//                        System.out.println("rightTopVertex.getGainWeight() = " + rightTopVertex.getGainWeight());
                        break;
                    }
                }

                double newTotalGain = getTotalGain(leftList) + getTotalGain(rightList);
                if (newTotalGain >= totalGain) {
//                    System.out.println("newTotalGain = " + newTotalGain);
//                    System.out.println("totalGain = " + totalGain);
                    totalGain = newTotalGain;
                } else //total gain not increase
                {
                    System.out.println("newTotalGain = " + newTotalGain);
                    System.out.println("totalGain = " + totalGain);
                    break;
                }
            }
            System.out.println("moveCount = " + moveCount);

            
    }
    private int getTotalGain(List<Vertex> vertexList) {
        int ret = 0;
        for (int i = 0; i < vertexList.size(); i++) {
            Vertex vertex = vertexList.get(i);
            ret += vertex.getGainWeight();
        }
        return ret;
    }

    public void initWeights(HashSet<Vertex> leftList, HashSet<Vertex> rightList) {
        List<Edge> edgeList = graph.getEdgeList();
        for (int i = 0; i < edgeList.size(); i++) {
            Edge edge = edgeList.get(i);
            Vertex vertex1 = edge.vertex1;
            Vertex vertex2 = edge.vertex2;
            if (leftList.contains(vertex1) && leftList.contains(vertex2)) {
                vertex1.innerWeight++;
                vertex2.innerWeight++;
            } else if (rightList.contains(vertex1) && rightList.contains(vertex2)) {
                vertex1.innerWeight++;
                vertex2.innerWeight++;
            } else if (leftList.contains(vertex1) && rightList.contains(vertex2)) {
                vertex1.outerWeight++;
                vertex2.outerWeight++;
            } else if (leftList.contains(vertex2) && rightList.contains(vertex1)) {
                vertex1.outerWeight++;
                vertex2.outerWeight++;
            }
        }
    }
}

class GainComparator implements Comparator<Vertex> {
    @Override
    public int compare(Vertex o1, Vertex o2) {
        if (o1.isMoved() == o2.isMoved())
            return Integer.compare(o1.getGainWeight(), o2.getGainWeight());
        else
            return Boolean.compare(o1.isMoved(), o2.isMoved());
    }
}