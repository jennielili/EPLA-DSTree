package cn.edu.fudan.cs.dstree.partition;

import java.io.Serializable;
import java.util.BitSet;

/**
 * Created by wangyang on 2014/10/18.
 */
public class Vertex implements Serializable{
    int id;
    int degree;
    public BitSet bitSet;
	public int getDegree() {
		return degree;
	}

	public void setDegree(int degree) {
		this.degree = degree;
	}

	String tag;
    double load;
    Object data; //save inter data
    boolean moved = false;

    public boolean isMoved() {
        return moved;
    }

    public void setMoved(boolean moved) {
        this.moved = moved;
    }

    public Vertex(int id, String tag, double load, Object data) {
        this.id = id;
        this.tag = tag;
        this.load = load;
        this.data = data;
    }

    public Vertex(int id, double load, Object data) {
        this.id = id;
        this.load = load;
        this.data = data;
    }

    public Vertex(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public double getLoad() {
        return load;
    }

    public void setLoad(double load) {
        this.load = load;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Vertex{" +
                "id=" + id +
                ", tag='" + tag + '\'' +
                ", load=" + load +
                ", partition=" + partitionIdx +
                ", data=" + data.toString() +
                '}';
    }

    int innerWeight = 0;
    int outerWeight = 0;
    int getGainWeight()
    {
        return innerWeight - outerWeight;
    }

    int diskLoadCount = 0;
    int visitCount = 0;
    boolean inCache = false;

    int partitionIdx = -1;

    public int getPartitionIdx() {
        return partitionIdx;
    }

    public void setPartitionIdx(int partitionIdx) {
        this.partitionIdx = partitionIdx;
    }

    public int getInnerWeight() {
        return innerWeight;
    }

    public void setInnerWeight(int innerWeight) {
        this.innerWeight = innerWeight;
    }

    public int getOuterWeight() {
        return outerWeight;
    }

    public void setOuterWeight(int outerWeight) {
        this.outerWeight = outerWeight;
    }

    public int getDiskLoadCount() {
        return diskLoadCount;
    }

    public void setDiskLoadCount(int diskLoadCount) {
        this.diskLoadCount = diskLoadCount;
    }

    public int getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(int visitCount) {
        this.visitCount = visitCount;
    }

    public boolean isInCache() {
        return inCache;
    }

    public void setInCache(boolean inCache) {
        this.inCache = inCache;
    }

    public void incVisitCount() {
        visitCount ++;
    }

    public void incDiskLoadCount() {
        diskLoadCount ++;
    }

//    @Override
//    public int hashCode() {
//        return id;
//    }
}
