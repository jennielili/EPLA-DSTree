package cn.edu.fudan.cs.dstree.partition;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

import de.ruedigermoeller.serialization.FSTObjectOutput;

/**
 * Created by wangyang on 2014/10/18.
 */
public class Graph implements Serializable{
    List<Vertex> vertexList;
    List<Edge> edgeList;
    HashMap<Vertex, List<Edge>> neighbors=new HashMap();

    public Graph(List<Vertex> vertexList, List<Edge> edgeList) {
        this.vertexList = vertexList;
        this.edgeList = edgeList;
    }
    public Graph(List<Vertex> vertexList2, List<Edge> edgeList2,int clone) {
        this.vertexList = new ArrayList();
        this.edgeList = new ArrayList();
        for(int ii=0;ii<vertexList.size();ii++)
        {
        	vertexList.add(vertexList2.get(ii));
        }
        for(int ii=0;ii<edgeList2.size();ii++)
        {
        	edgeList.add(edgeList2.get(ii));	
        }
        
    }
    public HashMap<Vertex, List<Edge>> computeNeighbors()
    {
    	HashMap<Vertex, List<Edge>> neibors=new HashMap();
    	for(int ii=0;ii<edgeList.size();ii++)
    	{
    		Edge edge=edgeList.get(ii);
    		Vertex ver1=edge.getVertex1();
    		Vertex ver2=edge.getVertex2();
    		List<Edge> temp1=neibors.get(edge.getVertex1());
    		List<Edge> temp2=neibors.get(edge.getVertex2());
    		if(temp1==null)
    		{
    			temp1=new ArrayList();
    			temp1.add(edge);
    			neibors.put(ver1, temp1);
    		}
    		else
    			temp1.add(edge);
    		if(temp2==null)
    		{
    			temp2=new ArrayList();
    			temp2.add(edge);
    			neibors.put(ver2, temp2);
    		}
    		else
    			temp2.add(edge);
    		
    	}
    	return neibors;
    }
    public List<Vertex> getVertexList() {
        return vertexList;
    }

    public void setVertexList(List<Vertex> vertexList) {
        this.vertexList = vertexList;
    }

    public List<Edge> getEdgeList() {
        return edgeList;
    }

    public void setEdgeList(List<Edge> edgeList) {
        this.edgeList = edgeList;
    }

    @Override
    public String toString() {
        return "Graph{" +
                "vertexList=" + vertexList.size() +
                ", edgeList=" + edgeList.size() +
                '}';
    }
    public void graphToFile(String fileName) throws IOException
    {
    	// FileWriter fw = new FileWriter(fileName);// ����FileWriter��������д���ַ���
 	    // BufferedWriter bw = new BufferedWriter(fw);
    	 FSTObjectOutput out = new FSTObjectOutput(new FileOutputStream(fileName));
         out.writeObject(this);
         out.close(); // required !
 	         	
    }
    public double getTotalLoad()
    {
        double ret = 0;
        for (int i = 0; i < vertexList.size(); i++) {
            Vertex vertex = vertexList.get(i);
            ret += vertex.getLoad();
        }
        return ret;
    }

    public boolean checkValid()
    {
        //check every vertexes of edge is in vertexList
        for (int i = 0; i < edgeList.size(); i++) {
            Edge edge = edgeList.get(i);
            if (!vertexList.contains(edge.getVertex1()) || !vertexList.contains(edge.getVertex2()))
                return false;
        }

        return true;
    }

    public int getTotalVertexVisitCount() {
        int ret = 0;
        for (int i = 0; i < vertexList.size(); i++) {
            Vertex vertex = vertexList.get(i);
            ret += vertex.visitCount;
        }
        return ret;
    }

    public int getTotalVertexDiskLoadCount() {
        int ret = 0;
        for (int i = 0; i < vertexList.size(); i++) {
            Vertex vertex = vertexList.get(i);
            ret += vertex.diskLoadCount;
        }
        return ret;
    }
}
