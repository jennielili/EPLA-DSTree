package cn.edu.fudan.cs.dstree.partition;

import java.io.Serializable;

/**
 * Created by wangyang on 2014/10/18.
 */
public class Edge implements Serializable {
    Vertex vertex1;
    Vertex vertex2;
    boolean isoff=false;
    public boolean isIsoff() {
		return isoff;
	}

	public void setIsoff(boolean isoff) {
		this.isoff = isoff;
	}

	public double getLb() {
		return lb;
	}

	public void setLb(double lb) {
		this.lb = lb;
	}

	public double getUb() {
		return ub;
	}

	public void setUb(double ub) {
		this.ub = ub;
	}

	double lb;
    double ub;

    double weight;

    public Edge(Vertex vertex1, Vertex vertex2, double weight) {
        this.vertex1 = vertex1;
        this.vertex2 = vertex2;
        this.weight = weight;
    }

    public Edge(Vertex vertex1, Vertex vertex2) {
        this(vertex1,vertex2,0);
    }

    public Vertex getVertex1() {
        return vertex1;
    }

    public Vertex getVertex2() {
        return vertex2;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return "Edge{" +
                "vertex1=" + vertex1 +
                ", vertex2=" + vertex2 +
                ", weight=" + weight +
                '}';
    }
}
