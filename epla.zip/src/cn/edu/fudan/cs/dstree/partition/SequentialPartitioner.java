package cn.edu.fudan.cs.dstree.partition;

import java.util.List;

/**
 * Created by wangyang on 2014/10/18.
 * partition the vertex by the sequential order of vertex
 */
public class SequentialPartitioner extends Partitioner {
    @Override
    public void partition() {
        double curLoadSum = 0;
        int curPartitionIdx = 0;
        List<Vertex> vertexList = graph.getVertexList();
        for (int i = 0; i < vertexList.size(); i++) {
            Vertex vertex = vertexList.get(i);

            if ((curLoadSum + vertex.getLoad()) < capacityThreshold) {
                vertex.setPartitionIdx(curPartitionIdx);
                curLoadSum += vertex.getLoad();
            }
            else
            {
                curPartitionIdx ++;
                vertex.setPartitionIdx(curPartitionIdx);

                curLoadSum = 0;
                curLoadSum += vertex.getLoad();
            }
        }
        partitionCount = curPartitionIdx + 1;
    }
}
