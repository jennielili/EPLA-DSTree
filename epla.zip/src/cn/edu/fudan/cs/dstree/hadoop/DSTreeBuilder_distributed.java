package cn.edu.fudan.cs.dstree.hadoop;
import cn.edu.fudan.cs.dstree.dynamicsplit.*;
import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;

import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * Created by wangyang on 14-2-19.
 * modified by qiuhongli on 14-7-9
 */
public class DSTreeBuilder_distributed {
    private static final Log log = LogFactory.getLog(DSTreeBuilder_distributed.class);
    private static final String KDS_ROUTE_OUTPUT = "KDSTreeBuilder.Kds.Route.Output";
    private static final String DSTREE_THRESHOLD = "DSTreeBuilder.Threshold";
    private static final String SEGMENT_SIZE = "segmentSize";
    private static final String DSTREE_INDEX_OUTPUT = "DSTreeBuilder.Index.Output";
    private static final String DSTREE_DATA_OUTPUT = "DSTreeBuilder.Data.Output";

    public static class SeriesRouteMapper extends Mapper<LongWritable, DoublesWritable, IntWritable, DoublesWritable> {
        Node root;
        HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
        private int tsLength;
        private int threshold;

       
        @Override
        protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            double[] timeSeries = value.getDoubles();
            Random  random=new Random();
            int ran=random.nextInt(10);
            context.write(new IntWritable(ran), value);
        }

       
    }

    public static class SubTreeReducer extends Reducer<IntWritable, DoublesWritable, Text, LongWritable> {
        private LongWritable result = new LongWritable();
        Node root;
        HashMap<IntWritable, Node> idx2NodeMap = new HashMap<IntWritable, Node>();
        private int tsLength;
        private int threshold;
        private int segmentSize;
      
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            tsLength = context.getConfiguration().getInt(SeriesInputFormat.SeriesInputFormatTsLength, 128);
            threshold = context.getConfiguration().getInt(DSTREE_THRESHOLD, 100);
           // segmentSize=context.getConfiguration().getInt(DSTREE_THRESHOLD, 8);
            segmentSize=8;

        }
       public void reduce(IntWritable key, Iterable<DoublesWritable> values, Context context) throws IOException, InterruptedException {
           // System.out.println("cn.edu.fudan.cs.dstree.hadoop.SeriesIndex2.SubTreeReducer.reduce");
         StopWatch  sw=new StopWatch();
   		 sw.start();
//          Node node = idx2NodeMap.get(key);
   		 String indexPath = context.getConfiguration().get(DSTREE_INDEX_OUTPUT, "indexPath");
   		 String subIndexFileName = "subIndex_" + key.get() + ".idx";
         Path outFile = new Path(indexPath + "/" + subIndexFileName);
         Node root = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[2];
	        nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
	        nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
	        root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

	        MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
	        root.setSeriesSegmentSketcher(seriesSegmentSketcher);
	        root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(seriesSegmentSketcher));

	        root.setRange(new MeanStdevRange());

	        //calc the split points by segmentSize
	        short[] points = IndexBuilder.calcPoints(tsLength, 8);
	        root.initSegments(points);
            //begin insert
            long count = 0;
            for (DoublesWritable val : values) {
                double[] doubles = val.getDoubles();
                if(doubles.length==tsLength)
                {
	                root.insert(doubles);
	                count++;
                }
                else
                {
                	if(doubles!=null)
                		System.out.println("Exception    the length of time series is "+doubles.length);
                }
                	if (count % 10000 == 0)
                    log.info(count);
            }
            String dataPath = context.getConfiguration().get(DSTREE_DATA_OUTPUT, "dataPath");

            //save the file index and data
            Configuration conf = context.getConfiguration();
            FileSystem fs = FileSystem.get(conf);
            if (fs.exists(outFile)) {
                log.info("delete subindex ...");
                fs.delete(outFile, true);
            }
            //write index file
         
            FSDataOutputStream fsDataOutputStream = fs.create(outFile, true, 1024 * 1024, (short) 1, 4 * 1024 * 1024);
            log.info(outFile.toUri() + " is created!");
            FSTObjectOutput out = new FSTObjectOutput(fsDataOutputStream);
            out.writeObject(root);
            out.close(); // required !
            fsDataOutputStream.close();
            
            //save data file
            System.out.println("  It take  time  to create the index  "+sw.getTime()+"  count   is  "+count);
            StopWatch  sw2=new StopWatch();
   		    sw2.start();
            String subDataFileName = "subData_" + key.get() + ".bin";
            Path outDataFile = new Path(dataPath + "/" + subDataFileName);
            if (fs.exists(outDataFile)) {
                log.info("delete subData ...");
                fs.delete(outDataFile, true);
            }
            FSDataOutputStream fsDataOutputStream1 = fs.create(outDataFile, true, 16 * 1024 * 1024, (short) 1, 2 * 1024 * 1024 * 1024L);
            log.info(outDataFile.toUri() + " is created!");
            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
                Node node = leafNodesByFirstOrder.get(i);
                String fileName = node.getFileName();
                FileBuffer fileBuffer = FileBufferManager.getInstance().getFileBuffer(fileName);
                List<double[]> allTimeSeries = fileBuffer.getAllTimeSeries(); 
                for (int j = 0; j < allTimeSeries.size(); j++) {
                    double[] doubles = allTimeSeries.get(j);
                    for (int k = 0; k < doubles.length; k++) {
                        double aDouble = doubles[k];
                        fsDataOutputStream1.writeDouble(aDouble);
                    }
                }
            }
            fsDataOutputStream1.close();
            log.info(outDataFile.toUri() + " write finished!");
            result.set(count);
            System.out.println("  It take  time  to save the data  "+sw2.getTime());
            Text text = new Text(key.get() + "");
            context.write(text, result);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 6) {
            System.err.println("Usage: DSTreeBuilder <in> <out> <tsLength> <threshold> <indexOutputPath> <DataOutputPath>");
            System.exit(2);
        }

        int tsLength = Integer.parseInt(otherArgs[2]);
        int threshold = Integer.parseInt(otherArgs[3]);
        Job job = new Job(conf, "DSTree Distributed Builder");
        job.getConfiguration().set(KDS_ROUTE_OUTPUT, otherArgs[0] + "-routeTree/KDSTree.data");
        job.getConfiguration().setInt(SeriesInputFormat.SeriesInputFormatTsLength, tsLength); //add tsLength into config
        job.getConfiguration().setInt(DSTREE_THRESHOLD, threshold); //add tsLength into config
        job.getConfiguration().set(DSTREE_INDEX_OUTPUT, otherArgs[4]);
        job.getConfiguration().set(DSTREE_DATA_OUTPUT, otherArgs[5]);
        job.setNumReduceTasks(6); 
        job.setInputFormatClass(SeriesInputFormat.class);
      //  job.setInputFormatClass(SequenceFileInputFormat.class);
        job.setJarByClass(DSTreeBuilder_distributed.class);
        job.setMapperClass(SeriesRouteMapper.class);
        job.setMapOutputKeyClass(IntWritable.class);
        //job.setCombinerClass(SumReducer.class);
        job.setMapOutputValueClass(DoublesWritable.class);//it's very necessary
        job.setReducerClass(SubTreeReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[1]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
