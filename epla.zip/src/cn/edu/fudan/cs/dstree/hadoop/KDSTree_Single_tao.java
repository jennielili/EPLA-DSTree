package cn.edu.fudan.cs.dstree.hadoop;
//import java.util.*;
import java.text.DecimalFormat;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import org.apache.commons.lang.math.IntRange;
import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.io.IntWritable;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

public class KDSTree_Single_tao {

	/**
	 * @param args
	 */
	 HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	public static int segmentLevel=10;
	List<IntRange> segments;
	private int dimCount;
	public static int tsLength=512;
    public static int threshold=2620;
    public static double[] weight;
    private float sampleRate;
    private KDSTreeNode root;
    private Node newroot;
	public  void buildTree(double[][] dataSet,int numCenters) throws IOException {
		 // TODO Auto-generated method stub
		 System.out.println("  dataSet **************************       "+dataSet.length);
		 StopWatch stopWatch2 = new StopWatch();
		 stopWatch2.start();
		 segments = CalcUtil.generateSplitRanges(tsLength, segmentLevel);
		 dimCount = CalcUtil.generateSplitRanges(1000, segmentLevel).size();
		 System.out.println("  the size of segments  "+segments.size()+"   dimCount    is   "+dimCount);
		 double[][] temp=new double[dataSet.length][segments.size()];
		 double[][] temp2=new double[dataSet.length][segments.size()];
		 int[] labels=new int[dataSet.length];
		 int[] interval=new int[segments.size()];
		 for (int i = 0; i < segments.size(); i++) {
             IntRange intRange = segments.get(i);
             int start = intRange.getMinimumInteger();
             int end = intRange.getMaximumInteger();
             interval[i]=end-start+1;
          //  System.out.println("  index    is   "+i+"    start   is  "+start+"   end   is   "+end);
          
         }
		 for(int ii=0;ii<dataSet.length;ii++)
		 {
			 double[] ts = dataSet[ii];
             double[] means = new double[segments.size()];
             for (int i = 0; i < segments.size(); i++) {
                 IntRange intRange = segments.get(i);
                 int start = intRange.getMinimumInteger();
                 int end = intRange.getMaximumInteger();
            //    System.out.println("  start   is  "+start+"   end   is   "+end);
                 double avg = CalcUtil.avg(ts, start, end);
                 temp[ii][i] = avg;
                 temp2[ii][i] = avg;
               //  System.out.println("  ii  "+ii+"   i   "+i+"   "+temp[ii][i]);
                 
             }
           
		 }
		 //compare dhd distance and Euclidean distance
		 /*for(int ii=0;ii<dataSet.length;ii++)
		 {
			 for(int jj=0;ii<dataSet.length;ii++)
			 {
				 double dist1=DistUtil.euclideanDistSquare(dataSet[ii], dataSet[jj]);
				 double dist2=DistUtil.euclideanDistSquare(temp[ii], temp[jj]);
				
				 System.out.println("  dist1   is   "+dist1+"  dist2   is   "+dist2+"   ");
			 }
		 }*/
		 
		 
		 int [] indexes=new int[dataSet.length];
		 for(int ii=0;ii<indexes.length;ii++)
		 {
			 indexes[ii]=ii;
		 }
		 root = new KDSTreeNode(temp, dimCount, 1, threshold,indexes);
		 System.out.println("*****************  indexes   length  "+indexes.length);
		 System.out.println("***************** root indexes   length  "+root.indexes.length);
		 root.buildTree();
		 weight=new double[dimCount];
		 int ss=1;
		 weight[0]=1;
		 for(int ii=1;ii<dimCount;ii++)
		 {
			 int  ttt=(int)Math.floor(Math.log((double)(ii)));
			 int a= (int)Math.pow((double)2, (double)ttt);
			 weight[ii]=(double)1/(2*a);
			// System.out.println("   ttt      is      "+ttt+"     ii      is    "+ii+"   weight   "+weight[ii]);
			
		 }
		 String indexFileName="/home/hadoop/lqh/kdsindex";
        // root.saveToFile(indexFileName);
         StringBuilder  stringBuilder=new StringBuilder();
       //  root.printTree(stringBuilder);
         // clustering   here 
         List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         System.out.println("  number of leaves  "+leaves.size());
      //   double[][][] synopsis=new double[leaves.size()][dimCount][2];
         List<double[]> leafMins=new ArrayList();
         List<double[]> leafMaxs=new ArrayList();
         List<double[]>  medians=new ArrayList();
         double[][] medians2=new double[leaves.size()][1000];
         List<Integer>  realIndexes=new ArrayList();
         for(int ii=0;ii<leaves.size();ii++)
         {
        	 KDSTreeNode leaf=leaves.get(ii);
        	// System.out.println("  leaf   id    "+leaf.getId());
        	 int start=leaf.getStart();
        	 int end=leaf.getEnd();
        	 int median=(start+end)/2;
        	 int realIndex=indexes[median];
        	// System.out.println("   readIndex   *************   "+realIndex);
        	 medians.add(dataSet[realIndex]);
        	 realIndexes.add(realIndex);
        	 medians2[ii]=dataSet[realIndex];
         }
       /*  for(int ii=0;ii<leaves.size();ii++)
         {
        	 KDSTreeNode leaf=leaves.get(ii);
        	 int start=leaf.getStart();
        	 int end=leaf.getEnd();
        	 int median=(start+end)/2;
        	 int realIndex=indexes[median];
        	 System.out.println("   readIndex   *************   "+realIndex);
        	 medians.add(dataSet[realIndex]);
        	 double[][] temp2=leaf.getDataSet();
        	 System.out.println(" leaf   "+ii+"  splitValue  "+leaf.getParent().getSplitValue()+"  split dim  "+leaf.getParent().getSplitDim()+" weight "+leaf.getParent().getDimWeight(leaf.getParent().getSplitDim()));
        	 double[] synopsis_min=new double[dimCount];
        	 double[] synopsis_max=new double[dimCount];
        	 for(int k=0;k<dimCount;k++)
        	 {
        		 
        		 synopsis_min[k]=Double.MAX_VALUE;
        		 synopsis_max[k]=Double.MIN_VALUE; 
        	 }
        	 int start_dim=0;
        	 for(int k=start_dim;k<dimCount;k++)
        	 {
        		for(int jj=leaf.getStart();jj<leaf.getEnd();jj++)
        		{
        			if(temp2[jj][k]<synopsis_min[k])
        		          synopsis_min[k]=temp2[jj][k];
        			
        			if(temp2[jj][k]>synopsis_max[k])
      		          synopsis_max[k]=temp2[jj][k];
        	     }
        	 
               }
        	 leafMins.add(synopsis_min);
        	 leafMaxs.add(synopsis_max);
        //	 System.out.println("  leaf   ii "+ii+"   max  "+ synopsis_max[4]+"    min  "+synopsis_min[4] );
         }
         //compute   the  prunning   rate 
         int sum=0;
       for(int ii=0;ii<leaves.size();ii++)
         {
        	 int cc=0;
        	 for(int jj=ii+1;jj<leaves.size();jj++)
             {
        		 double[] synopsis_min1=leafMins.get(ii);
        		 double[] synopsis_min2=leafMins.get(jj);
        		 double[] synopsis_max1=leafMaxs.get(ii);
        		 double[] synopsis_max2=leafMaxs.get(jj);
        		 double dis=lowerBound(synopsis_min1,synopsis_max1,7,synopsis_min2,synopsis_max2,interval);
        		 System.out.println("  ii   "+ii+"   jj   "+jj+"    "+dis);
        		 if(dis>0.5)
        		 { 
        			 sum++;
        			 cc++;
        			 if(cc>=1)
        				 break;
        		 }
        	 
             }
         }*/
        
         double sum2=0.0;
         double sum1=0.0;
         KmeansPlusPlus kpp=new KmeansPlusPlus();
         List<Integer> centerIds=new ArrayList();
         List<double[]> results=kpp.chooseInitialMeans(medians2, numCenters,centerIds);
         List<Integer> realcenterIds=new ArrayList();
         for(int i=0;i<centerIds.size();i++)
         {
        	 int id=realIndexes.get(centerIds.get(i));
        	 realcenterIds.add(id);
        	// System.out.println("   i    "+i+"    id   "+id);
        	// System.out.println(" result    "   +results.get(i)[0]+"  temp2   "+dataSet[id][0]);
         }
         FileOutputStream fos=new FileOutputStream("c:\\data\\centers2");
         BufferedOutputStream bos = new BufferedOutputStream(fos);
         DataOutputStream dos = new DataOutputStream(bos);
         for (int i = 0; i < medians2.length; i++) {
 			for (int j = 0; j < tsLength; j++) {
 					dos.writeDouble(medians2[i][j]);
 					//System.out.println("  double   is   "+tss[j]);

 				}
 			}
 		dos.close();
 		bos.close();
 		fos.close();
 		int dismatch=0;
 	    System.out.println("  time  spent   is    "+stopWatch2.getTime()+"  centers number "+medians2.length);
        for(int ii=0;ii<dataSet.length;ii++)
         {
        	 double min=Double.MAX_VALUE;
        	 double min2=Double.MAX_VALUE;
        	 int index1=-1;
        	 int index2=-1;
        	 int last2=-1;
        /*	 for(int jj=0;jj<results.size();jj++)
        	 {
        		 double dis=DistUtil.euclideanDistSquare(dataSet[ii], results.get(jj));
        		// double dis2=DistUtil.euclideanDistSquare(temp2[ii], temp2[realcenterIds.get(jj)]);
        		 if(dis<min)
        		 {
        			 min=dis;
        			 index1=jj;
        		 }
        	 }*/
        	 for(int jj=0;jj<results.size();jj++)
        	 {
        		// double dis=DistUtil.euclideanDistSquare(dataSet[ii], results.get(jj));
        		 double dis2=DistUtil.euclideanDistSquare_dhd(temp2[ii], temp2[realcenterIds.get(jj)],weight);
        	//	 System.out.println("   ");
        		 if(dis2<min2)
        		 {
        			 last2=index2;
        			 index2=jj;
        			 min2=dis2;
        		 }  
        		 
        	 }
        	// System.out.println("dhd   distance    is   "+min2);
        	// min2=DistUtil.euclideanDistSquare(dataSet[ii], results.get(index2));
        	// double min22=-1;;
        	// if(last2!=-1)
        	  //  min22=DistUtil.euclideanDistSquare(dataSet[ii], results.get(last2));
        	/* if(index1!=index2)
        	 {
        	      System.out.println("   index1       is   "+index1+"    index2      "+index2+"   min2  "+min2+"   min1   "+min+"   last   "+min22);
        	      if(index1!=last2)  
        	        dismatch++;
        	 }
        	 sum2+=min2;
        	 sum1+=min;*/
        	 
         }
         DecimalFormat df = new DecimalFormat("0.000");
         String num = df.format(Math.sqrt(sum2)); 
         System.out.println("    sum 2           is             "+num+"   dismatch   "+dismatch+"  sum1   "+sum1);
       //  double rate=(double)sum/(leaves.size()*(leaves.size()-1)/2);
       //  System.out.println("  prune  rate of nodes    is  "+rate);
         initMap();
         StopWatch stopWatch = new StopWatch();
	     stopWatch.start();
     /*    for(int ii=0;ii<dataSet.length;ii++)
         {
        	 Node leafNode = newroot.approximateSearch(dataSet[ii]);
             IntWritable intWritable = node2IdxMap.get(leafNode);
           //  System.out.println("   label    is   "+intWritable.get());
         }*/
         System.out.println("  time  SEARCH spent   is    "+stopWatch.getTime());
         System.out.println(stringBuilder.toString());
         
      
	}
	
	public double lowerBound(double[] min, double[] max,int start,double[] min2,double[] max2, int[] segmentLength) {
		double sum = 0;

		for (int i = 0; i < min.length; i++) {
			double node1MaxAvg = max[i];
			double node1MinAvg = min[i];

			double node2MaxAvg = max2[i];
			double node2MinAvg = min2[i];

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength[i];
			}
		}

		sum = Math.sqrt(sum);
		return sum;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 KDSTree_Single_tao  KDS=new KDSTree_Single_tao();
		// int size=100000;
		// int tsLength=512;
		 Integer numCenters=Integer.parseInt(args[0]);
		 Integer size=Integer.parseInt(args[1]);
		 segmentLevel=Integer.parseInt(args[2]);
		 threshold=Integer.parseInt(args[3]);
		 tsLength=Integer.parseInt(args[4]);
		 System.out.println("  size  "+size+"   segmentLevel   "+segmentLevel+"   threshold   "+threshold+"  tsLength  is  "+tsLength);
		 StopWatch stopWatch = new StopWatch();
	     stopWatch.start();
		 double[][] dataSet=new double[size][tsLength];
		 int[] indexes=new int[size];
		 for(int ii=0;ii<size;ii++)
		 {
			 indexes[ii]=ii;
		 } 
		 double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\stocks_20", tsLength,size);
		// double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("/home/hadoop/lqh/ucibinary", tsLength,size);
		 KDS.buildTree(timeSeries,numCenters);
		
		 System.out.println("  time  spent   is    "+stopWatch.getTime());
		 System.out.println("  ************************        successfully");
	}
	 private void initMap() throws IOException {
         //first order traverse to visit leaf node
		 newroot = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         NodeUtil.initDSTreeWithKDSTree(root, newroot);
         List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(newroot);
         for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
             Node node = leafNodesByFirstOrder.get(i);
             node2IdxMap.put(node, new IntWritable(i));
         }
     }
}
