package cn.edu.fudan.cs.dstree.hadoop;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import org.apache.commons.lang.time.StopWatch;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
public class Kmeans {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static  int iterationNumber=10;
	public static  int dimension=512;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//int Dimension=1000;
		long start = System.currentTimeMillis();
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Kmeans kp=new Kmeans();
		ArrayList list=new ArrayList();
	//	BufferedReader read1=new BufferedReader(new FileReader("c:\\data\\uci0.txt") );
		int k=100;
		Point point2=new Point();
		//WeightPoint wp=new WeightPoint(1,point2);
		ArrayList<double[]> al = new ArrayList();
		ArrayList<Point> al2 = new ArrayList();
		int count=0;
		String[] eles;
		//int size=268796;
		//int size=12218;
		//int size=11532;
		 Integer numCenters=Integer.parseInt(args[0]);
		 Integer size=Integer.parseInt(args[1]);
		 dimension=Integer.parseInt(args[2]);
		double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\tao_normalize20", dimension,size);
		//double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("/home/hadoop/lqh/ucibinary", dimension,size);
		List<double[]> result=new ArrayList();
		for(int kk=0;kk<k;kk++)
		{
			Random  random=new Random();
			int ran=random.nextInt(size);
			result.add(timeSeries[ran]);
			
		}
		long end = System.currentTimeMillis();
		double res=(end-start);
		System.out.println("Kmeans  Time  spent     is          "+res+"  secs"+"   k    is   "+k);
		//List result=kp.chooseInitialMeans(timeSeries,k);
		//int  nums=Tool.checkDuplication(result2);
		//System.out.println("          nums         is       "+nums);
		double sum1=0.0;
		/*for(int ii=0;ii<timeSeries.length;ii++)
	         {
	        	 double min=Double.MAX_VALUE;
	        	 double min2=Double.MAX_VALUE;
	        	 int index1=-1;
	        	 int index2=-1;
	        	 int last2=-1;
	        	 for(int jj=0;jj<result.size();jj++)
	        	 {
	        		 double dis=DistUtil.euclideanDistSquare(timeSeries[ii], result.get(jj));
	        		// double dis2=DistUtil.euclideanDistSquare(temp2[ii], temp2[realcenterIds.get(jj)]);
	        		 if(dis<min)
	        		 {
	        			 min=dis;
	        			 index1=jj;
	        		 }
	        	 }
	        	
	        	// System.out.println("dhd   distance    is   "+min2);
	        	 sum1+=min;
	         }
	         DecimalFormat df = new DecimalFormat("0.000");
	         String num = df.format(Math.sqrt(sum1)); 
	         System.out.println("    sum          is     "+num);*/
		System.out.println("Time seeding  spent     is          "+res+"  secs"+"   k    is   "+k);
		for(int ii=0;ii<iterationNumber;ii++)
		{
			StopWatch stopWatch22 = new StopWatch();
    	     stopWatch22.start();
			List<double[]> newcenter2=process_iterable(timeSeries,result,ii);
			result=newcenter2;
			System.out.println("  the time  spent    for iteration  "+ii+"   "+stopWatch22.getTime()+"    all  time  from begin   "+stopWatch.getTime());
			 stopWatch22.stop();
		}
		System.out.println("Time  spent     is          "+res+"  secs"+"   k    is   "+k);

	}
	public static List process_iterable(double[][] arrayP,List<double[]> center, int iter)
	{
		//boolean dup=checkDuplication(center);
		List<double[]> res=new ArrayList();
		List weighPoints=new ArrayList();
		
			res=new ArrayList();
			double squareError=0;
			int[] classCount=new int[center.size()];
			List[] pointIn=new ArrayList[center.size()];
			for(int u=0;u<center.size();u++)
			{
				pointIn[u]=new ArrayList();
			}
			double[][] center_sums=new double[center.size()][dimension];
			for(int ii=0;ii<arrayP.length;ii++)
			{
				double[] point2=arrayP[ii];
				double tempDis = 0;
				double minDis = Double.MAX_VALUE;
				int signal = -1;
				for (int j = 0; j < center.size(); j++) {
				    tempDis = DistUtil.euclideanDistSquare(point2, center.get(j));
					if(tempDis < minDis) {
						minDis = tempDis;
						signal = j;
					}
									
				}
				center_sums[signal]=getSum(center_sums[signal],point2);
				squareError=squareError+minDis;
				//��ļ�������1
				classCount[signal]=classCount[signal]+1;
				pointIn[signal].add(point2);
			}
			double[][] center_new=new double[center.size()][dimension];
			for(int i=0;i<center.size();i++)
			{
					if(classCount[i]==0)
					{
						//  only one condition, center is wrong
					//	System.out.println(" ********************      center  is wrong "+"  i   is  "+i+" center is "+((Point)center.get(i)).toString());
					    continue;
					}
					//System.out.println("the   classCount["+ii+"]      is    "+classCount[ii]);
					for(int jj=0;jj<dimension;jj++)
					{
						center_new[i][jj]=center_sums[i][jj]/classCount[i];
						//System.out.println("  center_sums["+ii+"]      is    "+center_sums[ii][0]);
					}
					
			}
			for(int i=0;i<center.size();i++)
			{
					
					
					//System.out.println("    new    center     is   "+point_new.toString());
				//	res.add(point_new);
				//  find the real point closest to wp
					double tempDis=0;
					double minDis = Double.MAX_VALUE;
					int signal = -1;
					for(int u=0;u<pointIn[i].size();u++)
					{
						double[] pp=(double[])pointIn[i].get(u);
						tempDis = DistUtil.euclideanDistSquare(pp, center_new[i]);
						if(tempDis < minDis) {
							minDis = tempDis;
							signal = u;
						}
						
						
					}
					if(signal==-1)
					{
						//System.out.println("  the  size   is  *******   "+pointIn[i].size()+"  i  is  "+i+"   center  is  "+(center.get(14)).toString());
						
					}
					else
					{
						res.add((double[])pointIn[i].get(signal));
					}
				
			}//for
			
			
			{
				System.out.println("   center ***************     size   is  "+center.size());
				System.out.println("Square  error    is    "+Math.sqrt(squareError)+"   iter   number   "+iter);
			}
		
		//remove  duplicate  points
	//	weighPoints=removeDuplicate(weighPoints);
		return res;
	}
	public static double[] getSum(double[] point,double[] previous)
	{
		
		
		for(int ii=0;ii<point.length;ii++)
		{
			//newSum[ii]=newSum[ii]+previous.point.get(ii);
			
			point[ii]=point[ii]+previous[ii];
		}
		return point;
		
	}
	/**
	 * K-Means++ initialization for k-means.
	 * 
	 * Reference:
	 * <p>
	 * D. Arthur, S. Vassilvitskii<br />
	 * k-means++: the advantages of careful seeding<br />
	 * In: Proc. of the Eighteenth Annual ACM-SIAM Symposium on Discrete Algorithms,
	 * SODA 2007
	 * </p>
	 * 
	 * @author Erich Schubert
	 * 
	 * @param <V> Vector type
	 * @param <D> Distance type
	 */
	
	 
	  
	 
	  public List<double[]> chooseInitialMeans(double[][]relation, int k,List<Integer> centers) {
		   
		  
		    // Chose first mean
		    List<double[]> means = new ArrayList<double[]>(k);
	        Random  ran=new Random();
	        Random  random=new Random();
		    int size=relation.length;
		    int randomI=ran.nextInt(size);
		    centers.add(randomI);
		    double[] first =relation[randomI];
		    means.add(first);
		    // Initialize weights
		    System.out.println("first pos   "+randomI);
		    double[] weights = new double[size];
		    double weightsum = initialWeights(weights, relation, first);
		    while(means.size() < k) {
		      if(weightsum > Double.MAX_VALUE) {
		       System.out.println("Could not choose a reasonable mean for k-means++ - too many data points, too large squared distances?");
		      }
		      if(weightsum < Double.MIN_NORMAL) {
		    	 
		    	  System.out.println("Could not choose a reasonable mean for k-means++ - to few data points?");
		    	  //add by lqh to consider there are  less different points
		    	  return means;
		      }
		      double r = random.nextDouble() * weightsum;
		      int pos = 0;
		      while(r > 0 && pos < weights.length) {
		        r -= weights[pos];
		        pos++;
		      }
		      if(pos>0)
		      {
		    	  pos--;
		      }
		      //add by lqh 
		      if(pos>= weights.length)
		    	  pos=weights.length-1;
		      // Add new mean:
		      double[] newmean = relation[pos];
		      centers.add(pos);
		     // System.out.println("   pos     is    "+pos);
		      means.add(newmean);
		      // Update weights:
		      weights[pos] = 0.0;
		      // Choose optimized version for double distances, if applicable.
		    
		        weightsum = updateWeights(weights, relation, newmean);
		      
		    
		    }
	     System.out.println("   weights    sum      is     "+Math.sqrt(weightsum));
		    return means;
		  }
		  
	  public List<Point> chooseInitialMeans_bulk(List<Point> relation, int k,double[] weights) {
		   
		  
		    // Chose first mean
		    List<Point> means = new ArrayList<Point>(k);
	        Random  ran=new Random();
	        Random  random=new Random();
		    int size=relation.size();
		    int randomI=ran.nextInt(size);
		    Point first =relation.get(randomI) ;
		    means.add(first);
		    double weightsum=0.0;
		    for(int ii=0;ii<weights.length;ii++)
		    {
		    	weightsum=weightsum+weights[ii];
		    }
		    while(means.size() < k) {
		      if(weightsum > Double.MAX_VALUE) {
		       System.out.println("Could not choose a reasonable mean for k-means++ - too many data points, too large squared distances?");
		      }
		      if(weightsum < Double.MIN_NORMAL) {
		    	 
		    	  System.out.println("Could not choose a reasonable mean for k-means++ - to few data points?");
		    	  //add by lqh to consider there are  less different points
		    	  return means;
		      }
		      double r = random.nextDouble() * weightsum;
		      int pos = 0;
		      while(r > 0 && pos < weights.length) {
		        r -= weights[pos];
		        pos++;
		      }
		      if(pos>0)
		      {
		    	  pos--;
		      }
		      //add by lqh 
		      if(pos>= weights.length)
		    	  pos=weights.length-1;
		      // Add new mean:
		      Point newmean = relation.get(pos);
		      means.add(newmean);
		      // Update weights:
		      weights[pos] = 0.0;
		      // Choose optimized version for double distances, if applicable.
		    
		         if(weightsum==0.0)
			    {
			    	   System.out.println("    ***********************888  relation size  is "+relation.size());
			       }
		    
		    }
	      //System.out.println("   weights    sum      is     "+weightsum);
		    return means;
		  }
	 

	 /**
	   * Initialize the weight list.
	   * 
	   * @param weights Weight list
	   * @param ids IDs
	   * @param latest Added ID
	   * @param distQ Distance query
	   * @return Weight sum
	   */
	  protected double initialWeights(double[] weights, double[][] ids, double[] latest) {
	    double weightsum = 0.0;
	    for(int i = 0; i < weights.length; i++) {
	      double[] it=ids[i];	
	      if(latest.equals(it)) {
	        weights[i] = 0.0;
	      }
	      else {
	        double d = DistUtil.euclideanDist(latest, it);
	        weights[i] = d * d;
	      }
	      weightsum += weights[i];
	    }
	    return weightsum;
	  }
	  
	 
	  /**
	   * Update the weight list.
	   * 
	   * @param weights Weight list
	   * @param ids IDs
	   * @param latest Added ID
	   * @param distQ Distance query
	   * @return Weight sum
	   */
	
	  
	  protected double updateWeights(double[] weights,  double[][] ids, double[] latest) {
		    double weightsum = 0.0;
		    for(int i = 0; i < weights.length; i++) {
		    	double[] it=ids[i];
		      if(weights[i] > 0.0) {
		        double d = DistUtil.euclideanDist(latest, it);
		        weights[i] = Math.min(weights[i], d * d);
		        weightsum += weights[i];
		      }
		    }
		//   System.out.println("     weightsum           is       "+weightsum);
		    return weightsum;
		  }

}
