package cn.edu.fudan.cs.dstree.hadoop;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

public class KmeansPlusPlus_Linux {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int Dimension = 1000;
		long start = System.currentTimeMillis();
		KmeansPlusPlus_Linux kp = new KmeansPlusPlus_Linux();
		ArrayList list = new ArrayList();
		// BufferedReader read1=new BufferedReader(new
		// FileReader("c:\\data\\uci0.txt") );
		int k = Integer.parseInt(args[0]);
		Point point2 = new Point();
		// WeightPoint wp=new WeightPoint(1,point2);
		ArrayList<double[]> al = new ArrayList();
		ArrayList<Point> al2 = new ArrayList();
		int count = 0;
		String[] eles;
		Integer size = Integer.parseInt(args[1]);
		double[][] timeSeries = TimeSeriesFileUtil
				.readSeriesFromBinaryFileAtOnce("/home/hadoop/lqh/ucibinary",
						1000, size);
		List<double[]> results = kp.chooseInitialMeans(timeSeries, k);
		FileOutputStream fos = new FileOutputStream("/home/hadoop/lqh/centers3");
		BufferedOutputStream bos = new BufferedOutputStream(fos);

		DataOutputStream dos = new DataOutputStream(bos);
		for (int i = 0; i < results.size(); i++) {

			for (int j = 0; j < Dimension; j++) {
				dos.writeDouble(results.get(i)[j]);
				// System.out.println("  double   is   "+tss[j]);

			}
		}
		dos.close();
		bos.close();
		fos.close();

		// int nums=Tool.checkDuplication(result2);
		// System.out.println("          nums         is       "+nums);
		long end = System.currentTimeMillis();
		long res = (end - start) / 1000;
		System.out.println("Time  spent     is          " + res + "  secs"
				+ "   k    is   " + k);

	}

	/**
	 * K-Means++ initialization for k-means.
	 * 
	 * Reference:
	 * <p>
	 * D. Arthur, S. Vassilvitskii<br />
	 * k-means++: the advantages of careful seeding<br />
	 * In: Proc. of the Eighteenth Annual ACM-SIAM Symposium on Discrete
	 * Algorithms, SODA 2007
	 * </p>
	 * 
	 * @author Erich Schubert
	 * 
	 * @param <V>
	 *            Vector type
	 * @param <D>
	 *            Distance type
	 */

	public List<double[]> chooseInitialMeans(double[][] relation, int k) {

		// Chose first mean
		List<double[]> means = new ArrayList<double[]>(k);
		Random ran = new Random();
		Random random = new Random();
		int size = relation.length;
		int randomI = ran.nextInt(size);
		double[] first = relation[randomI];
		means.add(first);
		// Initialize weights
		double[] weights = new double[size];
		double weightsum = initialWeights(weights, relation, first);
		while (means.size() < k) {
			if (weightsum > Double.MAX_VALUE) {
				System.out
						.println("Could not choose a reasonable mean for k-means++ - too many data points, too large squared distances?");
			}
			if (weightsum < Double.MIN_NORMAL) {

				System.out
						.println("Could not choose a reasonable mean for k-means++ - to few data points?");
				// add by lqh to consider there are less different points
				return means;
			}
			double r = random.nextDouble() * weightsum;
			int pos = 0;
			while (r > 0 && pos < weights.length) {
				r -= weights[pos];
				pos++;
			}
			if (pos > 0) {
				pos--;
			}
			// add by lqh
			if (pos >= weights.length)
				pos = weights.length - 1;
			// Add new mean:
			double[] newmean = relation[pos];
			means.add(newmean);
			// Update weights:
			weights[pos] = 0.0;
			// Choose optimized version for double distances, if applicable.

			weightsum = updateWeights(weights, relation, newmean);

		}
		System.out.println("   weights    sum      is     "
				+ Math.sqrt(weightsum));
		return means;
	}

	public List<Point> chooseInitialMeans_bulk(List<Point> relation, int k,
			double[] weights) {

		// Chose first mean
		List<Point> means = new ArrayList<Point>(k);
		Random ran = new Random();
		Random random = new Random();
		int size = relation.size();
		int randomI = ran.nextInt(size);
		Point first = relation.get(randomI);
		means.add(first);
		double weightsum = 0.0;
		for (int ii = 0; ii < weights.length; ii++) {
			weightsum = weightsum + weights[ii];
		}
		while (means.size() < k) {
			if (weightsum > Double.MAX_VALUE) {
				System.out
						.println("Could not choose a reasonable mean for k-means++ - too many data points, too large squared distances?");
			}
			if (weightsum < Double.MIN_NORMAL) {

				System.out
						.println("Could not choose a reasonable mean for k-means++ - to few data points?");
				// add by lqh to consider there are less different points
				return means;
			}
			double r = random.nextDouble() * weightsum;
			int pos = 0;
			while (r > 0 && pos < weights.length) {
				r -= weights[pos];
				pos++;
			}
			if (pos > 0) {
				pos--;
			}
			// add by lqh
			if (pos >= weights.length)
				pos = weights.length - 1;
			// Add new mean:
			Point newmean = relation.get(pos);
			means.add(newmean);
			// Update weights:
			weights[pos] = 0.0;
			// Choose optimized version for double distances, if applicable.

			if (weightsum == 0.0) {
				System.out
						.println("    ***********************888  relation size  is "
								+ relation.size());
			}

		}
		// System.out.println("   weights    sum      is     "+weightsum);
		return means;
	}

	/**
	 * Initialize the weight list.
	 * 
	 * @param weights
	 *            Weight list
	 * @param ids
	 *            IDs
	 * @param latest
	 *            Added ID
	 * @param distQ
	 *            Distance query
	 * @return Weight sum
	 */
	protected double initialWeights(double[] weights, double[][] ids,
			double[] latest) {
		double weightsum = 0.0;
		for (int i = 0; i < weights.length; i++) {
			double[] it = ids[i];
			if (latest.equals(it)) {
				weights[i] = 0.0;
			} else {
				double d = DistUtil.euclideanDist(latest, it);
				weights[i] = d * d;
			}
			weightsum += weights[i];
		}
		return weightsum;
	}

	/**
	 * Update the weight list.
	 * 
	 * @param weights
	 *            Weight list
	 * @param ids
	 *            IDs
	 * @param latest
	 *            Added ID
	 * @param distQ
	 *            Distance query
	 * @return Weight sum
	 */

	protected double updateWeights(double[] weights, double[][] ids,
			double[] latest) {
		double weightsum = 0.0;
		for (int i = 0; i < weights.length; i++) {
			double[] it = ids[i];
			if (weights[i] > 0.0) {
				double d = DistUtil.euclideanDist(latest, it);
				weights[i] = Math.min(weights[i], d * d);
				weightsum += weights[i];
			}
		}
		// System.out.println("     weightsum           is       "+weightsum);
		return weightsum;
	}

}
