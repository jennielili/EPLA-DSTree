package cn.edu.fudan.cs.dstree.hadoop;

public class DSTreeConst {
     public static int length=1000;
}
