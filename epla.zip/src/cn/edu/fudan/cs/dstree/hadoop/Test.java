package cn.edu.fudan.cs.dstree.hadoop;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double wei=getDimWeight(100);
		System.out.println("  wei    is   "+wei);
          
	}
	public static double getDimWeight(int dim) {
        double ret = 1;
        while (dim > 0) {
            ret /= 2;
            dim = (dim - 1) / 2;
        }

        return ret;
    }

}
