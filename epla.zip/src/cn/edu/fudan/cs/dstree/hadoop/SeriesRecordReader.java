package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Created by wangyang on 14-2-15.
 */
public class SeriesRecordReader extends RecordReader<LongWritable, DoublesWritable> {
    int fixedSize;
    LongWritable key;
    DoublesWritable value;
    long start;
    long end;
    long pos;
    private boolean done = false;
    private FSDataInputStream fsDataInputStream;

    public SeriesRecordReader(int tsLength) {
        this.fixedSize = tsLength * 8+4+4+4;//in bytes
    }

    @Override
    public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
        Path path = ((FileSplit) split).getPath();
        System.out.println("path = " + path);
        Configuration conf = context.getConfiguration();
        FileSystem fs = path.getFileSystem(conf);
        fsDataInputStream = fs.open(path);

        this.start = ((FileSplit) split).getStart();
        pos = start;
        this.end = ((FileSplit) split).getStart() + split.getLength();
        System.out.println("start = " + start);
        System.out.println("end = " + end);
        System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());
        if (start != 0) {
            long offset = start % fixedSize;
            if (offset > 0) {
                System.out.println("offset = " + offset);
            }
            start -= offset;
            fsDataInputStream.seek(start);
        }
        System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());

        done = fsDataInputStream.getPos() + fixedSize > end;
    }

    @Override
    public boolean nextKeyValue() throws IOException, InterruptedException {
        done = (fsDataInputStream.getPos() + fixedSize) > end;
        if (done) {
            System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());
            System.out.println("fsDataInputStream.getPos() + fixedSize =" + (fsDataInputStream.getPos() + fixedSize));
            System.out.println("end = " + end);
            return false;
        }

        pos = fsDataInputStream.getPos(); //start from 0
        int size=fsDataInputStream.readInt();
        key = new LongWritable(pos);
        byte[] buffer = new byte[fixedSize-12];
       
        fsDataInputStream.readFully(buffer);
        int from=fsDataInputStream.readInt();
        int id=fsDataInputStream.readInt();
        double[] ts = new double[buffer.length / 8];
//        DoubleBuffer.wrap(ts).
        ByteBuffer.wrap(buffer).asDoubleBuffer().get(ts);
        value = new DoublesWritable(from,id,ts);
        return true;
    }

    @Override
    public LongWritable getCurrentKey() throws IOException, InterruptedException {
        return key;
    }

    @Override
    public DoublesWritable getCurrentValue() throws IOException, InterruptedException {
        return value;
    }

    @Override
    public float getProgress() throws IOException, InterruptedException {
        if (end == start) {
            return 0.0f;
        } else {
            return Math.min(1.0f, (float) ((fsDataInputStream.getPos() - start) /
                    (double) (end - start)));
        }
    }

    @Override
    public void close() throws IOException {
        fsDataInputStream.close();
    }
}
