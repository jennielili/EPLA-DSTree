package cn.edu.fudan.cs.dstree.hadoop;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Reducer.Context;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;
import java.io.IOException;
import java.util.*;

/**
 * Reduecer for KDS Search
 * 
 * @author Qli
 */
public class KDS_Search_Reducer extends
		Reducer<IntWritable, DoublesWritable, LongWritable, DoubleWritable> {
	Node root;
	private int tsLength = 1000;
	private int threshold;
	private int currentKey;
	/*
	 * @Override protected void setup(Context context) throws IOException,
	 * InterruptedException { super.setup(context); root =
	 * readTheRouteInfo(context); }
	 */
	public Node readTheRouteInfo(TaskInputOutputContext context, int k)
			throws IOException {
		Configuration conf = context.getConfiguration();
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path("index/subIndex_" + k + ".idx");
		if (!fs.exists(path)) {
			throw new IOException("route file not exists!");
		}
		FSDataInputStream fsDataInputStream = fs.open(path);
		FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
		KDSTreeNode kdsTreeNode;
		try {
			root = (Node) in.readObject(Node.class);
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		in.close();
		fsDataInputStream.close();
		return root;
	}

	protected void reduce(
			IntWritable key,
			java.lang.Iterable<DoublesWritable> vals,
			org.apache.hadoop.mapreduce.Reducer<IntWritable, DoublesWritable, LongWritable, DoubleWritable>.Context context)
			throws java.io.IOException, InterruptedException {
		Configuration conf = context.getConfiguration();
		FileSystem fs = FileSystem.get(conf);
		HashMap<Integer, double[][]> hm = new HashMap();
		Path path = new Path("data/subData_" + key.get() + ".bin");
		if (!fs.exists(path)) {
			throw new IOException("data file not exists!");
		}
		FSDataInputStream fsDataInputStream = fs.open(path);
		root = readTheRouteInfo(context, key.get());
		List<double[][]> doubleLists = new ArrayList();
		List<Node> leafNodesByFirstOrder = NodeUtil
				.getLeafNodesByFirstOrder(root);
		for (int ii = 0; ii < leafNodesByFirstOrder.size(); ii++) {
			Node node = leafNodesByFirstOrder.get(ii);
			int k = node.getSize();
			double[][] temp = new double[node.getSize()][tsLength];
			for (int jj = 0; jj < k; jj++) {
				for (int t = 0; t < tsLength; t++)
					temp[jj][t] = fsDataInputStream.readDouble();
			}
			Integer it = new Integer(node.getId());
			hm.put(it, temp);
			System.out.println(" *******   key    is    "+key.get()+"*****  id   is   "+it+"   size   is   "+temp.length);
		}

		// get the data file by name

		for (DoublesWritable val : vals) {
			double[] doubles = val.getDoubles();
			Node leafNode = root.approximateSearch(doubles);
			Integer kk = new Integer(leafNode.getId());
			double temp[][] = hm.get(kk);
			double[] query = val.getDoubles();
			double min = Double.MAX_VALUE;
			int pos = -1;
			for (int tt = 0; tt < temp.length; tt++) {
				double distance = DistUtil.euclideanDist(query, temp[tt]);
				if (distance < min) {
					min = distance;
					pos = tt;
				}
			}
			System.out.println("query  is  " + val.getId()
					+ " the id of leafNode   is  " + leafNode.getId()
					+ "   pos   is  " + pos + "  distance   is  " + min
					+ "   the number of node   is  " + temp.length);
			context.write(new LongWritable(val.getId()),
					new DoubleWritable(min));
		}

	}
}
