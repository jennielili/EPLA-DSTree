package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;
import java.util.Date;

/**
 * Created by wangyang on 14-1-31.
 */
public class WholeTimeSeriesSplitRecordReader extends RecordReader<NullWritable, DoublesWritable> {
    private static final Log log = LogFactory.getLog(WholeTimeSeriesSplitRecordReader.class);

    private FileSplit split;
    private Configuration conf;
    private DoublesWritable value;
    private long length;
    private long start;

    public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
        log.info(" cn.edu.fudan.cs.dstree.hadoop.WholeTimeSeriesSplitRecordReader.initialize");
        //System.out.println("split.getLocations()[0] = " + split.getLocations()[0]);
        processed = false;
        this.split = (FileSplit) split;
        this.conf = context.getConfiguration();
        length = split.getLength();
        log.info("split.getLength() = " + split.getLength());
        start = ((FileSplit) split).getStart();
        log.info("((FileSplit) split).getStart() = " + ((FileSplit) split).getStart());
    }

    @Override
    public NullWritable getCurrentKey() throws IOException, InterruptedException {
        return NullWritable.get();
    }

    @Override
    public DoublesWritable getCurrentValue() throws IOException, InterruptedException {
        return value;
    }

    /**
     * Read raw bytes from a SequenceFile.
     */
    public synchronized boolean nextKeyValue() throws IOException, InterruptedException {
        if (!processed) {
            Path file = split.getPath();
            FileSystem fs = file.getFileSystem(conf);
            FSDataInputStream is = null;
            try {
                is = fs.open(file);
                is.seek(start);
                int len = (int) (length / 8);
                log.debug("len = " + len);
                double[] data = new double[len];
                for (int i = 0; i < data.length; i++) {
                    data[i] = is.readDouble();
                }

                value = new DoublesWritable(data);
            } finally {
                IOUtils.closeStream(is);
            }

            processed = true;
            return true;
        }

        return false;
    }

    public void close() throws IOException {

    }

    boolean processed;

    /**
     * Return the progress within the input split
     *
     * @return 0.0 to 1.0 of the input byte range
     */
    public float getProgress() throws IOException, InterruptedException {
        return processed ? 1.0f : 0;
    }
}
