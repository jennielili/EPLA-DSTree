package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.io.*;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
public class DoublesWritable implements Writable {
    private static final double[] EMPTY_DOUBLES = {};

    private int size=1000;
    public int getFrom() {
		return from;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	private int from=0;
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int id;
   

	private double[] doubles;

    public DoublesWritable() {
        
    }

    public DoublesWritable(int from,int id,double[] doubles) {
    	this.from=from;
    	this.id=id;
        this.doubles = doubles;
        this.size = doubles.length;
    }

    public double[] getDoubles() {
        double[] ret = new double[size];
        System.arraycopy(doubles,0,ret,0,size);
        return ret;
    }

    public int getLength() {
        return size;
    }

    public void setSize(int size) {
        if (size > getCapacity()) {
            setCapacity(size * 3 / 2);
        }
        this.size = size;
    }

    public int getCapacity() {
        return doubles.length;
    }

    public void setCapacity(int new_cap) {
        if (new_cap != getCapacity()) {
            double[] new_data = new double[new_cap];
            if (new_cap < size) {
                size = new_cap;
            }
            if (size != 0) {
                System.arraycopy(doubles, 0, new_data, 0, size);
            }
            doubles = new_data;
        }
    }

    public void set(DoublesWritable newData) {
        set(newData.doubles, 0, newData.size);
    }

    public void set(double[] newData, int offset, int length) {
        setSize(0);
        setSize(length);
        System.arraycopy(newData, offset, doubles, 0, size);
    }

    // inherit javadoc
    public void readFields(DataInput in) throws IOException {
       // setSize(0); // clear the old data
        
        size=in.readInt();
        doubles=new double[size];
       // setSize(in.readInt());
        
    //    System.out.println("  id   is  "+id+"    size    i   "+size);
       
        for (int i = 0; i < size; i++) {
            doubles[i] = in.readDouble();
        }
        
        from=in.readInt();
    	id=in.readInt();
    }

    // inherit javadoc
    public void write(DataOutput out) throws IOException {
    	
    	out.writeInt(size);
        for (int i = 0; i < size; i++) {
            out.writeDouble(doubles[i]);
        }
        
        out.writeInt(from);
        out.writeInt(id);
    }

    public int hashCode() {
        return super.hashCode();
    }

    /**
     * Are the two byte sequences equal?
     */
    public boolean equals(Object right_obj) {
        if (right_obj instanceof DoublesWritable)
            return super.equals(right_obj);
        return false;
    }
}
