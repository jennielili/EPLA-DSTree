package cn.edu.fudan.cs.dstree.hadoop;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Mapper.Context;

import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;

import java.util.*;
import java.io.IOException;
import java.math.*;
/**
 * Mapper for KDSTree Search
 * 
 * @author  Qli
 * 
 */
public class KDS_Search_Mapper extends Mapper<Object, Text, IntWritable, DoublesWritable> {

	 Node root;
	 private int tsLength=1000;
     private int threshold;
     private int leafNodesSize;
     HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	@Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        root = readTheRouteInfo(context);
        List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
        for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
            Node node = leafNodesByFirstOrder.get(i);
            node2IdxMap.put(node, new IntWritable(i));
        }
        leafNodesSize=leafNodesByFirstOrder.size();
    }
	 public Node readTheRouteInfo(TaskInputOutputContext context) throws IOException {
         Configuration conf = context.getConfiguration();
         FileSystem fs = FileSystem.get(conf);
         Path path = new Path("cluster2-routeTree/KDSTree.data");

         if (!fs.exists(path)) {
             throw new IOException("route file not exists!");
         }
         FSDataInputStream fsDataInputStream = fs.open(path);
         FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
         KDSTreeNode kdsTreeNode;
         try {
             kdsTreeNode = (KDSTreeNode) in.readObject(KDSTreeNode.class);
         } catch (Exception e) {
             throw new IOException(e.getMessage());
         }
         in.close();
         fsDataInputStream.close();
         Node root = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         NodeUtil.initDSTreeWithKDSTree(kdsTreeNode, root);
         NodeUtil.clearAllStatistics(root);
         return root;
     }
	 private void initMap() {
         //first order traverse to visit leaf node
        
     }
	protected void map(
    		Object key,
	    Text value,
	    org.apache.hadoop.mapreduce.Mapper<Object, Text, IntWritable, DoublesWritable>.Context context)
	    throws java.io.IOException, InterruptedException {
    	if(value==null || value.equals(""))
    	    	return;
        String aaa=value.toString();
        if(aaa.equals(""))
    	    	return;
        Random random=new Random();
    	Integer ran=random.nextInt(6);
    	String[] temps=value.toString().split("\t");
    	String[] items=temps[1].split(" ");
    	int id=Integer.parseInt(temps[0]);
    	if(items.length<=0)
    		return;
    	double[] doubles=new double[items.length];
    	for(int ii=0;ii<items.length;ii++)
    	{
    		doubles[ii]=Double.parseDouble(items[ii]);
    	}
    	DoublesWritable dw=new DoublesWritable(0,id,doubles);
        Node leafNode = root.approximateSearch(doubles);
        IntWritable intWritable = node2IdxMap.get(leafNode);
        int  aa=intWritable.get();
        context.write(new IntWritable(aa), dw);
        for(int i=1;i<80;i++)
        {
    	   if(aa-i>0)
    		   context.write(new IntWritable(aa-i), dw);
    	   if(aa+i<leafNodesSize)
    		   context.write(new IntWritable(aa+i), dw);
        	
        }
       // System.out.println("id   "+intWritable.get()+" query id  "+dw.getId());
        context.write(intWritable, dw);
		
    }
   
}
