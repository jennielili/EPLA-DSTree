package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.ByteWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;

/**
 * Created by wangyang on 14-1-25.
 */
public class ByteRecordReader extends RecordReader<LongWritable, ByteWritable> {
    private long start;
    private long end;
    private boolean done = false;
    private LongWritable key = null;
    private ByteWritable value = null;
    private FSDataInputStream fsDataInputStream;
    private long pos;

    public void initialize(InputSplit split, TaskAttemptContext context)
            throws IOException, InterruptedException {
        System.out.println("com.justonetech.example.hadoop.ByteRecordReader.initialize");
        Path path = ((FileSplit)split).getPath();
        System.out.println("path = " + path);
        Configuration conf = context.getConfiguration();
        FileSystem fs = path.getFileSystem(conf);
        fsDataInputStream = fs.open(path);
        this.start = ((FileSplit)split).getStart();
        this.pos = start;
        this.end = ((FileSplit)split).getStart() + split.getLength();
        System.out.println("start = " + start);
        System.out.println("end = " + end);
        fsDataInputStream.seek(start);
        done = pos >= end;
    }

    @Override
    public LongWritable getCurrentKey()
            throws IOException, InterruptedException {
        return key;
    }

    @Override
    public ByteWritable getCurrentValue()
            throws IOException, InterruptedException {
        return value;
    }

    /**
     * Read raw bytes from a SequenceFile.
     */
    public synchronized boolean nextKeyValue()
            throws IOException, InterruptedException {
        pos = fsDataInputStream.getPos();
        done = pos >= end;
        if (done) {
            return false;
        }
        key = new LongWritable(pos);
        value = new ByteWritable(fsDataInputStream.readByte());
        return true;
    }

    public void close() throws IOException {
        fsDataInputStream.close();
    }

    /**
     * Return the progress within the input split
     * @return 0.0 to 1.0 of the input byte range
     */
    public float getProgress() throws IOException, InterruptedException {
        if (end == start) {
            return 0.0f;
        } else {
            return Math.min(1.0f, (float) ((fsDataInputStream.getPos() - start) / (double) (end - start)));
        }
    }

}
