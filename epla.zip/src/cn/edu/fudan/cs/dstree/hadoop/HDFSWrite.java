package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.Date;

/**
 * Created by wangyang on 14-2-28.
 */
public class HDFSWrite {
    public static void main(String[] args) throws IOException {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        String outputPath = "hdfs-write-test";
        if (otherArgs.length > 0)
            outputPath = otherArgs[0];

        System.out.println("outputPath = " + outputPath);
        String fileName1 = "b32m_rep3.data";
        String fileName2 = "b128m_rep1.data";

        Path path1 = new Path(outputPath + "/" + fileName1);
        FileSystem fileSystem = FileSystem.get(conf);
        if (fileSystem.exists(path1)) {
            fileSystem.delete(path1, true);
        }

        writeFile(path1, 32 * 1024 * 1024, (short) 3);

        Path path2 = new Path(outputPath + "/" + fileName2);
        if (fileSystem.exists(path2)) {
            fileSystem.delete(path2, true);
        }

        writeFile(path2, 128 * 1024 * 1024, (short) 1);
    }

    public static void writeFile(Path file, long blockSize, short replication) throws IOException {
        Configuration conf = new Configuration();
//        conf.setInt("dfs.replication", replication);
        //dfs.block.size=2147483648
        FileSystem fs = FileSystem.get(conf);
        int bufferSize = 8 * 1024 * 1024;
        FSDataOutputStream fsDataOutputStream1 = fs.create(file, true, bufferSize, replication, blockSize);

        for (int i = 0; i < 1024 * 1024 * 10; i++) {
            fsDataOutputStream1.writeDouble(i);
        }
        fsDataOutputStream1.close();
    }
}
