package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;

/**
 * Created by wangyang on 14-2-9.
 */
public class HdfsReader {
    public static NumberFormat formatter = new DecimalFormat("#0.00");
    public static void main(String[] args) throws IOException {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        Path file = new Path(otherArgs[0]);
        FileSystem fs = FileSystem.get(conf);
        FSDataInputStream fis = fs.open(file);

        System.out.println(new Date() + "start read ..." + file.toUri());
        long totalRead = 0;
        int bufferSize = 1024 * 1024 * 4;  //4M
        long outputSize = bufferSize * 128; //512M
        byte[] buffer = new byte[bufferSize];
        int readCount = bufferSize;
        long t1 = System.currentTimeMillis();
        long t2;
        long lastPos = 0;

        while (readCount == bufferSize)
        {
            readCount = fis.read(buffer);
            totalRead += readCount;

            if (totalRead % outputSize == 0)
            {
                t2 = System.currentTimeMillis();
                double l = (t2 - t1) / 1000.0;
                long count = totalRead - lastPos;
                double speed = count / (1024 * 1024) / l;
                System.out.println(new Date() + " read to " + totalRead + " cost:" + formatter.format(l) + "s " + " speed:" + formatter.format(speed) + "MB/s");
                t1 = System.currentTimeMillis();
                lastPos = totalRead;
            }
        }

        System.out.println(new Date() + "finish read ..." + file.toUri());
    }
}
