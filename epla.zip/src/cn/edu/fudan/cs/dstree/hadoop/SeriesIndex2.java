package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.dynamicsplit.*;
import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by wangyang on 14-1-26.
 */
public class SeriesIndex2 {
    private static final Log log = LogFactory.getLog(SeriesIndex2.class);
    static int tsLength = 128;
    static int threshold = 100;
    public static String outputRouteDir = "outputRoute";
    public static String routeFileName = "routeTree.data";
    public static String indexFilePath = "outputIndex";
    public static String indexDataPath = "outputData";

    public static Node readTheRouteInfo(TaskInputOutputContext context) throws IOException {
        Node root;
        Configuration conf = context.getConfiguration();
        FileSystem fs = FileSystem.get(conf);
        Path outFile = new Path(outputRouteDir + "/" + routeFileName);
        if (!fs.exists(outFile)) {
            throw new IOException("route file not exists!");
        }
        FSDataInputStream fsDataInputStream = fs.open(outFile);
        FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
        try {
            root = (Node) in.readObject(Node.class);
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        }
        in.close();
        fsDataInputStream.close();
        log.info("root.getSize():" + root.getSize());
        return root;
    }

    public static class SeriesRouteMapper extends Mapper<NullWritable, DoublesWritable, IntWritable, DoublesWritable> {
        Node root;
        HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();

        private void initMap() {
            //first order traverse to visit leaf node
            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
                Node node = leafNodesByFirstOrder.get(i);
                node2IdxMap.put(node,new IntWritable(i));
            }
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            //read the route info
            root = readTheRouteInfo(context);
            initMap();
            log.info("node2IdxMap.size() = " + node2IdxMap.size());
            log.info("SeriesIndexMapper setup ...");
        }

        @Override
        protected void map(NullWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            double[] timeSeries = value.getDoubles();

            log.info("timeSeries.length = " + timeSeries.length);

            int size = timeSeries.length / tsLength;
            for (int i = 0; i < size; i++) {
                double[] ts = new double[tsLength];
                System.arraycopy(timeSeries, i * tsLength, ts, 0, tsLength);
                Node leafNode = root.approximateSearch(ts);
                IntWritable intWritable = node2IdxMap.get(leafNode);
                context.write(intWritable, new DoublesWritable(ts));
                if (i % 10000 == 0)
                    System.out.println(new Date() + " count = " + i);
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            log.info("SeriesIndexMapper cleanup ...");

            log.info("SeriesIndexMapper cleanup finished!");
            super.cleanup(context);
        }
    }

    public static class SubTreeReducer extends Reducer<IntWritable, DoublesWritable, Text, LongWritable> {
        private LongWritable result = new LongWritable();
        Node root;
        HashMap<IntWritable, Node> idx2NodeMap = new HashMap<IntWritable, Node>();

        private void initMap() {
            //first order traverse to visit leaf node
            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
                Node node = leafNodesByFirstOrder.get(i);
                idx2NodeMap.put(new IntWritable(i),node);
            }
            log.info("idx2NodeMap.size() = " + idx2NodeMap.size());
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            //read the route info
            root = readTheRouteInfo(context);
//            initMap();
            initRoot();

            log.info("SubTreeReducer setup ...");
        }

        private void initRoot() throws IOException {
            //create new Root from RouteTree
            FileBufferManager.fileBufferManager = null;
            FileBufferManager.getInstance().tsLength = tsLength;
            FileBufferManager.getInstance().setBufferedMemorySize(-1);//unlimited
            FileBufferManager.getInstance().setThreshold(threshold);

            //init helper class instances
            INodeSegmentSplitPolicy[] nodeSegmentSplitPolicies = new INodeSegmentSplitPolicy[2];
            nodeSegmentSplitPolicies[0] = new MeanNodeSegmentSplitPolicy();
            nodeSegmentSplitPolicies[1] = new StdevNodeSegmentSplitPolicy();
            root.setNodeSegmentSplitPolicies(nodeSegmentSplitPolicies);

            MeanStdevSeriesSegmentSketcher seriesSegmentSketcher = new MeanStdevSeriesSegmentSketcher();
            root.setSeriesSegmentSketcher(seriesSegmentSketcher);
            root.setNodeSegmentSketchUpdater(new MeanStdevNodeSegmentSketchUpdater(seriesSegmentSketcher));

            root.setRange(new MeanStdevRange());

            //clear all statistics include set size to 0
            NodeUtil.clearAllStatistics(root);
        }

        public void reduce(IntWritable key, Iterable<DoublesWritable> values, Context context) throws IOException, InterruptedException {
            System.out.println("cn.edu.fudan.cs.dstree.hadoop.SeriesIndex2.SubTreeReducer.reduce");

//            Node node = idx2NodeMap.get(key);

            long count = 0;
            for (DoublesWritable val : values) {
                double[] doubles = val.getDoubles();
                root.insert(doubles);
                count++;
                if (count % 10000 == 0)
                    log.info(count);
            }

            //save the file index and data
            Configuration conf = context.getConfiguration();
            FileSystem fs = FileSystem.get(conf);

            String subIndexFileName = "subIndex_" + key.get() + ".idx";
            Path outFile = new Path(indexFilePath + "/" + subIndexFileName);
            if (fs.exists(outFile)) {
                log.info("delete subindex ...");
                fs.delete(outFile, true);
            }
            FSDataOutputStream fsDataOutputStream = fs.create(outFile);
            log.info(outFile.toUri() + " is created!");
            FSTObjectOutput out = new FSTObjectOutput(fsDataOutputStream);
            out.writeObject(root);
            out.close(); // required !
            fsDataOutputStream.close();
            //save data
            String subDataFileName = "subData_" + key.get() + ".bin";
            Path outDataFile = new Path(indexDataPath + "/" + subDataFileName);
            if (fs.exists(outDataFile)) {
                log.info("delete subData ...");
                fs.delete(outDataFile, true);
            }
            FSDataOutputStream fsDataOutputStream1 = fs.create(outDataFile);
            log.info(outDataFile.toUri() + " is created!");

            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
                Node node = leafNodesByFirstOrder.get(i);
                String fileName = node.getFileName();
                FileBuffer fileBuffer = FileBufferManager.getInstance().getFileBuffer(fileName);
                List<double[]> allTimeSeries = fileBuffer.getAllTimeSeries();

                for (int j = 0; j < allTimeSeries.size(); j++) {
                    double[] doubles = allTimeSeries.get(j);
                    for (int k = 0; k < doubles.length; k++) {
                        double aDouble = doubles[k];
                        fsDataOutputStream1.writeDouble(aDouble);
                    }
                }
            }
            fsDataOutputStream1.close();
            log.info(outDataFile.toUri() + " write finished!");

            result.set(count);
            Text text = new Text(key.get() + "");
            context.write(text, result);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        conf.setLong("mapred.map.tasks", 20);

        if (otherArgs.length < 2) {
            System.err.println("Usage: seriesIndex <in> <out> [outputRouteDir] [routeFileName]");
            System.exit(2);
        }

        if (otherArgs.length >= 3)
            SeriesIndex2.outputRouteDir = otherArgs[2];

        log.info("SeriesIndex2.outputRouteDir = " + SeriesIndex2.outputRouteDir);

        if (otherArgs.length >= 4)
            SeriesIndex2.routeFileName = otherArgs[3];
        log.info("SeriesIndex2.routeFileName = " + SeriesIndex2.routeFileName);

        if (otherArgs.length >= 5)
            SeriesIndex2.indexFilePath = otherArgs[4];
        log.info("SeriesIndex2.indexFilePath = " + SeriesIndex2.indexFilePath);

        if (otherArgs.length >= 6)
            SeriesIndex2.indexDataPath = otherArgs[5];
        log.info("SeriesIndex2.indexDataPath = " + SeriesIndex2.indexDataPath);

        Job job = new Job(conf, "series point count");
        job.setNumReduceTasks((int) (4*8*0.75));
        job.setInputFormatClass(WholeTimeSeriesSplitInputFormat.class);
        job.setJarByClass(SeriesIndex2.class);
        job.setMapperClass(SeriesRouteMapper.class);
        job.setMapOutputKeyClass(IntWritable.class);
        //job.setCombinerClass(SumReducer.class);
        job.setMapOutputValueClass(DoublesWritable.class);//it's very necessary
        job.setReducerClass(SubTreeReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[1]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}