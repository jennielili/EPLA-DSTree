/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.data.*;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.Progressable;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Generate the official terasort input data set.
 * The user specifies the number of rows and the output directory and this
 * class runs a map/reduce program to generate the data.
 * The format of the data is:
 * <ul>
 * <li>(10 bytes key) (10 bytes rowid) (78 bytes filler) \r \n
 * <li>The keys are random characters from the set ' ' .. '~'.
 * <li>The rowid is the right justified row id as a int.
 * <li>The filler consists of 7 runs of 10 characters from 'A' to 'Z'.
 * </ul>
 * <p/>
 * <p/>
 * To run the program:
 * <b>bin/hadoop jar hadoop-examples-*.jar teragen 10000000000 in-dir</b>
 */


public class TimeSeriesGen_fromText extends Configured implements Tool {

      /**
     * The Mapper class that given a row number, will generate the appropriate
     * output line.
     */
    public static class TimeSeriesGenMapper extends MapReduceBase
            implements Mapper<Object, Text, NullWritable, DoublesWritable> {
        RandomSeriesGenerator randomSeriesGenerator;

         public void map(Object,Text,
                        OutputCollector<NullWritable, DoublesWritable> output,
                        Reporter reporter) throws IOException {
            double[] series = randomSeriesGenerator.generate();
            series = CalcUtil.z_Normalize(series);

            DoublesWritable value = new DoublesWritable(series);
            output.collect(NullWritable.get(), value);
        }
    }

    public static class DoublesFileOutputFormat extends FileOutputFormat<NullWritable,DoublesWritable>
    {
        @Override
        public RecordWriter<NullWritable, DoublesWritable> getRecordWriter(FileSystem ignored, JobConf job, String name, Progressable progress) throws IOException {
            Path file = FileOutputFormat.getTaskOutputPath(job, name);
            FileSystem fs = file.getFileSystem(job);
            FSDataOutputStream fileOut = fs.create(file, progress);
            return new DoublesRecordWriter(fileOut);
        }

        static class DoublesRecordWriter implements RecordWriter<NullWritable,DoublesWritable>
        {
            protected DataOutputStream out;

            DoublesRecordWriter(DataOutputStream out) {
                this.out = out;
            }

            @Override
            public void write(NullWritable key, DoublesWritable value) throws IOException {
                double[] doubles = value.getDoubles();
                for (int i = 0; i < doubles.length; i++) {
                    double aDouble = doubles[i];
                    out.writeDouble(aDouble);
                }
            }

            @Override
            public void close(Reporter reporter) throws IOException {
                out.close();
            }
        }
    }

    /**
     * @param args the cli arguments
     */
    public int run(String[] args) throws IOException {
        JobConf job = (JobConf) getConf();
        setNumberOfRows(job, Long.parseLong(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        job.setJobName("TimeSeriesGen_fromText");
        job.setJarByClass(TimeSeriesGen_fromText.class);
        job.setMapperClass(TimeSeriesGenMapper.class);
        job.setNumReduceTasks(0);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
      //  job.setInputFormat(RangeInputFormat.class);
        job.setOutputFormat(DoublesFileOutputFormat.class);
        JobClient.runJob(job);
        return 0;
    }

    public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new JobConf(), new TimeSeriesGen_fromText(), args);
        System.exit(res);
    }
}
