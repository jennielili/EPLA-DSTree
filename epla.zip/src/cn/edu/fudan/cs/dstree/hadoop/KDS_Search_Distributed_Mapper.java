package cn.edu.fudan.cs.dstree.hadoop;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.Mapper.Context;

import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import de.ruedigermoeller.serialization.FSTObjectInput;

import java.util.*;
import java.io.IOException;
import java.math.*;

/**
 * Mapper for KDSTree Search
 * 
 * @author  Qli
 * 
 */
public class KDS_Search_Distributed_Mapper extends Mapper<Object, Text, IntWritable, DoublesWritable> {

	 Node root;
	 private int tsLength=1000;
     private int threshold;
     HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	 protected void map(
    		Object key,
	    Text value,
	    org.apache.hadoop.mapreduce.Mapper<Object, Text, IntWritable, DoublesWritable>.Context context)
	    throws java.io.IOException, InterruptedException {
    	if(value==null || value.equals(""))
    	    	return;
        String aaa=value.toString();
        if(aaa.equals(""))
    	    	return;
        Random random=new Random();
    	String[] temps=value.toString().split("\t");
    	String[] items=temps[1].split(" ");
    	int id=Integer.parseInt(temps[0]);
    	if(items.length<=0)
    		return;
    	double[] doubles=new double[items.length];
    	for(int ii=0;ii<items.length;ii++)
    	{
    		doubles[ii]=Double.parseDouble(items[ii]);
    	}
    	DoublesWritable dw=new DoublesWritable(0,id,doubles);
      
       for(int ii=0;ii<10;ii++)
       {
    	   context.write(new IntWritable(ii), dw);
       }
    }
   
}
