package cn.edu.fudan.cs.dstree.hadoop;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import de.ruedigermoeller.serialization.FSTObjectOutput;
import org.apache.commons.lang.math.IntRange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.*;

/**
 * Created by wangyang on 14-1-26.
 */
public class KDSTreeBuilder {
    private static final Log log = LogFactory.getLog(KDSTreeBuilder.class);

    public static final String KDS_SEGMENT_LEVEL = "KDSTreeBuilder.Kds.Segment.Level";
    private static final String KDS_THRESHOLD = "KDSTreeBuilder.Kds.Threshold";
    private static final String KDS_ROUTE_OUTPUT = "KDSTreeBuilder.Kds.Route.Output";
    private static final String KDS_SAMPLE_RATE = "KDSTreeBuilder.Kds.Sample";


    public static class SegmentInfoCollectMapper extends Mapper<LongWritable, DoublesWritable, NullWritable, DoublesWritable> {
        int segmentLevel = 3;
        int tsLength = 1000;
        List<IntRange> segments;
        float sampleRate;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            log.info("cn.edu.fudan.cs.dstree.hadoop.KDSTreeBuilder.SegmentInfoCollectMapper.setup");
            super.setup(context);
            segmentLevel = context.getConfiguration().getInt(KDS_SEGMENT_LEVEL, 3);
            tsLength = context.getConfiguration().getInt(SeriesInputFormat.SeriesInputFormatTsLength, 128);
            sampleRate = context.getConfiguration().getFloat(KDS_SAMPLE_RATE, 0.1f);
            System.out.println("sampleRate = " + sampleRate);
            segments = CalcUtil.generateSplitRanges(tsLength, segmentLevel);
            log.info("segments.size() = " + segments.size());
        }

        @Override
        protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            Random random = new Random();
            if (random.nextDouble() <= sampleRate) {
                double[] ts = value.getDoubles();
                double[] means = new double[segments.size()];
                for (int i = 0; i < segments.size(); i++) {
                    IntRange intRange = segments.get(i);
                    int start = intRange.getMinimumInteger();
                    int end = intRange.getMaximumInteger();
                 //   System.out.println("  start   is  "+start+"   end   is   "+end);
                    double avg = CalcUtil.avg(ts, start, end);
                    means[i] = avg;
                }
                context.write(NullWritable.get(), new DoublesWritable(0,value.getId(),means));
                System.out.println("   in map   id   is  "+value.getId());
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            log.info("SegmentInfoCollectMapper cleanup ...");
            super.cleanup(context);
        }
    }

    public static class KDSTreeReducer extends Reducer<NullWritable, DoublesWritable, NullWritable, Text> {
        int segmentLevel = 3;
        List<double[]> dataList;
        int dimCount;
        int threshold;
        int tsLength;
        private float sampleRate;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
           tsLength = context.getConfiguration().getInt(SeriesInputFormat.SeriesInputFormatTsLength, 128);
            segmentLevel = context.getConfiguration().getInt(KDS_SEGMENT_LEVEL, 3);
            System.out.println("segmentLevel = " + segmentLevel);
            sampleRate = context.getConfiguration().getFloat(KDS_SAMPLE_RATE, 0.1f);
            threshold = context.getConfiguration().getInt(KDS_THRESHOLD, 3);
            threshold = (int) (threshold * sampleRate);
            System.out.println("threshold = " + threshold);

            dimCount = CalcUtil.generateSplitRanges(tsLength, segmentLevel).size();

            dataList = new ArrayList<double[]>(10240);
        }

        @Override
        protected void reduce(NullWritable key, Iterable<DoublesWritable> values, Context context) throws IOException, InterruptedException {
            System.out.println("  in reduce  ***************  ");
        	for (DoublesWritable next : values) {
        	//	System.out.println("   id     "+next.getId()+"  vlaue   10  "+next.getDoubles()[10]);
                dataList.add(next.getDoubles());
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            super.cleanup(context);
            log.info("begin build kds-tree ...");
            double[][] dataSet = dataList.toArray(new double[dataList.size()][]);
            System.out.println(" the length  of dataset  is  "+dataSet.length);
            int [] indexes=new int[dataSet.length];
   		    for(int ii=0;ii<indexes.length;ii++)
   		    {
   			    indexes[ii]=ii;
   		    }
            KDSTreeNode root = new KDSTreeNode(dataSet, dimCount, 1, threshold,indexes);
            root.buildTree();
          //  List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
            //System.out.println("  leaves    size    is   "+leaves.size());
            log.info("end build kds-tree ...");
            //write routeTree to hdfs
            Path path = new Path(context.getConfiguration().get(KDS_ROUTE_OUTPUT, "data/route-output"));
            FileSystem fs = FileSystem.get(context.getConfiguration());
            if (fs.exists(path)) {
                log.info("delete routeTree ...");
                fs.delete(path, true);
            }
            FSDataOutputStream fsDataOutputStream = fs.create(path);
            
            root.saveToStream(fsDataOutputStream);
            log.info("finish write route tree ...");

            StringBuilder sb = new StringBuilder();
            root.printTree(sb);
            context.write(NullWritable.get(), new Text(sb.toString()));
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 6) {
            System.err.println("Usage: KDSTreeBuilder <input-dir> <output-dir> <segmentLevel> <tsLength> <threshold> <sample>");
            System.exit(2);
        }

        int segmentLevel = Integer.parseInt(otherArgs[2]);
        int tsLength = Integer.parseInt(otherArgs[3]);
        int threshold = Integer.parseInt(otherArgs[4]);
        float sampleRate = Float.parseFloat(otherArgs[5]);

        Job job = new Job(conf, "KDSTreeBuilder");
        job.setNumReduceTasks(1);
       // job.setInputFormatClass(SequenceFileInputFormat.class);
      //  job.setInputFormatClass(BinaryFileInputFormat.class);
        job.setInputFormatClass(SeriesInputFormat.class);

        job.getConfiguration().setInt(SeriesInputFormat.SeriesInputFormatTsLength, tsLength); //add tsLength into config
        job.getConfiguration().setInt(KDS_THRESHOLD, threshold); //add tsLength into config
        job.getConfiguration().setInt(KDS_SEGMENT_LEVEL, segmentLevel); //add tsLength into config
        job.getConfiguration().setFloat(KDS_SAMPLE_RATE, sampleRate); //add tsLength into config

        job.setJarByClass(KDSTreeBuilder.class);
        job.getConfiguration().set(KDS_ROUTE_OUTPUT, otherArgs[0] + "-routeTree/KDSTree.data");

        job.setMapperClass(SegmentInfoCollectMapper.class);
        job.setMapOutputKeyClass(NullWritable.class);
        job.setMapOutputValueClass(DoublesWritable.class);//it's very necessary
        //job.setCombinerClass(SumReducer.class);
        job.setReducerClass(KDSTreeReducer.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[1]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}