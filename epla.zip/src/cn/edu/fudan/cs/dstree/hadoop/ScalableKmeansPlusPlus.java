package cn.edu.fudan.cs.dstree.hadoop;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.time.StopWatch;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

public class ScalableKmeansPlusPlus {

	/**
	 * @param args
	 */
	
		public static  int dimension=512;
		public static  int iterationNumber=10;

	public static void main(String[] args) throws IOException {
			//BufferedReader read1=new BufferedReader(new FileReader("d:\\dataset\\cup3.txt") );
			long start = System.currentTimeMillis();
			//FileWriter ffw = new FileWriter("d:\\dataset\\cup_bulk.txt");
		  //  BufferedWriter fw = new BufferedWriter(ffw); 
			System.out.println("  plus plus Usage    java -Xms256m  -Xmx18192m -jar  sca.jar  k size dimension l iter2");
			double squareError=0;
			//int size=11532;
			 Integer numCenters=Integer.parseInt(args[0]);
			 Integer size=Integer.parseInt(args[1]);
			 dimension=Integer.parseInt(args[2]);
			 int l=Integer.parseInt(args[3]);
			 int iter2=Integer.parseInt(args[4]);
			 // l*iter2 should be greater than the numCenters
	   		HashSet hs=new HashSet();
			ArrayList<Point> center = new ArrayList();
		    ArrayList<Point> al = new ArrayList();
			String[] seed2=new String[dimension];
			for(int ii=0;ii<seed2.length;ii++)
			{
				seed2[ii]="1.0";
			}
			StopWatch stopWatch = new StopWatch();
   	         stopWatch.start();
		//	double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("/home/hadoop/lqh/ucibinary", dimension,size);
			double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\tao_normalize20", 512,size);
			Random ran=new Random();
			int ranI=ran.nextInt(size);
			double[] first=timeSeries[ranI];
			//double cost=computeCost(al,first);
			List<double[]> cans=new ArrayList();
			KmeansPlusPlus kp=new KmeansPlusPlus();
			double[] weights=new double[size];
			double weightsum = kp.initialWeights(weights, timeSeries, first);
			for(int ii=0;ii<iter2;ii++)
			{
				List<double[]> result=kp.chooseInitialMeans_bulk(timeSeries,l,weights);
				
				kp.updateWeights_bulk(weights,timeSeries,result);
				for(int jj=0;jj<result.size();jj++)
				{
					cans.add(result.get(jj));
				}
			}
			System.out.println("  the time for seeding   is   "+stopWatch.getTime());
			// we get  l*iterationNumber centers now
			double[][] newcans=new double[cans.size()][dimension];
			for(int ii=0;ii<cans.size();ii++)
			{
				newcans[ii]=cans.get(ii);
			}
			// get    weighted centers
			//int k=10;
			KmeansPlusPlus kpp=new KmeansPlusPlus();
			List<Integer> centers=new ArrayList();
			List<double[]> results=kpp.chooseInitialMeans(newcans, numCenters,centers);
			for(int ii=0;ii<iterationNumber;ii++)
			{
				StopWatch stopWatch22 = new StopWatch();
	    	     stopWatch22.start();
				List<double[]> newcenter2=process_iterable(timeSeries,results,ii);
				results=newcenter2;
				System.out.println("  the time  spent    for iteration  "+ii+"   "+stopWatch22.getTime());
				 stopWatch22.stop();
			}
			
			System.out.println(" get    weighted centers   finished ....... ");
			//  get  k centers  from  l*iterationNumber weighted centers
			
			
		 
			
	
	}
	public static List process_iterable(double[][] arrayP,List<double[]> center, int iter)
	{
		//boolean dup=checkDuplication(center);
		List<double[]> res=new ArrayList();
		List weighPoints=new ArrayList();
		res=new ArrayList();
		double squareError=0;
		int[] classCount=new int[center.size()];
		List[] pointIn=new ArrayList[center.size()];
		for(int u=0;u<center.size();u++)
		{
				pointIn[u]=new ArrayList();
		}
		double[][] center_sums=new double[center.size()][dimension];
		for(int ii=0;ii<arrayP.length;ii++)
			{
				double[] point2=arrayP[ii];
				double tempDis = 0;
				double minDis = Double.MAX_VALUE;
				int signal = -1;
				for (int j = 0; j < center.size(); j++) {
				    tempDis = DistUtil.euclideanDistSquare(point2, center.get(j));
					if(tempDis < minDis) {
						minDis = tempDis;
						signal = j;
					}
									
				}
				center_sums[signal]=getSum(center_sums[signal],point2);
				squareError=squareError+minDis;
				//��ļ�������1
				classCount[signal]=classCount[signal]+1;
				pointIn[signal].add(point2);
			}
			double[][] center_new=new double[center.size()][dimension];
			for(int i=0;i<center.size();i++)
			{
					if(classCount[i]==0)
					{
						//  only one condition, center is wrong
					//	System.out.println(" ********************      center  is wrong "+"  i   is  "+i+" center is "+((Point)center.get(i)).toString());
					    continue;
					}
					//System.out.println("the   classCount["+ii+"]      is    "+classCount[ii]);
					for(int jj=0;jj<dimension;jj++)
					{
						center_new[i][jj]=center_sums[i][jj]/classCount[i];
						//System.out.println("  center_sums["+ii+"]      is    "+center_sums[ii][0]);
					}
					
			}
			for(int i=0;i<center.size();i++)
			{
					
					
					//System.out.println("    new    center     is   "+point_new.toString());
				//	res.add(point_new);
				//  find the real point closest to wp
					double tempDis=0;
					double minDis = Double.MAX_VALUE;
					int signal = -1;
					for(int u=0;u<pointIn[i].size();u++)
					{
						double[] pp=(double[])pointIn[i].get(u);
						tempDis = DistUtil.euclideanDistSquare(pp, center_new[i]);
						if(tempDis < minDis) {
							minDis = tempDis;
							signal = u;
						}
						
						
					}
					if(signal==-1)
					{
						//System.out.println("  the  size   is  *******   "+pointIn[i].size()+"  i  is  "+i+"   center  is  "+(center.get(14)).toString());
						
					}
					else
					{
						res.add((double[])pointIn[i].get(signal));
					}
				
			}//for
			
			
			{
				System.out.println("   center ***************     size   is  "+center.size());
				System.out.println("Square  error    is    "+Math.sqrt(squareError)+"   iter   number   "+iter);
			}
		
		//remove  duplicate  points
	//	weighPoints=removeDuplicate(weighPoints);
		return res;
	}
	public static double[] getSum(double[] point,double[] previous)
	{
		
		
		for(int ii=0;ii<point.length;ii++)
		{
			//newSum[ii]=newSum[ii]+previous.point.get(ii);
			
			point[ii]=point[ii]+previous[ii];
		}
		return point;
		
	}

}
