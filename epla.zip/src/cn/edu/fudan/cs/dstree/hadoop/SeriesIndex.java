package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.dynamicsplit.*;
import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Created by wangyang on 14-1-26.
 */
public class SeriesIndex {
    private static final Log log = LogFactory.getLog(SeriesIndex.class);
    static int tsLength = 128;
    static int threshold = 100;
    static int binSize = 4;
    public static String outputRouteDir = "outputRoute";
    public static String routeFileName = "routeTree.data";

    public static class SeriesIndexMapper extends Mapper<NullWritable, DoublesWritable, Text, DoublesWritable> {
        double[] data;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            log.info("SeriesIndexMapper setup ...");
        }

        private Text key = new Text("centroid");

        int collectThreshold = threshold * 10;

        @Override
        protected void map(NullWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            data = value.getDoubles();

            log.info("data.length = " + data.length);
            Node root = IndexBuilder.buildIndexInMemoryWithMean(data, tsLength, collectThreshold, 1);
            log.info("root = " + root);
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            log.info("SeriesIndexMapper cleanup ...");

            int binWidth = collectThreshold / binSize;
            int outputThreshold = collectThreshold / 2;
            List<FileBuffer> fileBuffers = FileBufferManager.getInstance().getFileBuffers();
            for (int i = 0; i < fileBuffers.size(); i++) {
                FileBuffer fileBuffer = fileBuffers.get(i);
                double[] centroidTimeSeries = fileBuffer.getCentroidTimeSeries();
//                if (centroidTimeSeries != null && fileBuffer.getBufferCount() > collectThreshold /4) {
                if (centroidTimeSeries != null) {
                    int weight = fileBuffer.getBufferCount() / binWidth;
                    for (int j = 0; j < weight; j++) {
                        context.write(key, new DoublesWritable(centroidTimeSeries));
                    }

//                    if (fileBuffer.getBufferCount() > outputThreshold)
//                        context.write(key, new DoublesWritable(centroidTimeSeries));
                }
            }
            log.info("SeriesIndexMapper cleanup finished!");

            super.cleanup(context);
        }
    }

    public static class CentroidReducer extends Reducer<Text, DoublesWritable, Text, LongWritable> {
        private LongWritable result = new LongWritable();

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
        }

        public void reduce(Text key, Iterable<DoublesWritable> values, Context context) throws IOException, InterruptedException {
            System.out.println("cn.edu.fudan.cs.dstree.hadoop.SeriesIndex.CentroidReducer.reduce");

            Node root = IndexBuilder.initRootWithMean(tsLength, threshold * 10 * binSize, 1); //gen dstree with weight
            long count = 0;
            for (DoublesWritable val : values) {
                double[] doubles = val.getDoubles();
                root.insert(doubles);
                count++;
                if (count % 10000 == 0)
                    log.info(count);
            }
            log.info("root = " + root);
            log.info("count = " + count);

            //write dstree into hdfs
            //
            Configuration conf = context.getConfiguration();
            FileSystem fs = FileSystem.get(conf);
//            Path outPath = new Path(outputRouteDir);
//
//            if (!fs.exists(outPath))
//                fs.create(outPath, false);
//
            Path outFile = new Path(outputRouteDir + "/" + routeFileName);
            if (fs.exists(outFile)) {
                log.info("delete routeTree ...");
                fs.delete(outFile, true);
            }
            FSDataOutputStream fsDataOutputStream = fs.create(outFile);
            log.info(outFile.toUri() + " is created!");
            FSTObjectOutput out = new FSTObjectOutput(fsDataOutputStream);
            out.writeObject(root);
            out.close(); // required !
            fsDataOutputStream.close();
            //read tree data

            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            log.info("leafNodesByFirstOrder.size() = " + leafNodesByFirstOrder.size());

            FSDataInputStream fsDataInputStream = fs.open(outFile);
            FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
            Node newRoot;
            try {
                newRoot = (Node) in.readObject(Node.class);
            } catch (Exception e) {
                throw new IOException(e.getMessage());
            }
            in.close();
            fsDataInputStream.close();

            log.info("newRoot:" + newRoot);
            log.info("newRoot.getSize():" + newRoot.getSize());

            result.set(count);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        conf.setLong("mapred.map.tasks", 20);

        if (otherArgs.length < 2) {
            System.err.println("Usage: seriesIndex <in> <out> [outputRouteDir] [routeFileName]");
            System.exit(2);
        }

        if (otherArgs.length >= 3)
            SeriesIndex.outputRouteDir = otherArgs[2];

        log.info("SeriesIndex.outputRouteDir = " + SeriesIndex.outputRouteDir);

        if (otherArgs.length >= 4)
            SeriesIndex.routeFileName = otherArgs[3];
        log.info("SeriesIndex.routeFileName = " + SeriesIndex.routeFileName);

        Job job = new Job(conf, "series point count");
        job.setInputFormatClass(WholeTimeSeriesSplitInputFormat.class);
        job.setJarByClass(SeriesIndex.class);
        job.setMapperClass(SeriesIndexMapper.class);
        //job.setCombinerClass(SumReducer.class);
        job.setMapOutputValueClass(DoublesWritable.class);//it's very necessary
        job.setReducerClass(CentroidReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[1]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}