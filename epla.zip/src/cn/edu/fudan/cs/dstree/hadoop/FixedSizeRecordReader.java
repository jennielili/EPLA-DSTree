package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;

/**
 * Created by wangyang on 14-1-26.
 */
public class FixedSizeRecordReader extends RecordReader<LongWritable, BytesWritable> {
    int fixedSize;

    LongWritable key;
    BytesWritable value;
    long start;
    long end;
    long pos;
    private boolean done = false;
    private FSDataInputStream fsDataInputStream;

    public FixedSizeRecordReader(int fixedSize) {
        this.fixedSize = fixedSize;
    }

    @Override
    public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
        Path path = ((FileSplit) split).getPath();
        System.out.println("path = " + path);
        Configuration conf = context.getConfiguration();
        FileSystem fs = path.getFileSystem(conf);
        fsDataInputStream = fs.open(path);

        this.start = ((FileSplit) split).getStart();
        pos = start;
        this.end = ((FileSplit) split).getStart() + split.getLength();
        System.out.println("start = " + start);
        System.out.println("end = " + end);
        System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());
        if (start != 0) {
            long offset = start % fixedSize;
            if (offset > 0) {
                System.out.println("offset = " + offset);
            }
            start -= offset;
            fsDataInputStream.seek(start);
        }
        System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());

        done = fsDataInputStream.getPos() + fixedSize > end;
    }

    @Override
    public boolean nextKeyValue() throws IOException, InterruptedException {
        done = (fsDataInputStream.getPos() + fixedSize) > end;
        if (done) {
            System.out.println("fsDataInputStream.getPos() = " + fsDataInputStream.getPos());
            System.out.println("fsDataInputStream.getPos() + fixedSize =" + (fsDataInputStream.getPos() + fixedSize));
            System.out.println("end = " + end);
            return false;
        }

        pos = fsDataInputStream.getPos(); //start from 0
        key = new LongWritable(pos);
        byte[] buffer = new byte[fixedSize];
        fsDataInputStream.readFully(buffer);
        value = new BytesWritable(buffer);
        return true;
    }

    @Override
    public LongWritable getCurrentKey() throws IOException, InterruptedException {
        return key;
    }

    @Override
    public BytesWritable getCurrentValue() throws IOException, InterruptedException {
        return value;
    }

    @Override
    public float getProgress() throws IOException, InterruptedException {
        if (end == start) {
            return 0.0f;
        } else {
            return Math.min(1.0f, (float) ((fsDataInputStream.getPos() - start) /
                    (double) (end - start)));
        }
    }

    @Override
    public void close() throws IOException {
        fsDataInputStream.close();
    }
}
