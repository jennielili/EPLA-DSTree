package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: wangyang
 * Date: 13-3-19
 * Time: 上午12:16
 * To change this template use File | Settings | File Templates.
 */
public class HDFSBruteForceExactSearcher {
    public static void main(String[] args) throws IOException {
        String fileName = args[0]; //source file
        String searchFileName = args[1]; //in text format
        double[][] multiTs = TimeSeriesFileUtil.readSeriesFromFile(searchFileName);
        double[] distances = new double[multiTs.length];
        double[][] hitTs = new double[multiTs.length][];
        long[] hitLineNo = new long[multiTs.length];

        Arrays.fill(distances, Double.POSITIVE_INFINITY);

        HDFSBinaryTimeSeriesReader reader = new HDFSBinaryTimeSeriesReader(fileName, multiTs[0].length);
        reader.open();
        long lineNo = 0;
        try {
            while (reader.hasNext()) {
                double[] next = reader.next();
                for (int i = 0; i < multiTs.length; i++) {
                    double[] qs = multiTs[i];

                    double d = DistUtil.euclideanDist(qs, next);
                    if (d < distances[i]) {
                        distances[i] = d;
                        hitLineNo[i] = lineNo;
                        hitTs[i] = next;
                    }
                }
                lineNo++;
                if (lineNo % 100000 == 0)
                {
                    System.out.println(new Date() + "lineNo = " + lineNo);
                }
            }
        } finally {
            reader.close();
        }

        //output
        for (int i = 0; i < multiTs.length; i++) {
            double[] qs = multiTs[i];
            System.out.println("search:" + i);
            printTimeSeries(qs);

            System.out.println("hitLineNo = " + hitLineNo[i]);
            System.out.println("distances = " + distances[i]);
            System.out.println("hitTs = ");
            printTimeSeries(hitTs[i]);
        }
    }

    public static NumberFormat formatter = new DecimalFormat("#0.0000");

    public static void printTimeSeries(double[] ts) {
        System.out.print("[");
        for (int j = 0; j < Math.min(ts.length, 10); j++) {
            double v = ts[j];
            System.out.print(formatter.format(v) + " ");
        }
        System.out.println("...]");
    }
}
