package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import java.io.IOException;

/**
 * Created by wangyang on 14-1-26.
 */
public class SeriesInputFormat extends FileInputFormat<LongWritable, DoublesWritable> {
    public static final String SeriesInputFormatTsLength = "SeriesInputFormat.tsLength";

    public static int tsLength=1000;

    public SeriesInputFormat() {
    }

    @Override
    protected boolean isSplitable(JobContext context, Path filename) {
        return true;
    }

    @Override
    public RecordReader<LongWritable, DoublesWritable> createRecordReader(InputSplit inputSplit, TaskAttemptContext taskAttemptContext) throws IOException, InterruptedException {
        tsLength = taskAttemptContext.getConfiguration().getInt(SeriesInputFormatTsLength, 1000);
        return new SeriesRecordReader(tsLength);
    }

}
