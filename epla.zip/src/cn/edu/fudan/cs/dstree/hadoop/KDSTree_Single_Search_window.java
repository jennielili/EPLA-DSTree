package cn.edu.fudan.cs.dstree.hadoop;
//import java.util.*;
import java.text.DecimalFormat;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import org.apache.commons.lang.math.IntRange;
import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.io.IntWritable;
import cn.edu.fudan.cs.dstree.dynamicsplit.IndexBuilder;
import cn.edu.fudan.cs.dstree.dynamicsplit.KDSTreeNode;
import cn.edu.fudan.cs.dstree.dynamicsplit.Node;
import cn.edu.fudan.cs.dstree.dynamicsplit.NodeUtil;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

public class KDSTree_Single_Search_window {

	/**
	 * @param args
	 */
	 HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
	private int segmentLevel=4;
	List<IntRange> segments;
	private int dimCount;
	private int tsLength=1000;
    int threshold=100;
    private float sampleRate;
    private KDSTreeNode root;
    private Node newroot;
	public  void buildTree(double[][] dataSet,int numCenters) throws IOException {
		 // TODO Auto-generated method stub
		 System.out.println("  dataSet **************************       "+dataSet.length);
		 StopWatch stopWatch2 = new StopWatch();
		 stopWatch2.start();
		 segments = CalcUtil.generateSplitRanges(tsLength, segmentLevel);
		 dimCount = CalcUtil.generateSplitRanges(1000, segmentLevel).size();
		 System.out.println("  the size of segments  "+segments.size()+"   dimCount    is   "+dimCount);
		 double[][] temp=new double[dataSet.length][segments.size()];
		 int[] labels=new int[dataSet.length];
		 int[] interval=new int[segments.size()];
		 for (int i = 0; i < segments.size(); i++) {
             IntRange intRange = segments.get(i);
             int start = intRange.getMinimumInteger();
             int end = intRange.getMaximumInteger();
             interval[i]=end-start+1;
             System.out.println("  index    is   "+i+"    start   is  "+start+"   end   is   "+end);
          
         }
		 for(int ii=0;ii<dataSet.length;ii++)
		 {
			 double[] ts = dataSet[ii];
             double[] means = new double[segments.size()];
             for (int i = 0; i < segments.size(); i++) {
                 IntRange intRange = segments.get(i);
                 int start = intRange.getMinimumInteger();
                 int end = intRange.getMaximumInteger();
            //    System.out.println("  start   is  "+start+"   end   is   "+end);
                 double avg = CalcUtil.avg(ts, start, end);
                 temp[ii][i] = avg;
               //  System.out.println("  ii  "+ii+"   i   "+i+"   "+temp[ii][i]);
                 
             }
           
		 }
		 int [] indexes=new int[dataSet.length];
		 for(int ii=0;ii<indexes.length;ii++)
		 {
			 indexes[ii]=ii;
		 }
		 root = new KDSTreeNode(temp, dimCount, 1, threshold,indexes);
		 System.out.println("*****************  indexes   length  "+indexes.length);
		 System.out.println("***************** root indexes   length  "+root.indexes.length);
		 root.buildTree();
		 Node root2 = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         NodeUtil.initDSTreeWithKDSTree(root, root2);
         NodeUtil.clearAllStatistics(root2);
         
     //    String indexFileName="c:\\data\\kdsindex";
		 String indexFileName="/home/hadoop/lqh/kdsindex";
		 List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         System.out.println("  number of leaves  "+leaves.size());
         
       //  root.saveToFile(indexFileName);
         StringBuilder  stringBuilder=new StringBuilder();
       //  root.printTree(stringBuilder);
         // clustering   here 
       //  List<KDSTreeNode> leaves=NodeUtil.getLeafKDSNodesByFirstOrder(root);
         System.out.println("  number of leaves  "+leaves.size());
      //   double[][][] synopsis=new double[leaves.size()][dimCount][2];
         List<double[]> leafMins=new ArrayList();
         List<double[]> leafMaxs=new ArrayList();
         List<double[]>  medians=new ArrayList();
         double[][] medians2=new double[leaves.size()][1000];
         for(int ii=0;ii<leaves.size();ii++)
         {
        	 KDSTreeNode leaf=leaves.get(ii);
        	 int start=leaf.getStart();
        	 int end=leaf.getEnd();
        	 int median=(start+end)/2;
        	 int realIndex=indexes[median];
        	 System.out.println("   readIndex   *************   "+realIndex);
        	 medians.add(dataSet[realIndex]);
        	 double[][] temp2=leaf.getDataSet();
        	 System.out.println(" leaf   "+ii+"  splitValue  "+leaf.getParent().getSplitValue()+"  split dim  "+leaf.getParent().getSplitDim()+" weight "+leaf.getParent().getDimWeight(leaf.getParent().getSplitDim()));
        	 double[] synopsis_min=new double[dimCount];
        	 double[] synopsis_max=new double[dimCount];
        	 for(int k=0;k<dimCount;k++)
        	 {
        		 
        		 synopsis_min[k]=Double.MAX_VALUE;
        		 synopsis_max[k]=Double.MIN_VALUE; 
        	 }
        	 int start_dim=0;
        	 for(int k=start_dim;k<dimCount;k++)
        	 {
        		for(int jj=leaf.getStart();jj<leaf.getEnd();jj++)
        		{
        			if(temp2[jj][k]<synopsis_min[k])
        		          synopsis_min[k]=temp2[jj][k];
        			
        			if(temp2[jj][k]>synopsis_max[k])
      		          synopsis_max[k]=temp2[jj][k];
        	     }
        	 
               }
        	 leafMins.add(synopsis_min);
        	 leafMaxs.add(synopsis_max);
        //	 System.out.println("  leaf   ii "+ii+"   max  "+ synopsis_max[4]+"    min  "+synopsis_min[4] );
         }
         //compute   the  prunning   rate 
         int sum=0;
         for(int ii=0;ii<leaves.size();ii++)
         {
        	 int cc=0;
        	 for(int jj=ii+1;jj<leaves.size();jj++)
             {
        		 double[] synopsis_min1=leafMins.get(ii);
        		 double[] synopsis_min2=leafMins.get(jj);
        		 double[] synopsis_max1=leafMaxs.get(ii);
        		 double[] synopsis_max2=leafMaxs.get(jj);
        		 double dis=lowerBound(synopsis_min1,synopsis_max1,7,synopsis_min2,synopsis_max2,interval);
        		 System.out.println("  ii   "+ii+"   jj   "+jj+"    "+dis);
        		 if(dis>0.5)
        		 { 
        			 sum++;
        			 cc++;
        			 if(cc>=1)
        				 break;
        		 }
        	 
             }
         }
        
         double sum2=0.0;
         initMap();
         StopWatch stopWatch = new StopWatch();
	    	stopWatch.start();
	    	
	     // 
	     BufferedReader aa=new BufferedReader(new FileReader("c:\\data\\search.txt"));
	     while(aa.ready())
		{
	    	double[] queryItem=new double[tsLength];
			String newLine=aa.readLine();
			String[] vas=newLine.split("\t");
			Integer id=Integer.parseInt(vas[0]);
			String[] doubles=vas[1].split(" ");
			for(int ii=0;ii<doubles.length;ii++)
			{
				queryItem[ii]=Double.parseDouble(doubles[ii]);
			}
			
			Node leafNode =root2.approximateSearch(queryItem);
			System.out.println("  query  id     is    "+id+"    node  id    is    "+leafNode.getId());
			
			
			
		}
       /*  for(int ii=0;ii<dataSet.length;ii++)
         {
        	 Node leafNode = newroot.approximateSearch(dataSet[ii]);
             IntWritable intWritable = node2IdxMap.get(leafNode);
           //  System.out.println("   label    is   "+intWritable.get());
         }*/
         System.out.println("  time  SEARCH spent   is    "+stopWatch.getTime());
         System.out.println(stringBuilder.toString());
         
      
	}
	
	public double lowerBound(double[] min, double[] max,int start,double[] min2,double[] max2, int[] segmentLength) {
		double sum = 0;

		for (int i = 0; i < min.length; i++) {
			double node1MaxAvg = max[i];
			double node1MinAvg = min[i];

			double node2MaxAvg = max2[i];
			double node2MinAvg = min2[i];

			Range node1AvgRange = new Range(node1MinAvg, node1MaxAvg);
			Range node2AvgRange = new Range(node2MinAvg, node2MaxAvg);

			double avgDistance = Range.distance(node1AvgRange, node2AvgRange);
			if (avgDistance != 0) {
				sum += avgDistance * avgDistance * segmentLength[i];
			}
		}

		sum = Math.sqrt(sum);
		return sum;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 KDSTree_Single_Search_window  KDS=new KDSTree_Single_Search_window();
		// int size=100000;
		 int tsLength=1000;
		 Integer numCenters=Integer.parseInt(args[0]);
		 Integer size=Integer.parseInt(args[1]);
		 StopWatch stopWatch = new StopWatch();
	     stopWatch.start();
		 double[][] dataSet=new double[size][tsLength];
		 int[] indexes=new int[size];
		 for(int ii=0;ii<size;ii++)
		 {
			 indexes[ii]=ii;
		 }
		 
		// double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\ucibinary", tsLength,size);
		 double[][] timeSeries = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce("c:\\data\\ucibinary", tsLength,size);
		 KDS.buildTree(timeSeries,numCenters);
		
		 System.out.println("  time  spent   is    "+stopWatch.getTime());
		 System.out.println("  ************************        successfully");
	}
	 private void initMap() throws IOException {
         //first order traverse to visit leaf node
		 newroot = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
         List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(newroot);
         for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
             Node node = leafNodesByFirstOrder.get(i);
             node2IdxMap.put(node, new IntWritable(i));
         }
     }
}
