package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.util.TimeSeriesReader;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.util.GenericOptionsParser;
import org.omg.DynamicAny._DynAnyFactoryStub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by wangyang on 14-2-9.
 */
public class HDFSTxtTimeSeriesReader {
    private static final Log log = LogFactory.getLog(HDFSTxtTimeSeriesReader.class);
    public static NumberFormat formatter = new DecimalFormat("#0.0000");
    static PathFilter defaultFilter = new PathFilter() {
        @Override
        public boolean accept(Path path) {
            if (path.getName().startsWith(".")) return false;
            if (path.getName().startsWith("_")) return false;

            return true;
        }
    };

    String path;
    int tsLength;
    Configuration conf;
    Path[] files;
    long[] lens;
    long totalLength = 0;
    int tsLengthInByte;
    FileSystem fs;

    public HDFSTxtTimeSeriesReader(String path, Configuration conf, PathFilter filter) throws IOException {
        this.path = path;
        this.conf = conf;

        fs = FileSystem.get(conf);
        Path parentPath = new Path(path);
        FileStatus fileStatus = fs.getFileStatus(parentPath);

        if (fileStatus == null) {
            throw new RuntimeException("file not exists!" + path);
        }

        files = getAllFiles(parentPath, fs, filter).toArray(new Path[0]);

        totalLength = 0;
        lens = new long[files.length];
        for (int i = 0; i < files.length; i++) {
            Path file = files[i];
            lens[i] = fs.getFileStatus(file).getLen();
            totalLength += lens[i];
        }

        fileIdx = 0;
        posInFile = 0;
        position = 0;
        tsLengthInByte = tsLength * 8;
    }

    public static List<Path> getAllFiles(Path path, FileSystem fs, PathFilter filter) throws IOException {
        log.debug("process " + path.getName());
        List<Path> ret = new ArrayList<Path>();

        FileStatus fileStatus = fs.getFileStatus(path);

        if (fileStatus == null) {
            throw new RuntimeException("file not exists!" + path);
        }

        if (fileStatus.isDir()) {
            FileStatus[] statuses = fs.listStatus(path, filter);
            for (FileStatus status : statuses) {
                ret.addAll(getAllFiles(status.getPath(), fs, filter));
            }
        } else {
            ret.add(path);
        }

        return ret;
    }

    public HDFSTxtTimeSeriesReader(String path) throws IOException {
        this(path, new Configuration(), defaultFilter);
    }

    int fileIdx;
    long posInFile;
    long position;
    String line;

    public boolean hasNext() throws IOException {
        //read file one by one
        line = bufferedReader.readLine();
        boolean b = line != null && line.trim().length() > 0;
        if (b)
            return b;
        else if ((++fileIdx) < files.length) {
            fis.close();
            fis = fs.open(files[fileIdx]);
            bufferedReader = new BufferedReader(new InputStreamReader(fis));
            return hasNext();
        }
        return false;
    }

    FSDataInputStream fis;
    BufferedReader bufferedReader;

    public double[] next() {
        return TimeSeriesReader.readFromString(line);
    }

    public void close() throws IOException {
        fis.close();
    }

    public void open() throws IOException {
        fis = fs.open(files[fileIdx]);
        bufferedReader = new BufferedReader(new InputStreamReader(fis));
    }
}
