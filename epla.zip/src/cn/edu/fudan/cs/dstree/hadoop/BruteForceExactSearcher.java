package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.util.DistUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by wangyang on 14-1-26.
 */
public class BruteForceExactSearcher {
    private static final Log log = LogFactory.getLog(BruteForceExactSearcher.class);
    public static double[][] queryTimeSeries;
    public static String queryTxtFile;

    public static class FindNearestMapper extends Mapper<LongWritable, DoublesWritable, IntWritable, DoublesWritable> {
        double[] distances;
        double[][] hitTimeSeries;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            log.info("cn.edu.fudan.cs.dstree.hadoop.BruteForceExactSearcher.FindNearestMapper.setup");
            super.setup(context);
            log.info(queryTxtFile);
            log.info(queryTimeSeries);
            queryTxtFile = context.getConfiguration().get("queryTxtFile","");
            log.info(queryTxtFile);

            queryTimeSeries = getTimeSeries(queryTxtFile);

            distances = new double[queryTimeSeries.length];
            Arrays.fill(distances, Double.POSITIVE_INFINITY);
            hitTimeSeries = new double[queryTimeSeries.length][];
        }

        @Override
        protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            for (int i = 0; i < queryTimeSeries.length; i++) {
                double[] qs = queryTimeSeries[i];

                double d = DistUtil.euclideanDist(qs, value.getDoubles());
                if (d < distances[i]) {
                    distances[i] = d;
                    hitTimeSeries[i] = value.getDoubles();
                }
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            log.info("SeriesIndexMapper cleanup ...");

            for (int i = 0; i < hitTimeSeries.length; i++) {
                double[] hitTimeSery = hitTimeSeries[i];
                context.write(new IntWritable(i), new DoublesWritable(hitTimeSery));
            }
            super.cleanup(context);
        }
    }

    public static class FindNearestReducer extends Reducer<IntWritable, DoublesWritable, IntWritable, Text> {
        double[] distances;
        double[][] hitTimeSeries;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            queryTxtFile = context.getConfiguration().get("queryTxtFile","");
            log.info("queryTxtFile = " + queryTxtFile);
            queryTimeSeries = getTimeSeries(queryTxtFile);
            distances = new double[queryTimeSeries.length];
            Arrays.fill(distances, Double.POSITIVE_INFINITY);
            hitTimeSeries = new double[queryTimeSeries.length][];
        }

        @Override
        protected void reduce(IntWritable key, Iterable<DoublesWritable> values, Context context) throws IOException, InterruptedException {
            double distance = Double.POSITIVE_INFINITY;
            double[] hitTs = new double[0];
            for (DoublesWritable val : values) {
                double[] qs = queryTimeSeries[key.get()];
                double[] ts = val.getDoubles();
                double d = DistUtil.euclideanDist(qs, ts);
                if (d < distance) {
                    distance = d;
                    hitTs = ts;
                }
            }
            String s = TimeSeriesFileUtil.timeSeries2Line(hitTs);
            s = distance + " " + s;
            context.write(key, new Text(s));
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            super.cleanup(context);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 3) {
            System.err.println("Usage: BruteForceExactSearcher <input-dir> <qs-file> <output-dir>");
            System.exit(2);
        }

        String queryTxtFile = otherArgs[1];
        double[][] qss = getTimeSeries(queryTxtFile);


        int tsLength = qss[0].length;

        Job job = new Job(conf, "BruteForceExactSearcher");
        job.setNumReduceTasks(1);

        job.setInputFormatClass(SeriesInputFormat.class);
        job.getConfiguration().setInt(SeriesInputFormat.SeriesInputFormatTsLength, tsLength); //add tsLength into config

        job.setJarByClass(BruteForceExactSearcher.class);
//        job.getConfiguration().set
//        BruteForceExactSearcher.queryTimeSeries = qss;
//        BruteForceExactSearcher.queryTxtFile = otherArgs[1];
        job.getConfiguration().set("queryTxtFile",otherArgs[1]);

        job.setMapperClass(FindNearestMapper.class);
        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(DoublesWritable.class);//it's very necessary
        //job.setCombinerClass(SumReducer.class);
        job.setReducerClass(FindNearestReducer.class);
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[2]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

    private static double[][] getTimeSeries(String queryTxtFile) throws IOException {
        List<double[]> tss = new ArrayList<double[]>();
        HDFSTxtTimeSeriesReader reader = new HDFSTxtTimeSeriesReader(queryTxtFile);
        reader.open();
        try {
            while (reader.hasNext()) {
                double[] next = reader.next();
                tss.add(next);
            }
        } finally {
            reader.close();
        }

        return tss.toArray(new double[tss.size()][]);
    }
}