package cn.edu.fudan.cs.dstree.hadoop;
import java.util.*;





/**
 * 
 * @author Administrator
 * This is a tool class to provide some methods used frequently
 * The methods in it are static,so you can use them by class Tool
 */
public class Tool {
	public static int dimension=1000;
	public static double distanceSimple(Point p1, Point p2) {
		double sum = 0.0;
		double a = 0;
		if(p1==null || p2==null)
			 System.out.println("  Fatal   Error  in  Tooljava    *************");
	//	System.out.println("   point    size    is   "+p1.point.size());
		for(int i=0; i<p1.point.size(); i++) {
			a = Math.pow((p1.point.get(i)-p2.point.get(i)), 2);
		//	System.out.println("   point 1 "+p1.point.get(i)+  "   point  2   is  "+p2.point.get(i));
			sum += a;
		}
		return Math.sqrt(sum);
	}
	public static  double getHashValue(double[] a , double b, double w, double[] vv )
   	{
   		double temp=0.0;
   		double temp1=0.0;
   		double temp2=0.0;
   		double hash=0.0;
   		for(int ii=0;ii<a.length;ii++)
   		{
   		//	temp=temp+(a.point.get(ii)*vv.point.get(ii))/(Math.sqrt(piabs))*(Math.sqrt(piabs2));
   			temp=temp+a[ii]*vv[ii];
   		}
    //	System.out.println("  temp   is   "+temp);
   		hash=Math.floor((temp+b)/w);
   	    return hash;	
   	}

}
