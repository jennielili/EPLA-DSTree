package cn.edu.fudan.cs.dstree.hadoop;

/**
 * Created by wangyang on 14-1-26.
 */
public class Series128InputFormat extends FixedSizeRecordFileInputFormat {

    public Series128InputFormat() {
        super();
        fixedSize = 128 * 8;
    }
}
