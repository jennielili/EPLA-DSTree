package cn.edu.fudan.cs.dstree.hadoop;
import java.io.IOException;
import java.util.*;
import cn.edu.fudan.cs.dstree.util.CalcUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser; 
//for original data
public class DataGen_fromText {
		public static class BaselineMapper extends
			Mapper<Object, Text, NullWritable, DoublesWritable> {
		public void map(Object key, Text value, Context context)
				throws IOException, InterruptedException {
			int length=1000;
			String[] values=value.toString().split("\t");
			String[] values2=values[1].split(" ");
			double[] ld=new double[1000];
			for(int ii=0;ii<DSTreeConst.length;ii++)
			{
				ld[ii]=Double.parseDouble(values2[ii].trim());
			}
            ld = CalcUtil.z_Normalize(ld);
            DoublesWritable item = new DoublesWritable(ld);
           	context.write(NullWritable.get(), item);
			
			
    }
		}
	
		
	
	public void run(String[] args) throws Exception {
		Configuration conf = new Configuration();
		new GenericOptionsParser(conf, args).getRemainingArgs();
		Job job = new Job(conf, "Similarity Join Using LSH : diff 18 r 5  records 67w");
		job.setJarByClass(DataGen_fromText.class);
		job.setMapperClass(BaselineMapper.class);
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		job.setNumReduceTasks(0);
		job.setMapOutputKeyClass(NullWritable.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(DoublesWritable.class);
			//	FileInputFormat.addInputPath(job,				new Path(conf.get(SQConfig.dataSplitInput)));
		//FileInputFormat.addInputPath(job,				new Path("lqh/uci"));
		FileInputFormat.addInputPath(job,				new Path("lsh_test"));
		FileSystem fs = FileSystem.get(conf);
		fs.delete(new Path("binaryfile"), true);
		//	FileOutputFormat.setOutputPath(job,	new Path(conf.get(SQConfig.strKNNJoinOutput)));
		FileOutputFormat.setOutputPath(job,	new Path("binaryfile"));
		long begin = System.currentTimeMillis();
		job.waitForCompletion(true);
		long end = System.currentTimeMillis();
		long second = (end - begin) / 1000;
		System.err.println(job.getJobName() + " takes " + second + " seconds");
	}

	/**
	 * @param argseee
	 */
	public static void main(String[] args) {
		DataGen_fromText rs = new DataGen_fromText();
		try {
			rs.run(args);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

}
