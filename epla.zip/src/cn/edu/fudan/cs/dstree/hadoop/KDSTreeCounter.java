package cn.edu.fudan.cs.dstree.hadoop;

import cn.edu.fudan.cs.dstree.dynamicsplit.*;
import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.reduce.LongSumReducer;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * Created by wangyang on 14-2-19.
 */
public class KDSTreeCounter {
    private static final Log log = LogFactory.getLog(KDSTreeCounter.class);
    private static final String KDS_ROUTE_OUTPUT = "KDSTreeBuilder.Kds.Route.Output";
    private static final String DSTREE_THRESHOLD = "DSTreeBuilder.Threshold";
    private static final String DSTREE_INDEX_OUTPUT = "DSTreeBuilder.Index.Output";
    private static final String DSTREE_DATA_OUTPUT = "DSTreeBuilder.Data.Output";

    public static class KDSTreeCounterMapper extends Mapper<LongWritable, DoublesWritable, IntWritable, LongWritable> {
        Node root;
        HashMap<Node, IntWritable> node2IdxMap = new HashMap<Node, IntWritable>();
        private int tsLength;
        private int threshold;

        public Node readTheRouteInfo(TaskInputOutputContext context) throws IOException {
            Configuration conf = context.getConfiguration();
            FileSystem fs = FileSystem.get(conf);
            Path path = new Path(context.getConfiguration().get(KDS_ROUTE_OUTPUT, "data/route-output"));

            if (!fs.exists(path)) {
                throw new IOException("route file not exists!");
            }
            FSDataInputStream fsDataInputStream = fs.open(path);
            FSTObjectInput in = new FSTObjectInput(fsDataInputStream);
            KDSTreeNode kdsTreeNode;
            try {
                kdsTreeNode = (KDSTreeNode) in.readObject(KDSTreeNode.class);
            } catch (Exception e) {
                throw new IOException(e.getMessage());
            }
            in.close();
            fsDataInputStream.close();

            Node root = IndexBuilder.initMemoryRoot(tsLength, threshold, 1);
            NodeUtil.initDSTreeWithKDSTree(kdsTreeNode, root);
            NodeUtil.clearAllStatistics(root);
            return root;
        }

        private void initMap() {
            //first order traverse to visit leaf node
            List<Node> leafNodesByFirstOrder = NodeUtil.getLeafNodesByFirstOrder(root);
            for (int i = 0; i < leafNodesByFirstOrder.size(); i++) {
                Node node = leafNodesByFirstOrder.get(i);
                node2IdxMap.put(node, new IntWritable(i));
            }
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            super.setup(context);
            tsLength = context.getConfiguration().getInt(SeriesInputFormat.SeriesInputFormatTsLength, 128);
            threshold = context.getConfiguration().getInt(DSTREE_THRESHOLD, 100);
            //read the route info
            root = readTheRouteInfo(context);
            initMap();
            log.info("node2IdxMap.size() = " + node2IdxMap.size());
            log.info("SeriesIndexMapper setup ...");
        }

        @Override
        protected void map(LongWritable key, DoublesWritable value, Context context) throws IOException, InterruptedException {
            double[] timeSeries = value.getDoubles();
            Node leafNode = root.approximateSearch(timeSeries);
            IntWritable intWritable = node2IdxMap.get(leafNode);
            context.write(intWritable, new LongWritable(1));
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            log.info("SeriesIndexMapper cleanup ...");

            log.info("SeriesIndexMapper cleanup finished!");
            super.cleanup(context);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 3) {
            System.err.println("Usage: KDSTreeCounter <in> <out> <tsLength>");
            System.exit(2);
        }

        int tsLength = Integer.parseInt(otherArgs[2]);

        Job job = new Job(conf, "KDSTree Counter");
        String routeTreePath = otherArgs[0] + "-routeTree/KDSTree.data";
        System.out.println("routeTreePath = " + routeTreePath);
        job.getConfiguration().set(KDS_ROUTE_OUTPUT, routeTreePath);
        job.getConfiguration().setInt(SeriesInputFormat.SeriesInputFormatTsLength, tsLength); //add tsLength into config

        job.setInputFormatClass(SeriesInputFormat.class);
        job.setJarByClass(KDSTreeCounter.class);
        job.setMapperClass(KDSTreeCounterMapper.class);
        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(LongWritable.class);//it's very necessary
        job.setCombinerClass((new LongSumReducer<IntWritable>()).getClass());
        job.setReducerClass((new LongSumReducer<IntWritable>()).getClass());
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(LongWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        Path outputDir = new Path(otherArgs[1]);
        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputDir)) {
            System.out.println("delete output dir ...");
            fs.delete(outputDir, true);
        }
        FileOutputFormat.setOutputPath(job, outputDir);

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
