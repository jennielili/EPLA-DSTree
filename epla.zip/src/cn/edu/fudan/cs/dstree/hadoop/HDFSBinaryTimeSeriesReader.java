package cn.edu.fudan.cs.dstree.hadoop;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by wangyang on 14-2-9.
 */
public class HDFSBinaryTimeSeriesReader {
    private static final Log log = LogFactory.getLog(HDFSBinaryTimeSeriesReader.class);
    public static NumberFormat formatter = new DecimalFormat("#0.0000");
    static PathFilter defaultFilter = new PathFilter() {
        @Override
        public boolean accept(Path path) {
            if (path.getName().startsWith(".")) return false;
            if (path.getName().startsWith("_")) return false;

            return true;
        }
    };

    String path;
    int tsLength;
    Configuration conf;
    Path[] files;
    long[] lens;
    long totalLength;
    int tsLengthInByte;
    FileSystem fs;

    public HDFSBinaryTimeSeriesReader(String path, int tsLength, Configuration conf, PathFilter filter) throws IOException {
        this.path = path;
        this.tsLength = tsLength;
        this.conf = conf;

        fs = FileSystem.get(conf);
        Path parentPath = new Path(path);
        FileStatus fileStatus = fs.getFileStatus(parentPath);

        if (fileStatus == null) {
            throw new RuntimeException("file not exists!" + path);
        }

        files = getAllFiles(parentPath, fs, filter).toArray(new Path[0]);

        totalLength = 0;
        lens = new long[files.length];
        for (int i = 0; i < files.length; i++) {
            Path file = files[i];
            lens[i] = fs.getFileStatus(file).getLen();
            totalLength += lens[i];
        }

        fileIdx = 0;
        posInFile = 0;
        position = 0;
        tsLengthInByte = tsLength * 8;
    }

    public static List<Path> getAllFiles(Path path, FileSystem fs, PathFilter filter) throws IOException {
        log.debug("process " + path.getName());
        List<Path> ret = new ArrayList<Path>();

        FileStatus fileStatus = fs.getFileStatus(path);

        if (fileStatus == null) {
            throw new RuntimeException("file not exists!" + path);
        }

        if (fileStatus.isDir()) {
            FileStatus[] statuses = fs.listStatus(path, filter);
            for (FileStatus status : statuses) {
                ret.addAll(getAllFiles(status.getPath(), fs, filter));
            }
        } else {
            ret.add(path);
        }

        return ret;
    }

    public HDFSBinaryTimeSeriesReader(String path, int tsLength) throws IOException {
        this(path, tsLength, new Configuration(), defaultFilter);
    }

    int fileIdx;
    long posInFile;
    long position;

    public boolean hasNext() throws IOException {
        //read file one by one
        boolean ret = (position + tsLengthInByte) <= totalLength;

        //prepare data
        if (ret) {
            ts = new double[tsLength];
            for (int i = 0; i < ts.length; i++) {
                if (posInFile != lens[fileIdx])  //read to end
                    ts[i] = fis.readDouble();
                else {
                    //change file
                    fileIdx++;
                    if (lens[fileIdx] < 8) {
                        throw new RuntimeException("file length <8 !");
                    }
                    fis.close();
                    fis = fs.open(files[fileIdx]);

                    posInFile = 0;
                    ts[i] = fis.readDouble();
                }
                posInFile += 8;
                position += 8;
            }
        }

        return ret;
    }

    FSDataInputStream fis;
    double[] ts;

    public double[] next() {
        return ts;
    }

    public void close() throws IOException {
        fis.close();
    }

    public void open() throws IOException {
        fis = fs.open(files[fileIdx]);
    }

    public static void main(String[] args) throws IOException {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        Path file = new Path(otherArgs[0]);
        FileSystem fs = FileSystem.get(conf);
        FileStatus fileStatus = fs.getFileStatus(file);
        List<Path> fileList = new ArrayList<Path>();
        if (fileStatus.isDir()) {
            //add first level file
            System.out.println("file.toUri() = " + file.toUri() + " is a directory!");
            FileStatus[] fileStatuses = fs.listStatus(file);
            System.out.println("fileStatuses.length = " + fileStatuses.length);
            for (int i = 0; i < fileStatuses.length; i++) {
                FileStatus fileStatuse = fileStatuses[i];
                if (!fileStatuse.isDir()) {
                    if (fileStatuse.getPath().getName().startsWith("_")) continue;
                    if (fileStatuse.getPath().getName().startsWith(".")) continue;
                    fileList.add(fileStatuse.getPath());
                    System.out.println("add fileStatuse.getPath().toUri() = " + fileStatuse.getPath().toUri());
                }
            }
        } else {
            fileList.add(file);
        }

        int tsLength = 128;
        if (otherArgs.length >= 2) {
            tsLength = Integer.parseInt(otherArgs[1]);
        }
        System.out.println("tsLength = " + tsLength);

        String sIdxes = "0";
        if (otherArgs.length >= 3) {
            sIdxes = otherArgs[2];
        }

        String[] split = sIdxes.split(",");
        long[] idxes = new long[split.length];
        for (int i = 0; i < idxes.length; i++) {
            idxes[i] = Long.parseLong(split[i]);
        }

        Arrays.sort(idxes);
        byte[] buffer = new byte[tsLength * 8];

        for (Path path : fileList) {
            FSDataInputStream fis = fs.open(path);
            System.out.println(new Date() + "start read ..." + path.toUri());

            for (int i = 0; i < idxes.length; i++) {
                long idx = idxes[i];
                long position = tsLength * idx * 8;
                fis.readFully(position, buffer);

                System.out.println("idx = " + idx);
                System.out.print("[");
                double[] timeSeries = new double[buffer.length / 8];
                ByteBuffer.wrap(buffer).asDoubleBuffer().get(timeSeries);
//                for (int j = 0; j < Math.min(timeSeries.length, 10); j++) {
                for (int j = 0; j < timeSeries.length; j++) {
                    double ts = timeSeries[j];
                    System.out.print(formatter.format(ts) + " ");
                }
                System.out.println("...]");
            }
            fis.close();
            System.out.println(new Date() + "finish read ..." + path.toUri());
        }
    }

    /**
     *
     * positions file format
     * one line one position range
     * 1
     * 1,3
     * 2,100
     *
     *
     * output format
     *
     * 1
     * 0.343 0.4545 0.4545 ...
     * 2
     * 0.434 0.3434 0.343 ...
     */
}
