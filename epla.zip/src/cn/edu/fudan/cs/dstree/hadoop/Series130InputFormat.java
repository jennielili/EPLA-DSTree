package cn.edu.fudan.cs.dstree.hadoop;

/**
 * Created by wangyang on 14-1-26.
 */
public class Series130InputFormat extends FixedSizeRecordFileInputFormat {
    public Series130InputFormat()
    {
        super();
        fixedSize = 130 * 8;
    }
}
