package cn.edu.fudan.cs.dstree.strtree;

import cn.edu.fudan.cs.dstree.lhsm.CpuUsageGenerator;
import org.apache.commons.lang.time.StopWatch;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Created by wangyang on 2014/10/10.
 */
public class STRTree implements Serializable {

    Node root;

    public Node getRoot() {
        return root;
    }

    double[][] timeSeries;

    public int getDimCount() {
        return timeSeries[0].length;
    }

    public int getTimeSeriesCount() {
        return timeSeries.length;
    }

    int pageSize;

    public int getPageSize() {
        return pageSize;
    }

    double[] mbrUpper;
    double[] mbrLower;

    public double[][] getTimeSeries() {
        return timeSeries;
    }

    public double[] getMbrUpper() {
        return mbrUpper;
    }

    public double[] getMbrLower() {
        return mbrLower;
    }

    public STRTree(double[][] timeSeries, int pageSize) {
        this.timeSeries = timeSeries;
        this.pageSize = pageSize;

        int pageCount = (int) Math.ceil(timeSeries.length / pageSize);
        fanout = (int) Math.ceil(Math.pow(pageCount, 1.0 / getDimCount()));
        System.out.println("pageCount = " + pageCount);
        System.out.println("fanout = " + fanout);

        buildSTRTree();
    }

    int fanout;

    public int getFanout() {
        return fanout;
    }

    private void buildSTRTree() {
        //build tree recursively
        root = new Node(null, timeSeries, pageSize, 0);
    }

    public static void main(String[] args) {
        int count = 1000 * 1000;
        int dimCount = 10;
      //  CpuUsageGenerator cpuUsageGenerator = new CpuUsageGenerator(dimCount, -10, 10, 0, 4, -1000, 1000, 0);

        double[][] ts = new double[count][dimCount];
     //   for (int i = 0; i < ts.length; i++) {
       //     ts[i] = cpuUsageGenerator.generate();
        //}

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        int pageSize = 100;
        STRTree strTree = new STRTree(ts, pageSize);
        stopWatch.stop();
        Node root = strTree.getRoot();
        System.out.println("root = " + root);
        System.out.println("stopWatch.getTime() = " + stopWatch.getTime());
        root.printTreeInfo();
    }
}
