package cn.edu.fudan.cs.dstree.strtree;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Created by wangyang on 2014/10/10.
 */
public class Node implements Serializable {
    static int nums=0; 
	int[] idArray; //for search keep the id of original time series
    public  int id=nums++;
    public int[] getIdArray() {
        return idArray;
    }

    int tsCount;

    public int getTsCount() {
        return tsCount;
    }

    ArrayList<Node> children;

    public boolean isLeaf() {
        return children == null || children.size() == 0;
    }

    public int getChildCount() {
        if (isLeaf()) {
            return 0;
        } else {
            return children.size();
        }
    }

    public ArrayList<Node> getChildren() {
        return children;
    }

    public void addChild(Node child) {
        if (children == null) {
            children = new ArrayList<Node>();
        }
        children.add(child);
        child.parent = this;
    }

    Node parent;

    public void setLevel(int level) {
        this.level = level;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public Node getParent() {
        return parent;
    }

    int level = 0;

    public int getLevel() {
        return level;
    }

    int fanout;

    public int getFanout() {
        return fanout;
    }

    double[][] timeSeries;

    double[] mbrUpper;
    double[] mbrLower;

    public double[][] getTimeSeries() {
        return timeSeries;
    }

    public double[] getMbrUpper() {
        return mbrUpper;
    }

    public double[] getMbrLower() {
        return mbrLower;
    }

    double[] centroids;

    public double[] getCentroids() {
        return centroids;
    }

    int dimCount;

    public int getDimCount() {
        return dimCount;
    }

    double pageSize;
    int currentDim;

    public double getPageSize() {
        return pageSize;
    }

    public int getCurrentDim() {
        return currentDim;
    }

    public Node(Node parent, double[][] timeSeries, double pageSize, int currentDim) {
        this.parent = parent;
        if (parent != null) {
            this.level = parent.level + 1;
        }
        this.tsCount = timeSeries.length;

        this.pageSize = pageSize;
        this.currentDim = currentDim;
        this.dimCount = timeSeries[0].length;

        int pageCount = (int) Math.ceil(timeSeries.length / pageSize);
        fanout = (int) Math.ceil(Math.pow(pageCount, 1.0 / (dimCount - currentDim)));
//        System.out.println("pageCount = " + pageCount);
//        System.out.println("fanout = " + fanout);

        makeMbr(timeSeries);

        //do split if necessary
        if (getTsCount() > pageSize) {
            int nodeSize = (int) Math.ceil(tsCount * 1.0 / fanout);
            sortTimeSeries(timeSeries, currentDim);
            for (int i = 0; i < tsCount / nodeSize; i++) {
                double[][] tmpTs = new double[nodeSize][];
                System.arraycopy(timeSeries, i * nodeSize, tmpTs, 0, tmpTs.length);
                Node child = new Node(this, tmpTs, pageSize, currentDim + 1);
                addChild(child);
            }

            //process the tail
            if (tsCount % nodeSize != 0) {
                double[][] tmpTs = new double[tsCount % nodeSize][];
                System.arraycopy(timeSeries, tsCount - tmpTs.length, tmpTs, 0, tmpTs.length);
                Node child = new Node(this, tmpTs, pageSize, currentDim + 1);
                addChild(child);
            }
        } else {
            this.timeSeries = timeSeries;
            this.idArray = new int[timeSeries.length];
            Arrays.fill(this.idArray, -1); //not init
        }
    }

    private void sortTimeSeries(double[][] tmpTimeSeries, final int currentDim) {
        Arrays.sort(tmpTimeSeries, new Comparator<double[]>() {
            @Override
            public int compare(double[] o1, double[] o2) {
                return Double.compare(o1[currentDim], o2[currentDim]);
            }
        });
    }

    private void makeMbr(double[][] timeSeries) {
        mbrUpper = new double[getDimCount()];
        Arrays.fill(mbrUpper, Double.NEGATIVE_INFINITY);
        mbrLower = new double[getDimCount()];
        Arrays.fill(mbrLower, Double.POSITIVE_INFINITY);
        centroids = new double[getDimCount()];
        Arrays.fill(centroids, 0);

        for (int i = 0; i < timeSeries.length; i++) {
            double[] ts = timeSeries[i];

            for (int j = 0; j < ts.length; j++) {
                double t = ts[j];

                if (t > mbrUpper[j]) {
                    mbrUpper[j] = t;
                }

                if (t < mbrLower[j]) {
                    mbrLower[j] = t;
                }

                centroids[j] += t;
            }
        }

        //sum to average ==> center point
        for (int j = 0; j < centroids.length; j++) {
            centroids[j] = centroids[j] / timeSeries.length;
        }
    }

    @Override
    public String toString() {
        return "Node{" +
                "level=" + level +
                ", mbrUpper=" + Arrays.toString(mbrUpper) +
                ", mbrLower=" + Arrays.toString(mbrLower) +
                ", centroids=" + Arrays.toString(centroids) +
                ", tsCount=" + tsCount +
                ", isLeaf=" + isLeaf() +
                ", childCount=" + getChildCount() +
                '}';
    }

    public String toString(boolean isShort) {
        if (isShort)
            return "Node{" +
                    "level=" + level +
                    ", tsCount=" + tsCount +
                    ", isLeaf=" + isLeaf() +
                    ", childCount=" + getChildCount() +
                    '}';
        else
            return "Node{" +
                    "level=" + level +
                    ", mbrUpper=" + Arrays.toString(mbrUpper) +
                    ", mbrLower=" + Arrays.toString(mbrLower) +
                    ", centroids=" + Arrays.toString(centroids) +
                    ", tsCount=" + tsCount +
                    ", isLeaf=" + isLeaf() +
                    ", childCount=" + getChildCount() +
                    '}';
    }

    public void printTreeInfo() {
        System.out.println(rightPad(getLevel(), " ") + toString(true));
        if (!isLeaf()) {
            for (int i = 0; i < children.size(); i++) {
                Node node = children.get(i);
                node.printTreeInfo();
            }
        }
    }

    private String rightPad(int count, String s) {
        String ret = "";
        for (int i = 0; i < count; i++) {
            ret += s;
        }
        return ret;
    }


    public void getLeafNodes(List<Node> nodeList) {
        if (isLeaf()) {
            nodeList.add(this);
        } else {
            for (int i = 0; i < children.size(); i++) {
                Node child = children.get(i);
                child.getLeafNodes(nodeList);
            }
        }
    }

    public void initIdxArray(double[] ts, int id) {
        if (isLeaf()) {
            for (int i = 0; i < timeSeries.length; i++) {
                if (ts == timeSeries[i]) {
                    idArray[i] = id;
                    return;
                }
            }
//            throw new RuntimeException("not found!");
        } else {
            for (int i = 0; i < children.size(); i++) {
                Node child = children.get(i);

                if (child.contains(ts)) {
                    child.initIdxArray(ts, id);
                }
            }
        }
    }

    public boolean contains(double[] ts) {
        for (int i = 0; i < ts.length; i++) {
            double t = ts[i];
            if (!(mbrLower[i] <= t && t <= mbrUpper[i])) {
                return false;
            }
        }
        return true;
    }

    public boolean idxArrayInitialized() {
        for (int i = 0; i < idArray.length; i++) {
            int i1 = idArray[i];
            if (i1 < 0) {
                return false;
            }
        }

        return true;
    }

    public Node find(double[] ts) {
        if (isLeaf()) {
            for (int i = 0; i < timeSeries.length; i++) {
                if (ts == timeSeries[i]) {
                    return this;
                }
            }
        } else {
            for (int i = 0; i < children.size(); i++) {
                Node child = children.get(i);

                if (child.contains(ts)) {
                    return child.find(ts);
                }
            }
        }

        return null;
    }
}
