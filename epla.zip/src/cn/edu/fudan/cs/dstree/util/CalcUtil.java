package cn.edu.fudan.cs.dstree.util;

import cn.edu.fudan.cs.dstree.data.Utils;
import org.apache.commons.lang.math.IntRange;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.regression.SimpleRegression;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 10-12-30
 * Time: 下午5:41
 * To change this template use File | Settings | File Templates.
 */
public class CalcUtil {
    public static double avg(double[] timeSeries) {
    //	System.out.println("   the  length   is   "+timeSeries.length);
    	//System.out.println("   start   is   "+start+"   end   is  "+end);
        return avg(timeSeries, 0, timeSeries.length);
    }

    public static Mean mean = new Mean();

    public static double avg(double[] timeSeries, int start, int end) {
    	//System.out.println("  start   is   "+start+"  end    is  "+end+"    in CalcUtil.java");
        return mean.evaluate(timeSeries, start, (end - start));
    }

    public static Variance variance = new Variance(false);

    public static double deviation(double[] timeSeries, int start, int end) {
        return Math.sqrt(variance.evaluate(timeSeries, start, (end - start)));
    }

    public static double deviation(double[] timeSeries) {
        return deviation(timeSeries, 0, timeSeries.length);
    }

    public static double[] z_Normalize(double[] timeSeries) {
        double[] ret = new double[timeSeries.length];
        double mean = avg(timeSeries);
        double std = deviation(timeSeries);
        if (std == 0)
            std = 1;
        for (int i = 0; i < ret.length; i++) {
            ret[i] = (timeSeries[i] - mean) / std;
        }
        return ret;
    }

    public static double[] avgBySegments(double[] timeSeries, short[] segments) {
        double[] ret = new double[segments.length];
        int start = 0, end;
        for (int i = 0; i < ret.length; i++) {
            end = segments[i];
            ret[i] = avg(timeSeries, start, end);
            start = end;
        }
        return ret;
    }

    public static double[][] plaBySegments(double[] timeSeries, short[] segments) {
        double[][] ret = new double[segments.length][3];
        int start = 0, end;
        for (int i = 0; i < ret.length; i++) {
            end = segments[i];
            ret[i] = pla(timeSeries, start, end);
            start = end;
        }
        return ret;
    }

    public static double[] devBySegments(double[] timeSeries, short[] segments) {
        double[] ret = new double[segments.length];
        int start = 0, end;
        for (int i = 0; i < ret.length; i++) {
            end = segments[i];
            ret[i] = deviation(timeSeries, start, end);
            start = end;
        }
        return ret;
    }

    public static short[] split(short[] points, short minLength) {
        short[] newPoints = new short[points.length * 2];
        int c = 0;
        for (int i = 0; i < points.length; i++) {
            short length = points[i]; //i==0
            if (i > 0)
                length = (short) (points[i] - points[i - 1]);

            if (length >= minLength * 2) {
                int start = 0;
                if (i > 0)
                    start = points[i - 1];
                newPoints[c++] = (short) (start + length / 2);
            }
            newPoints[c++] = points[i];
        }

        short[] ret = new short[c];
        System.arraycopy(newPoints, 0, ret, 0, ret.length);
        return ret;
    }
/*
 *        points specify begin and end positions 
 * 
 */
    public static short[] calcPoints(int tsLength, int segmentSize) {
        int avgLegnth = tsLength / segmentSize;
        short[] points = new short[segmentSize];
        for (int i = 0; i < points.length; i++) {
            points[i] = (short) ((i + 1) * avgLegnth);
        }

        //set the last one
        points[points.length - 1] = (short) tsLength;
        return points;
    }

    public static double[] pla(double[] series, int fromIdx, int toIdx) {
        if ((fromIdx + 1) == toIdx)               //deal with one point
            return new double[]{0, series[fromIdx], 0};   //slope = 0, intercept = point value, sum error = 0;
        else {
            SimpleRegression sr = new SimpleRegression();
            for (int i = fromIdx; i < toIdx; i++) {
                sr.addData(i - fromIdx, series[i]);
            }
            return new double[]{sr.getSlope(), sr.getIntercept(), sr.getSumSquaredErrors()};
        }
    }

    public static double deviation(double[][] data, int idx) {
        return deviation(data, idx, 0, data.length);
    }

    public static double deviation(double[][] data, int idx, int start, int end) {
        double sum = 0;
        double sum2 = 0;
        for (double[] aData : data) {
            sum += aData[idx];
            sum2 += aData[idx] * aData[idx];
        }
        return Math.sqrt((sum2 - (sum * sum) / data.length) / data.length);
    }

    public static double[] deviation(double[][] data, int[] idxes) {
        return deviation(data, idxes, 0, data.length);
    }

    public static double[] deviation(double[][] data, int[] idxes, int start, int end) {
        double[] sum = new double[idxes.length];
        double[] sum2 = new double[idxes.length];
        for (int j = start; j < end; j++) {
            double[] aData = data[j];
            for (int i = 0; i < idxes.length; i++) {
                int idx = idxes[i];
                sum[i] += aData[idx];
                sum2[i] += aData[idx] * aData[idx];
//                System.out.println("  data     is    ****** "+aData[j]);
            }
        }

        double[] ret = new double[idxes.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = Math.sqrt((sum2[i] - (sum[i] * sum[i]) / data.length) / data.length);
        }

        return ret;
    }

    public static void main(String[] args) {
        double[][] vs = new double[100][2];
        double[] doubles = new double[100];
        for (int i = 0; i < vs.length; i++) {
            vs[i][0] = Utils.random(0, 100.0);
            vs[i][1] = vs[i][0] * 2;
            doubles[i] = vs[i][0];
        }

        double deviation = deviation(doubles);
        System.out.println("deviation = " + deviation);

        double deviation1 = deviation(vs, 0);
        System.out.println("deviation1 = " + deviation1);

        double[] devs = deviation(vs, new int[]{0,1});
        System.out.println("devs.length = " + devs.length);
        System.out.println("devs[0] = " + devs[0]);
        System.out.println("devs[1] = " + devs[1]);
    }

    public static int indexOfMax(double[] values)
    {
        int ret = -1;
        double maxValue = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < values.length; i++) {
            double value = values[i];
        //    System.out.println("  value   is    "+value+"   i   is  "+i);
            if (value > maxValue)
            {
                ret = i;
                maxValue = value;
            }
        }

        return ret;
    }

    public static int indexOfMin(double[] values)
    {
        int ret = -1;
        double minValue = Double.POSITIVE_INFINITY;
        for (int i = 0; i < values.length; i++) {
            double value = values[i];
            if (value < minValue)
            {
                ret = i;
                minValue = value;
            }
        }

        return ret;
    }

    public static List<IntRange> generateSplitRanges(int tsLength, int level) {
        List<IntRange> ret = new ArrayList<IntRange>();
        short[][] allLevelPoints = new short[level][];
        short[] firstLevelPoints = CalcUtil.calcPoints(tsLength, 1);
        allLevelPoints[0] = firstLevelPoints;
        for (int i = 1; i < level; i++) {
            allLevelPoints[i] = CalcUtil.split(allLevelPoints[i - 1], (short) 1);
        }

        for (int i = 0; i < allLevelPoints.length; i++) {
            short[] levelPoints = allLevelPoints[i];
            for (int j = 0; j < levelPoints.length; j++) {
                short endPoint = levelPoints[j];
                short startPoint = 0;
                if (j > 0)
                    startPoint = levelPoints[j - 1];
                IntRange range = new IntRange(startPoint, endPoint);
                ret.add(range);
            }
        }

        return ret;
    }
}
