package cn.edu.fudan.cs.dstree.util;
import  cn.edu.fudan.cs.dstree.allpair.complex;
import java.io.IOException;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: zetasq
 * Date: 1/31/11
 * Time: 9:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class DistUtil {
    public static double euclideanDist(double[] ts_1, double[] ts_2) {
        double sum = 0;
        for (int i = 0; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            sum += dp * dp;
        }
        return Math.sqrt(sum);
    }
    public static double euclideanDistSquare(double[] ts_1, double[] ts_2) {
        double sum = 0;
        for (int i = 0; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            sum += dp * dp;
        }
        return sum;
    }
    public static double euclideanDistSquare_dhd(double[] ts_1, double[] ts_2,double[] weight) {
    	//double[] weight={1,0.5,0.5,0.25,0.25,0.25,0.25,0.125,0.125,0.125,0.125,0.125,0.125,0.125,0.125,0.0625,0.0625}
        double sum = 0;
        for (int i = 0; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            
            sum += dp * dp;
        }
        return sum;
    }
    public static double euclideanDistSquare_dhd_iter(double[] ts_1, double[] ts_2,double[] weight,int iter) {
    	//double[] weight={1,0.5,0.5,0.25,0.25,0.25,0.25,0.125,0.125,0.125,0.125,0.125,0.125,0.125,0.125,0.0625,0.0625}
       // int start=Math.pow(arg0, arg1);
    	int start=0;
    	int end=0;
    	if(iter<=2)
    	{
    		start=0;
    		end=0;
    	}
    	if(iter==3)
    	{
    		start=1;
    		end=2;
    	}
    	if(iter==4)
    	{
    		start=3;
    		end=6;
    	}
    	if(iter==5)
    	{
    		start=7;
    		end=14;
    	}
    	if(iter==6)
    	{
    		start=15;
    		end=30;
    	}
    	if(iter>=7)
    	{
    		start=0;
    		end=ts_1.length-1;
    	}
    	double sum = 0;
        for (int i = start; i < end+1; i++) {
            final double dp = ts_1[i] - ts_2[i];
            
            sum += dp * dp;
        }
        return sum;
    }
    public static double euclideanDistSquare_start(double[] ts_1, double[] ts_2, int start) {
        double sum = 0;
        for (int i = start; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            sum += dp * dp;
        }
        return sum;
    }
    public static boolean euclideanDistLessThan(double[] ts_1, double[] ts_2, double range) {
        double rangeSquare = range * range;
        double sumSquare = 0;
        for (int i = 0; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            sumSquare += dp * dp;
            if (sumSquare > rangeSquare)
            {
            	//System.out.println("distance    is   "+sumSquare);
                return false;
            }
        }
  //      System.out.println("distance  ******  is   "+sumSquare);
        return true;
    }
    public static double euclideanDistLessThan_double(double[] ts_1, double[] ts_2, double range) {
        double rangeSquare = range * range;
        double sumSquare = 0;
        for (int i = 0; i < ts_1.length; i++) {
            final double dp = ts_1[i] - ts_2[i];
            sumSquare += dp * dp;
            if (sumSquare > rangeSquare)
            {
            	//System.out.println("distance    is   "+sumSquare);
                return -1.0;
            }
        }
  //      System.out.println("distance  ******  is   "+sumSquare);
        return sumSquare;
    }
    public static double euclideanDistLessThan_dft(complex[] value1, complex[] value2, double range) {
        double rangeSquare = range * range;
        double sumSquare = 0;
        for (int i = 0; i < value1.length; i++) {
        	double dis=(value2[i].i-value1[i].i)*(value2[i].i-value1[i].i)+(value2[i].r-value1[i].r)*(value2[i].r-value1[i].r);
            if (sumSquare > rangeSquare*1024)
            {
            	//System.out.println("distance    is   "+sumSquare);
                return -1.0;
            }
        }
  //      System.out.println("distance  ******  is   "+sumSquare);
        return sumSquare/1024;
    }

    public static double minDist(String fileName, double[] queryTs) throws IOException {
        //open index file;
        TimeSeriesReader timeSeriesReader = new TimeSeriesReader(fileName);
        timeSeriesReader.open();
        double ShortestDist = Double.POSITIVE_INFINITY;
        double tempDist;
        int lineNo = 0;
        int resultLineNo = -1;
        while (timeSeriesReader.hasNext()) {
            double tempTimeseries[] = timeSeriesReader.next();
            tempDist = DistUtil.euclideanDist(queryTs, tempTimeseries);
            if (tempDist < ShortestDist) {
                ShortestDist = tempDist;
                resultLineNo = lineNo;
            }
            lineNo++;
        }
        timeSeriesReader.close();
        System.out.println("resultLineNo = " + resultLineNo);
        return ShortestDist;
    }

    public static double minDistBinary(String fileName, double[] queryTs) throws IOException {
        //open index file;
        double[][] tss = TimeSeriesFileUtil.readSeriesFromBinaryFileAtOnce(fileName, queryTs.length);
       
        return minDist(tss, queryTs);
    }
    public static double minDistBinary2(double[][] tss, double[] queryTs) throws IOException {
        //open index file;
        
        return minDist(tss, queryTs);
    }
    public static double[] minDist(String fileName, double[][] multiTs) throws IOException {
        //open index file;
        TimeSeriesReader timeSeriesReader = new TimeSeriesReader(fileName);
        timeSeriesReader.open();
        double[] shortestDists = new double[multiTs.length];
        Arrays.fill(shortestDists, Double.POSITIVE_INFINITY);
        double tempDist;
        int lineNo = 0;
        int resultLineNo = -1;
        while (timeSeriesReader.hasNext()) {
            double tempTimeseries[] = timeSeriesReader.next();
            for (int i = 0; i < shortestDists.length; i++) {
                tempDist = DistUtil.euclideanDist(multiTs[i], tempTimeseries);
                if (tempDist < shortestDists[i]) {
                    shortestDists[i] = tempDist;
                    resultLineNo = lineNo;
//                    String s = TimeSeriesFileUtil.timeSeries2Line(tempTimeseries);
//                    System.out.println("s = " + s);
//                    System.out.println("tempDist = " + tempDist);
                }
            }
            lineNo++;
        }
        timeSeriesReader.close();
        System.out.println("resultLineNo = " + resultLineNo);
        return shortestDists;
    }

    public static double minDist(double[][] tss, double[] queryTs) throws IOException {
        double ShortestDist = Double.POSITIVE_INFINITY;
        double tempDist;
//        int resultLineNo = -1;
        for (int i = 0; i < tss.length; i++) {
            tempDist = DistUtil.euclideanDist(queryTs, tss[i]);
            if (tempDist < ShortestDist) {
                ShortestDist = tempDist;
//                resultLineNo = i;
            }
        }
//        System.out.println("resultLineNo = " + resultLineNo);
        return ShortestDist;
    }


    public static int minDistIndex(double[][] tsArray, double[] queryTs) {
        int ret = -1;
        double ShortestDist = Double.POSITIVE_INFINITY;
        double tempDist;
        for (int i = 0; i < tsArray.length; i++) {
            tempDist = DistUtil.euclideanDist(queryTs, tsArray[i]);
            if (tempDist < ShortestDist) {
                ShortestDist = tempDist;
                ret = i;
            }
        }
        return ret;
    }
}
