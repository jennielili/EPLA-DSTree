package cn.edu.fudan.cs.dstree.util;

import cn.edu.fudan.cs.dstree.data.Utils;

/**
 * Created by wangyang on 14-2-16.
 * This reduces the average complexity from O(n log n) (in quicksort) to O(n) (in quickselect).
 */
public class QuickSelect {
    public static double quickSelectMedian(double[] list) {
        return quickSelect(list, list.length / 2);
    }

    public static double quickSelect(double[] list, int kth) {
        return quickSelect(list, 0, list.length - 1, kth);
    }

    public static double quickSelect(double[] list, int left, int right, int kth) {
        if (left == right)        // If the list contains only one element
            return list[left];  // Return that element

        while (true) {
            int pivotIndex = Utils.random(left, right);
            pivotIndex = partition(list, left, right, pivotIndex);
            if (kth == pivotIndex)
                return list[kth];
            else if (kth < pivotIndex)
                right = pivotIndex - 1;
            else
                left = pivotIndex + 1;
        }
    }

    private static int partition(double[] list, int left, int right, int pivotIndex) {
        double pivotValue = list[pivotIndex];
        double tmp = list[pivotIndex];
        list[pivotIndex] = list[right];
        list[right] = tmp;

        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (list[i] <= pivotValue) {
                double t = list[storeIndex];
                list[storeIndex] = list[i];
                list[i] = t;
                storeIndex++;
            }
        }
        tmp = list[right];
        list[right] = list[storeIndex];
        list[storeIndex] = tmp;

        return storeIndex;
    }

    public static double quickSelectMedian(double[][] list, int left, int right, int idx) {
        return quickSelect(list, left, right, (left + right) / 2, idx);
    }
    public static double quickSelectMedian(double[][] list, int left, int right, int idx,int[] indexes) {
        return quickSelect(list, left, right, (left + right) / 2, idx,indexes);
    }
    public static double quickSelectMedian(double[][] list, int idx) {
        return quickSelect(list, list.length / 2, idx);
    }

    public static double quickSelect(double[][] list, int kth, int idx) {
        return quickSelect(list, 0, list.length - 1, kth, idx);
    }

    public static double quickSelect(double[][] list, int left, int right, int kth, int idx) {
        if (left == right)        // If the list contains only one element
            return list[left][idx];  // Return that element

        while (true) {
            int pivotIndex = Utils.random(left, right);
            pivotIndex = partition(list, left, right, pivotIndex, idx);
            if (kth == pivotIndex)
                return list[kth][idx];
            else if (kth < pivotIndex)
                right = pivotIndex - 1;
            else
                left = pivotIndex + 1;
        }
    }
    public static double quickSelect(double[][] list, int left, int right, int kth, int idx,int[] indexes) {
        if (left == right)        // If the list contains only one element
            return list[left][idx];  // Return that element

        while (true) {
            int pivotIndex = Utils.random(left, right);
            pivotIndex = partition(list, left, right, pivotIndex, idx,indexes);
            if (kth == pivotIndex)
                return list[kth][idx];
            else if (kth < pivotIndex)
                right = pivotIndex - 1;
            else
                left = pivotIndex + 1;
        }
    }
    private static int partition(double[][] list, int left, int right, int pivotIndex, int idx) {
        double pivotValue = list[pivotIndex][idx];
        double[] tmp = list[pivotIndex];
        list[pivotIndex] = list[right];
        list[right] = tmp;

        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (list[i][idx] <= pivotValue) {
                double[] t = list[storeIndex];
                list[storeIndex] = list[i];
                list[i] = t;
                storeIndex++;
            }
        }
        tmp = list[right];
        list[right] = list[storeIndex];
        list[storeIndex] = tmp;

        return storeIndex;
    }

    private static int partition(double[][] list, int left, int right, int pivotIndex, int idx,int[] indexes) {
        double pivotValue = list[pivotIndex][idx];
        double[] tmp = list[pivotIndex];
        list[pivotIndex] = list[right];
        list[right] = tmp;
        
        //add by lqh change the indexes
        int tmp2 = indexes[pivotIndex];
        indexes[pivotIndex] = indexes[right];
        indexes[right] = tmp2;
        

        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (list[i][idx] <= pivotValue) {
                double[] t = list[storeIndex];
                list[storeIndex] = list[i];
                list[i] = t;
                
                //add by lqh change the indexes
                int tmp3 = indexes[storeIndex];
                indexes[storeIndex] = indexes[i];
                indexes[i] = tmp3;
              
                storeIndex++;
            }
        }
        tmp = list[right];
        list[right] = list[storeIndex];
        list[storeIndex] = tmp;
        
        //add by lqh to change indexes
        int tmp4 = indexes[right];
        indexes[right] = indexes[storeIndex];
        indexes[storeIndex] = tmp4;

        return storeIndex;
    }
    public static void main(String[] args) {
        double[] list = new double[]{3, 1, 2};
        double v = quickSelectMedian(list);
        System.out.println("v = " + v);

        for (int i = 0; i < list.length; i++) {
            double v1 = list[i];
            if (i == list.length / 2) {
                System.out.print("*" + i);
            }
            System.out.println("v1 = " + v1);
        }

        double[][] newList = new double[100][5];
        for (int i = 0; i < newList.length; i++) {
            double[] vs = newList[i];

            vs[0] = Utils.random(0, 100);
            for (int j = 0; j < vs.length; j++) {
                vs[j] = vs[0] * (j + 1);
            }
        }

        double v1 = quickSelectMedian(newList, 1);
        System.out.println("v1 = " + v1);
        for (int i = 0; i < newList.length; i++) {
            double[] doubles = newList[i];
            if (i == newList.length / 2) {
                System.out.print(i + "*");
            }
            System.out.println("doubles[1] = " + doubles[1]);
            System.out.println("doubles[0] = " + doubles[0]);
        }
    }
}
