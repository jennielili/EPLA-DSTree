package cn.edu.fudan.cs.dstree.util;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 10-12-30
 * Time: 下午3:17
 * To change this template use File | Settings | File Templates.
 */
public class TimeSeriesReader {
    BufferedReader bfr;
    String fileName;
    double[][] data2;

    int pos;

    public String getFileName() {
        return fileName;
    }

    public TimeSeriesReader(String fileName) {
        this.fileName = fileName;
    }

    public TimeSeriesReader(double[][] data) {
        this.data2 = data;
        size = data.length;
        pos = 0;
    }

    int size;

    String line;

    public boolean hasNext() throws IOException {
        if (data2 == null) {
            line = bfr.readLine();
            return (line != null && line.trim().length() > 0);
        } else {
            return pos <= size;
        }
    }

    static String SEPARATOR = " |\t|\n";

    public static double[] readFromString(String str) {
        String[] strings = str.split(SEPARATOR);

        double[] ret = new double[strings.length];

        for (int i = 0; i < ret.length; i++) {
            String s = strings[i];
            if (s.length() > 0)
                ret[i] = Double.parseDouble(s);
        }
        return ret;
    }

    public double[] next() {
        if (data2 == null)
            return readFromString(line);
        else
            return data2[pos++]; //return and inc pos
    }

    public void open() throws FileNotFoundException {
        if (data2 == null)
            bfr = new BufferedReader(new FileReader(new File(fileName)));
    }

    public void close() throws IOException {
        if (data2 == null)
            bfr.close();
    }
}
