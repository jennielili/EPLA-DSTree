package cn.edu.fudan.cs.dstree.data;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import cn.edu.fudan.cs.dstree.util.CalcUtil;

public class ReadDataFromTao {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
	//	BufferedReader aa = new BufferedReader(new FileReader(
		//"c:\\data\\tao.txt"));
		//BufferedWriter bb=new BufferedWriter(new FileWriter(
		//		"d:\\data\\tao_new20"));
		BufferedReader aa = new BufferedReader(new FileReader(
		"c:\\data\\tao.txt"));
		int rep = 0;
		int count = 0;
		int length = 963;
		int newlen=512;
		int stride=20;
		stride=Integer.parseInt(args[0]);
		int batchWriteSize=1000;
		FileOutputStream fos = new FileOutputStream("c:\\data\\tao_normalize"+stride);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		DataOutputStream dos = new DataOutputStream(bos);
		double[] timeseries = new double[length];
		double[] series = new double[length];
		while (aa.ready()) {
			String newLine = aa.readLine();
			String[] values = newLine.split(" ");
		//	System.out.println(" length   is  " + values.length);
			for (int ii = 0; ii < values.length; ii++) {
				if(!values[ii].trim().equals(""))
				{
					timeseries[ii] = Double.parseDouble(values[ii]);
				//	System.out.println("  ii  "+ii+"  value   "+values[ii]);
				}
			}
			series = CalcUtil.z_Normalize(timeseries);
			
			int t=(length-newlen)/stride;
			for(int j=0;j<t;j++)
			{
				String line="";
				for(int k=0;k<newlen;k++)
				{
					dos.writeDouble(series[k+j*stride]);
				//	line=line+series[k+j*stride]+" ";
					
				//	System.out.println("  value    is    "+series[k+j*stride]);
				}
				//bb.write(line);
			//	bb.newLine();
				count++;
					
			}
			if (count % batchWriteSize == 0) {
				System.out.println(new Date() + " count = " + count);
				dos.flush();
			}
			

		}
        System.out.println("   count   is   "+count);     
        dos.close(); 
	}

}
