package cn.edu.fudan.cs.dstree.data;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 11-6-21
 * Time: 下午7:32
 * To change this template use File | Settings | File Templates.
 */
public interface SeriesGenerator {
    double[] generate();
}
