package cn.edu.fudan.cs.dstree.data;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import cn.edu.fudan.cs.dstree.util.CalcUtil;

public class ReadDataFromBinary2 {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		BufferedWriter bb = new BufferedWriter(new FileWriter(
		"c:\\data\\tao_new.txt"));
		//BufferedWriter bb=new BufferedWriter(new FileWriter(
		//		"d:\\data\\tao_new20"));
		
		
		FileInputStream fis = new FileInputStream("c:\\data\\tao_new_original20");
	//	FileInputStream fis = new FileInputStream("c:\\data\\ucibinary");
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		
		FileOutputStream fos = new FileOutputStream("c:\\data\\tao_new_original"+20);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		DataOutputStream dos = new DataOutputStream(bos);
		
		//int count=91921;
		int count=10000;
		int tsLength=128;
		long count2 = 0;
		for (int i = 0; i < count; i++) {
			double[] tss = new double[tsLength];
			double[] tssN = new double[tsLength];
			String temp="";
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();
				//temp+=tss[j]+" ";
				

			}
			tssN = CalcUtil.z_Normalize(tss);
			for (int j = 0; j < tsLength; j++) {
				//tss[j] = dis.readDouble();
				//temp+=tssN[j]+" ";
				dos.writeDouble(tssN[j]);
				

			}
		//	bb.write(temp);
		//	System.out.println(temp);
			//bb.newLine();
		}
		dos.flush();
		dos.close();
		
	}

}
