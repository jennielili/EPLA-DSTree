package cn.edu.fudan.cs.dstree.data;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import cn.edu.fudan.cs.dstree.util.CalcUtil;

public class ReadDataFromBinary {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		BufferedWriter bb = new BufferedWriter(new FileWriter(
		"c:\\data\\tao_new.txt"));
		//BufferedWriter bb=new BufferedWriter(new FileWriter(
		//		"d:\\data\\tao_new20"));
		
		
		//FileInputStream fis = new FileInputStream("c:\\data\\tao_new_original20");
		FileInputStream fis = new FileInputStream("c:\\data\\tao_normalize20");
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		//int count=670878;
		int count=268796;
		//int count=10000;
		int tsLength=512;
		long count2 = 0;
		for (int i = 0; i < count; i++) {
			double[] tss = new double[tsLength];
			double[] tssN = new double[tsLength];
			String temp="";
			for (int j = 0; j < tsLength; j++) {
				tss[j] = dis.readDouble();
				//temp+=tss[j]+" ";
				

			}
			if(i%10000==0)
				System.out.println("  i   is    "+i);
			tssN = CalcUtil.z_Normalize(tss);
			for (int j = 0; j < tsLength; j++) {
				//tss[j] = dis.readDouble();
				temp+=tss[j]+" ";
				

			}
			bb.write(temp);
		//	System.out.println(temp);
			bb.newLine();
		}
		bb.close();
		
	}

}
