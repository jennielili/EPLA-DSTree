package cn.edu.fudan.cs.dstree.data;

import cn.edu.fudan.cs.dstree.util.CalcUtil;
import cn.edu.fudan.cs.dstree.util.TimeSeriesFileUtil;

import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: wangyang
 * Date: 12-3-4
 * Time: 下午2:50
 * To change this template use File | Settings | File Templates.
 * save the random series into file for experiment,length = 1204
 */
public class ExprRndSeriesGenerator {
    public static void main(String[] args) throws IOException {
        String filePath = "G:\\dstree_data\\";
        if (args.length > 0) {
            filePath = args[0];
        }

        int seriesLength = 128;
        if (args.length > 1) {
            seriesLength = Integer.parseInt(args[1]);
        }

//        int size = 100;
        int size = 1000 * 70;
        if (args.length > 2) {
            size = Integer.parseInt(args[2]);
        }

        boolean txtFormat = true;
        if (args.length > 3) {
            if (args[3].equalsIgnoreCase("bin"))
            {
                txtFormat = false;
            }
        }

        String fileName = filePath +"Series_" + seriesLength + "_" +size + ".z.txt";
        if (!txtFormat)
            fileName = filePath +"Series_" + seriesLength + "_" +size + ".z.bin";
        System.out.println("fileNames = " + fileName);
        File file = new File(fileName);
        if (file.exists())
            file.delete();

        RandomSeriesGenerator randomSeriesGenerator = new RandomSeriesGenerator();

        GaussianGenerator gaussianGenerator = new GaussianGenerator(seriesLength,-50,50,0,10);
        randomSeriesGenerator.addGenerator(gaussianGenerator);

        RandomWalkGenerator randomWalkGenerator = new RandomWalkGenerator(seriesLength,-50,50,0,10);
        randomSeriesGenerator.addGenerator(randomWalkGenerator);
        randomSeriesGenerator.addGenerator(randomWalkGenerator);
        randomSeriesGenerator.addGenerator(randomWalkGenerator);

        SegmentGaussianGenerator segmentGaussianGenerator = new SegmentGaussianGenerator(seriesLength,3,10,-50,50,0,10);
        randomSeriesGenerator.addGenerator(segmentGaussianGenerator);
        randomSeriesGenerator.addGenerator(segmentGaussianGenerator);

        SineGenerator sineGenerator = new SineGenerator(seriesLength,1,5,2,20,-50,50);
        randomSeriesGenerator.addGenerator(sineGenerator);
        randomSeriesGenerator.addGenerator(sineGenerator);

        FileOutputStream fos = new FileOutputStream(fileName);

        int batchWriteSize = 10000;

        if (txtFormat)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= size; i++) {
                double[] series = randomSeriesGenerator.generate();
                series = CalcUtil.z_Normalize(series);
                sb.append(TimeSeriesFileUtil.timeSeries2Line(series));
                if (i % batchWriteSize == 0)
                {
                    System.out.println(new Date() + " i = " + i);
                    fos.write(sb.toString().getBytes());
                    fos.flush();
                    sb = new StringBuilder();
                }
            }
            if (sb.length() > 0)
                fos.write(sb.toString().getBytes());

        }
        else  //bin format
        {
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            DataOutputStream dos = new DataOutputStream(bos);

            for (int i = 1; i <= size; i++) {
                double[] series = randomSeriesGenerator.generate();
                series = CalcUtil.z_Normalize(series);
                for (int j = 0; j < series.length; j++) {
                    dos.writeDouble(series[j]);
                }
                if (i % batchWriteSize == 0)
                {
                    System.out.println(new Date() + " i = " + i);
                    dos.flush();
                }
            }

            dos.flush();
            dos.close();
            bos.flush();
            bos.close();
        }

        fos.flush();
        fos.close();
    }
}
